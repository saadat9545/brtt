from pyrogram import filters, enums, Client, errors
from pyrogram.types import Message, ChatPermissions
from utils.filters import check
from utils.clients import ApiClient
from utils.config import SETTINGS, SUDO, DATA_DIR, ZIP_NAME, BASE_DIR
from pickle import dump
from utils import Buttons
import asyncio
from os import remove as os_remove
import string, random as rnd, shutil, time as myTime, re, os, sys, pyrogram
from data.database import db
from bs4 import BeautifulSoup
import zipfile
import time

# اگر پوشه وجود نداشت، خودکار ساخته شود
os.makedirs(DATA_DIR, exist_ok=True)
#-----------------------------------------------------
def wFile(input):
    file = open(f"{input}", "w", encoding = "utf8")
    file.close()
#------------------------------------------------------
def save_settings():
    with open('settings.pkl', 'wb') as f:
        dump(SETTINGS, f)
#-----------------------------------------------------
@ApiClient.on_message(filters.user(SUDO) & filters.private & filters.command('backup'))
async def backup(bot: Client, msg: Message):
    wait_msg = await msg.reply('<b>⏳ لطفا منتظر بمانید ...</b>')
    user_id = msg.from_user.id
    async def progress(current, total):
        percent = current * 100 / total
        await wait_msg.edit_text(
            f"<b>📤 در حال آپلود...\n{percent:.1f}%</b>")
    await bot.send_document(
        user_id,
        "betdata.db",
        progress=progress)
    await wait_msg.edit_text("<b>📤 آپلود فایل دوم...</b>")
    await bot.send_document(
        user_id,
        "settings.pkl",
        progress=progress)
    await wait_msg.edit_text("<b>✅ بکاپ با موفقیت ارسال شد</b>")


@ApiClient.on_message(filters.user(SUDO) & filters.private & filters.regex('📊 وضعیت$'))
async def online_members(bot: Client, msg: Message):
    live, active, daily = db.online_stats()

    text = (
        "📊 **وضعیت کاربران آنلاین**\n\n"
        f"🟢 آنلاین لحظه‌ای: **{live or 0}**\n"
        f"🟡 کاربران فعال (۵ دقیقه): **{active or 0}**\n"
        f"🔵 کاربران امروز: **{daily or 0}**"
    )

    await msg.reply_text(text)
#-----------------------------------------------------
@ApiClient.on_message(filters.user(SUDO) & filters.private & filters.command("zip"))
async def file_zip(bot: Client, msg: Message):

    files = os.listdir(DATA_DIR)
    if not files:
        return await msg.reply("⚠️ هیچ فایلی برای زیپ کردن وجود ندارد.")

    status = await msg.reply("📦 در حال ساخت فایل ZIP ...")

    try:
        with zipfile.ZipFile(ZIP_NAME, "w", zipfile.ZIP_DEFLATED) as zipf:
            for file in files:
                file_path = os.path.join(DATA_DIR, file)
                if os.path.isfile(file_path):
                    zipf.write(file_path, arcname=file)

        await status.edit("📤 در حال ارسال فایل ZIP ...")

        await msg.reply_document(
            document=ZIP_NAME,
            caption="✅ فایل‌ها با موفقیت زیپ شدند."
        )

    except Exception as e:
        await status.edit(f"❌ خطا:\n`{e}`")

    finally:
        if os.path.exists(ZIP_NAME):
            os.remove(ZIP_NAME)

@ApiClient.on_message(filters.user(SUDO) & filters.private & filters.command('r'))
async def Reload(_, msg: Message):
    await msg.reply_text(f'<b>Reloaded !</b>')
    os.execl(sys.executable, sys.executable, *sys.argv)   


@ApiClient.on_message(filters.user(SUDO) & filters.reply & filters.regex(r'^/settext'))
async def set_btext_banere(bot: Client, msg: Message):
    SETTINGS['text_baner'] = msg.reply_to_message.id
    save_settings()
    await msg.reply_text(f'بنر زیرمجموعه ذخیره شد!')

@ApiClient.on_message(filters.user(SUDO) & filters.reply & filters.regex(r'^/setbn'))
async def set_link_bn(bot: Client, msg: Message):
    SETTINGS['link_baner'] = msg.reply_to_message.id
    save_settings()
    await msg.reply_text(f'<b>بنر زیرمجموعه گیری  با موفقیت ذخیره شد!</b>')

@ApiClient.on_message(filters.user(SUDO) & filters.regex(r'^/delbn'))
async def del_link_bn(bot: Client, msg: Message):
    SETTINGS['link_baner'] = 0
    save_settings()
    await msg.reply_text(f'<b>بنر زیرمجموعه گیری  با موفقیت پاک شد!</b>')


@ApiClient.on_message(filters.user(SUDO) & filters.reply & filters.regex(r'^/setform site$'))
async def set_link_site(bot: Client, msg: Message):
    SETTINGS['link_site'] = msg.reply_to_message.id
    save_settings()
    await msg.reply_text(f'<b>لینک سایت با موفقیت ذخیره شد!</b>')


@ApiClient.on_message(filters.user(SUDO) & filters.regex(r'^/delform site$'))
async def del_link_sitee(bot: Client, msg: Message):
    SETTINGS['link_site'] = 0
    save_settings()
    await msg.reply_text(f'<b>لینک سایت با موفقیت پاک شد!</b>')

@ApiClient.on_message(filters.user(SUDO) & filters.reply & filters.regex(r'^/setform shorbet$'))
async def set_shorbet_form(bot: Client, msg: Message):
    SETTINGS['vip_form'] = msg.reply_to_message.id
    save_settings()
    await msg.reply_text(f'<b>فرم شوربت ذخیره شد !</b>')


@ApiClient.on_message(filters.user(SUDO) & filters.regex(r'^/delform shorbet$'))
async def del_shorbet_form(bot: Client, msg: Message):
    SETTINGS['vip_form'] = 0
    save_settings()
    await msg.reply_text(f'<b>فرم شوربت پاک شد !</b>')


@ApiClient.on_message(filters.user(SUDO) & filters.reply & filters.regex(r'^/setform link$'))
async def set_nofilter_link_site(bot: Client, msg: Message):
    SETTINGS['no_fillter'] = msg.reply_to_message.id
    save_settings()
    await msg.reply_text(f'<b>لینک سایت بدون فیلتر با موفقیت ذخیره شد!</b>')


@ApiClient.on_message(filters.user(SUDO) &  filters.regex(r'^/delform link$'))
async def del_nofilter_link_site(bot: Client, msg: Message):
    SETTINGS['no_fillter'] = 0
    save_settings()
    await msg.reply_text(f'<b>لینک سایت بدون فیلتر با موفقیت پاک شد!</b>')

# @ApiClient.on_message(filters.user(SUDO) & filters.reply & filters.regex(r'^/setform vip$'))
# async def set_vip_form(bot: Client, msg: Message):
#     SETTINGS['vip_form'] = msg.reply_to_message.id
#     save_settings()
#     await msg.reply_text(f'<b>فرم وی آی پی ذخیره شد !</b>')


# @ApiClient.on_message(filters.user(SUDO) & filters.regex(r'^/delform vip$'))
# async def del_vip_form(bot: Client, msg: Message):
#     SETTINGS['vip_form'] = 0
#     save_settings()
#     await msg.reply_text(f'<b>فرم وی آی پی پاک شد !</b>')



@ApiClient.on_message(filters.user(SUDO) & filters.reply & filters.regex(r'^/setform fulltime$'))
async def set_football_form(bot: Client, msg: Message):
    SETTINGS['footbal_form'] = msg.reply_to_message.id
    save_settings()
    await msg.reply_text(f'<b>فرم نتیجه دقیق ذخیره شد !</b>')


@ApiClient.on_message(filters.user(SUDO) & filters.regex(r'^/delform fulltime$'))
async def del_football_form(bot: Client, msg: Message):
    SETTINGS['footbal_form'] = 0
    save_settings()
    await msg.reply_text(f'<b>فرم نتیجه دقیق پاک شد !</b>')


@ApiClient.on_message(filters.user(SUDO) & filters.reply & filters.regex(r'^/setform ourbots$'))
async def set_haki_form(bot: Client, msg: Message):
    SETTINGS['ourbots'] = msg.reply_to_message.id
    save_settings()
    await msg.reply_text(f'<b> لیست ربات ذخیره شد !</b>')


@ApiClient.on_message(filters.user(SUDO) & filters.regex(r'^/delform ourbots$'))
async def del_haki_form(bot: Client, msg: Message):
    SETTINGS['ourbots'] = 0
    save_settings()
    await msg.reply_text(f'<b> لیست ربات  پاک شد !</b>')



@ApiClient.on_message(filters.user(SUDO) & filters.private & filters.regex('اطلاعات 🔭$'))
async def bot_info(bot: Client, msg: Message):
    t = db.All_Data_Text()
    c = db.All_user_count()
    file_name = "Bot_sub_info.html"
    with open(file_name, "w", encoding="utf-8") as f:
        f.write(t)
    status_msg = await msg.reply_text("📤 در حال آپلود فایل...")
    start_time = time.time()
    async def progress(current, total):
        if total == 0:
            return
        percent = int(current * 100 / total)
        try:
            await status_msg.edit_text(
                f"📤 در حال آپلود فایل...\n"
                f"📊 پیشرفت: {percent}%")
        except:
            pass
    await bot.send_document(msg.chat.id,file_name,caption=f'👥 Count : {c}',progress=progress)
    await status_msg.delete()
    os.remove(file_name)
    
@ApiClient.on_message(filters.user(SUDO) & filters.private & filters.regex('نجوا 📩$'))
async def send_message_All_member(bot: Client, msg: Message):
    message = await bot.ask(msg.from_user.id, 'شما در حال ارسال پیام به تمام کاربرای ربات هستین !\nلطفا پیام خود را بفرستین !')
    x = 0

    a = db.All_Users()
    for i in a:
       for b in i:
            await message.copy(int(b))
            x += 1
    await msg.reply_text(f'پیام با موفقیت به {x} کاربرای ربات ارسال شد !')


@ApiClient.on_message(filters.user(SUDO) & filters.command(r'^s'))
async def set_je(bot: Client, msg: Message):
    res = msg.command[1]
    name = await bot.get_chat(int(res))
    if int(res) in SETTINGS['channel_ids']:
        msg.reply('در جوین اجباری ها موجود می باشد ⁉️')
    else:
        SETTINGS['channel_link'][name.title] = name.invite_link
        SETTINGS['channel_ids'][int(res)] = name.invite_link
        save_settings()
        await msg.reply_text(f'➕ جوین اجباری جدید ✔️\n®️ نام : {name.title}\n©️شناسه : <code>{res}</code>\n➰ لینک :\n<code>{name.invite_link}</code>')


@ApiClient.on_message(filters.user(SUDO) & filters.command(r'^d'))
async def det_je(bot: Client, msg: Message):
    res = msg.command[1]

    name = await bot.get_chat(int(res))

    try:
        SETTINGS['channel_ids'].pop(int(res))
        SETTINGS['channel_link'].pop(name.title)
        save_settings()
        await msg.reply_text(f'➖ حذف جوین اجباری  ✔️\n®️ نام : {name.title}\n©️شناسه : <code>{res}</code>')
    except:
        await msg.reply('در جوین اجباری ها موجود نیست ⁉️')


@ApiClient.on_message(filters.user(SUDO) & filters.command(r'^resetj'))
async def reset_join(bot: Client, msg: Message):

    SETTINGS['channel_link'].clear()
    SETTINGS['channel_ids'].clear()
    await msg.reply_text(f'تمام جوین اجباری ها با موفقیت حذف شدن !')


@Client.on_message(filters.user(SUDO) & filters.command("todata"))
async def Add_database(bot: Client, msg: Message):
    if not msg.reply_to_message or not msg.reply_to_message.document:
        await msg.reply_text("⚠️ لطفاً روی فایل HTML ریپلای کنید.")
        return
    file_path = await msg.reply_to_message.download(file_name="users.html")

    status_msg = await msg.reply_text("📥 در حال دانلود فایل HTML ...")

    from bs4 import BeautifulSoup
    import asyncio, os

    with open(file_path, "r", encoding="utf-8") as f:
        soup = BeautifulSoup(f, "lxml")

    # ✅ فقط کاربران معتبر
    valid_rows = []
    for tr in soup.find_all("tr"):
        tds = tr.find_all("td")
        if len(tds) == 5 and tds[1].get_text(strip=True).isdigit():
            valid_rows.append(tds)

    total = len(valid_rows)

    if total == 0:
        await status_msg.edit_text("❌ هیچ کاربر معتبری در فایل پیدا نشد.")
        return

    added = 0
    skipped = 0

    await status_msg.edit_text(
        f"✅ {total} کاربر شناسایی شد\n🚀 شروع ورود به دیتابیس..."
    )

    for i, cols in enumerate(valid_rows, start=1):
        name = cols[0].get_text(strip=True)
        user_id = int(cols[1].get_text(strip=True))
        username = cols[2].get_text(strip=True) or None
        invited = int(cols[3].get_text(strip=True) or 0)
        join_time = cols[4].get_text(strip=True)

        if not db.User_id(user_id):
            db.Add_User(name, user_id, username, invited, join_time)
            added += 1
        else:
            skipped += 1

        # ✅ درصد واقعی
        if i % 300 == 0 or i == total:
            percent = int((i / total) * 100)
            await status_msg.edit_text(
                f"🔄 در حال پردازش داده‌ها...\n\n"
                f"📊 پیشرفت: {percent}%\n"
                f"✅ اضافه شده: {added}\n"
                f"♻️ تکراری: {skipped}"
            )
            await asyncio.sleep(0.2)

    await status_msg.edit_text(
        f"✅ عملیات با موفقیت انجام شد!\n\n"
        f"👥 کل کاربران: {total}\n"
        f"✅ اضافه شده: {added}\n"
        f"♻️ تکراری: {skipped}"
    )

    try:
        os.remove(file_path)
    except Exception:
        pass


@Client.on_message(filters.user(SUDO) & filters.command("adddata"))
async def Add_database_mem(bot: Client, msg: Message):
    if not msg.reply_to_message or not msg.reply_to_message.document:
        await msg.reply_text("⚠️ لطفاً روی فایل text ریپلای کنید.")
        return

    status_msg = await msg.reply_text("📥 در حال دانلود و پردازش فایل...")

    file_path = await msg.reply_to_message.download(file_name="users.txt")

    added = 0
    skipped = 0

    with open(file_path, "r", encoding="utf-8") as f:
        lines = [line.strip() for line in f if line.strip()]

    i = 0
    while i < len(lines):
        # رد کردن جداکننده
        if lines[i].startswith("="):
            i += 1
            continue

        try:
            user_id = lines[i]
            name = lines[i + 1]
            join_time = lines[i + 2]
        except IndexError:
            break

        i += 3

        # بررسی عددی بودن آیدی
        if not user_id.isdigit():
            skipped += 1
            continue

        user_id = int(user_id)
        username = "-"
        invited = 0

        # اگر قبلاً وجود نداشته باشه
        if not db.User_id(user_id):
            db.Add_User(
                name,
                user_id,
                username,
                invited,
                join_time
            )
            added += 1
        else:
            skipped += 1

    await status_msg.edit_text(
        f"✅ پردازش کامل شد\n\n"
        f"➕ کاربران اضافه‌شده: {added}\n"
        f"⛔️ کاربران تکراری / ردشده: {skipped}"
    )


@ApiClient.on_message(filters.user(SUDO) & filters.regex(r'^تنظیم جوین اجباری 🔒$'))
async def set_j(bot: Client, msg: Message):

    try:
        text=((await bot.ask(msg.from_user.id,f'<b>لطفا شناسه رو ارسال کنید !</b>',filters=filters.text,reply_markup=Buttons.Cancel,timeout=120)))
    except TimeoutError :pass

    if text.text == '❌ انصراف ❌':
        await bot.send_message(msg.from_user.id, f'سلام مدیر 💎\n🔧 از منوی زیر میتونید ربات را کنترل کنید 🔧', 
        reply_markup = Buttons.Management)

    try:
        b=((await bot.ask(msg.from_user.id,'<b>لطفا اسم دکمه رو ارسال کنید !</b>',filters=filters.text ,reply_markup=Buttons.Cancel,timeout=120)))
    except TimeoutError :pass

    if int(text.text) in SETTINGS['channel_ids']:
        await bot.send_message(msg.from_user.id,'در جوین اجباری ها موجود می باشد ⁉️')
    else:
        name = await bot.get_chat(int(text.text))

        SETTINGS['channel_link'][b.text] = name.invite_link
        SETTINGS['channel_ids'][int(text.text)] = name.invite_link
        save_settings()
        await bot.send_message(msg.from_user.id,f'➕ جوین اجباری جدید ✔️\n®️ نام : {name.title}\n©️شناسه : <code>{text.text}</code>\n➰ لینک :\n<code>{name.invite_link}</code>')


@ApiClient.on_message(filters.user(SUDO) & filters.regex(r'^حذف جوین اجباری 🔓$'))
async def del_jj(bot: Client, msg: Message):
    try:
        text=((await bot.ask(msg.from_user.id,f'<b>لطفا شناسه رو ارسال کنید !</b>',filters=filters.text,reply_markup=Buttons.Cancel,timeout=120)))
    except TimeoutError :pass

    try:
        b=((await bot.ask(msg.from_user.id,'<b>لطفا اسم دکمه رو ارسال کنید !</b>',filters=filters.text ,reply_markup=Buttons.Cancel,timeout=120)))
    except TimeoutError :pass

    if text.text == '❌ انصراف ❌':
        await bot.send_message(msg.from_user.id, f'سلام مدیر 💎\n🔧 از منوی زیر میتونید ربات را کنترل کنید 🔧', 
        reply_markup = Buttons.Management)
    try:
        name = await bot.get_chat(int(text.text))
        SETTINGS['channel_ids'].pop(int(text.text))
        SETTINGS['channel_link'].pop(b.text)
        save_settings()
        await bot.send_message(msg.from_user.id,f'➖ حذف جوین اجباری  ✔️\n®️ نام : {name.title}\n©️شناسه : <code>{text.text}</code>')

    except:
        await bot.send_message(msg.from_user.id, 'در جوین اجباری ها موجود نیست ⁉️')


@ApiClient.on_message(filters.user(SUDO) & filters.regex(r'^❌ انصراف ❌$'))
async def can_(bot: Client, msg: Message):
    await msg.reply('سلام مدیر 💎\n🔧 از منوی زیر میتونید ربات را کنترل کنید 🔧',
                    reply_markup = Buttons.Management )

from pyrogram import filters, enums, Client, errors
from pyrogram.types import Message, ChatPermissions
from utils.filters import check
from utils.clients import ApiClient
from utils.config import SETTINGS, SUDO, DATA_DIR, ZIP_NAME, BASE_DIR
from pickle import dump
from utils import Buttons
import asyncio
from os import remove as os_remove
import string, random as rnd, shutil, time as myTime, re, os, sys, pyrogram
from data.database import db
from bs4 import BeautifulSoup
import zipfile
import time

# اگر پوشه وجود نداشت، خودکار ساخته شود
os.makedirs(DATA_DIR, exist_ok=True)
#-----------------------------------------------------
def wFile(input):
    file = open(f"{input}", "w", encoding = "utf8")
    file.close()
#------------------------------------------------------
def save_settings():
    with open('settings.pkl', 'wb') as f:
        dump(SETTINGS, f)
#-----------------------------------------------------
@ApiClient.on_message(filters.user(SUDO) & filters.private & filters.command('backup'))
async def backup(bot: Client, msg: Message):
    wait_msg = await msg.reply('<b>⏳ لطفا منتظر بمانید ...</b>')
    user_id = msg.from_user.id
    async def progress(current, total):
        percent = current * 100 / total
        await wait_msg.edit_text(
            f"<b>📤 در حال آپلود...\n{percent:.1f}%</b>")
    await bot.send_document(
        user_id,
        "betdata.db",
        progress=progress)
    await wait_msg.edit_text("<b>📤 آپلود فایل دوم...</b>")
    await bot.send_document(
        user_id,
        "settings.pkl",
        progress=progress)
    await wait_msg.edit_text("<b>✅ بکاپ با موفقیت ارسال شد</b>")


@ApiClient.on_message(filters.user(SUDO) & filters.private & filters.regex('📊 وضعیت$'))
async def online_members(bot: Client, msg: Message):
    live, active, daily = db.online_stats()

    text = (
        "📊 **وضعیت کاربران آنلاین**\n\n"
        f"🟢 آنلاین لحظه‌ای: **{live or 0}**\n"
        f"🟡 کاربران فعال (۵ دقیقه): **{active or 0}**\n"
        f"🔵 کاربران امروز: **{daily or 0}**"
    )

    await msg.reply_text(text)
#-----------------------------------------------------
@ApiClient.on_message(filters.user(SUDO) & filters.private & filters.command("zip"))
async def file_zip(bot: Client, msg: Message):

    files = os.listdir(DATA_DIR)
    if not files:
        return await msg.reply("⚠️ هیچ فایلی برای زیپ کردن وجود ندارد.")

    status = await msg.reply("📦 در حال ساخت فایل ZIP ...")

    try:
        with zipfile.ZipFile(ZIP_NAME, "w", zipfile.ZIP_DEFLATED) as zipf:
            for file in files:
                file_path = os.path.join(DATA_DIR, file)
                if os.path.isfile(file_path):
                    zipf.write(file_path, arcname=file)

        await status.edit("📤 در حال ارسال فایل ZIP ...")

        await msg.reply_document(
            document=ZIP_NAME,
            caption="✅ فایل‌ها با موفقیت زیپ شدند."
        )

    except Exception as e:
        await status.edit(f"❌ خطا:\n`{e}`")

    finally:
        if os.path.exists(ZIP_NAME):
            os.remove(ZIP_NAME)

@ApiClient.on_message(filters.user(SUDO) & filters.private & filters.command('r'))
async def Reload(_, msg: Message):
    await msg.reply_text(f'<b>Reloaded !</b>')
    os.execl(sys.executable, sys.executable, *sys.argv)   


@ApiClient.on_message(filters.user(SUDO) & filters.reply & filters.regex(r'^/settext'))
async def set_btext_banere(bot: Client, msg: Message):
    SETTINGS['text_baner'] = msg.reply_to_message.id
    save_settings()
    await msg.reply_text(f'بنر زیرمجموعه ذخیره شد!')

@ApiClient.on_message(filters.user(SUDO) & filters.reply & filters.regex(r'^/setbn'))
async def set_link_bn(bot: Client, msg: Message):
    SETTINGS['link_baner'] = msg.reply_to_message.id
    save_settings()
    await msg.reply_text(f'<b>بنر زیرمجموعه گیری  با موفقیت ذخیره شد!</b>')

@ApiClient.on_message(filters.user(SUDO) & filters.regex(r'^/delbn'))
async def del_link_bn(bot: Client, msg: Message):
    SETTINGS['link_baner'] = 0
    save_settings()
    await msg.reply_text(f'<b>بنر زیرمجموعه گیری  با موفقیت پاک شد!</b>')


@ApiClient.on_message(filters.user(SUDO) & filters.reply & filters.regex(r'^/setform site$'))
async def set_link_site(bot: Client, msg: Message):
    SETTINGS['link_site'] = msg.reply_to_message.id
    save_settings()
    await msg.reply_text(f'<b>لینک سایت با موفقیت ذخیره شد!</b>')


@ApiClient.on_message(filters.user(SUDO) & filters.regex(r'^/delform site$'))
async def del_link_sitee(bot: Client, msg: Message):
    SETTINGS['link_site'] = 0
    save_settings()
    await msg.reply_text(f'<b>لینک سایت با موفقیت پاک شد!</b>')

@ApiClient.on_message(filters.user(SUDO) & filters.reply & filters.regex(r'^/setform shorbet$'))
async def set_shorbet_form(bot: Client, msg: Message):
    SETTINGS['vip_form'] = msg.reply_to_message.id
    save_settings()
    await msg.reply_text(f'<b>فرم شوربت ذخیره شد !</b>')


@ApiClient.on_message(filters.user(SUDO) & filters.regex(r'^/delform shorbet$'))
async def del_shorbet_form(bot: Client, msg: Message):
    SETTINGS['vip_form'] = 0
    save_settings()
    await msg.reply_text(f'<b>فرم شوربت پاک شد !</b>')


@ApiClient.on_message(filters.user(SUDO) & filters.reply & filters.regex(r'^/setform link$'))
async def set_nofilter_link_site(bot: Client, msg: Message):
    SETTINGS['no_fillter'] = msg.reply_to_message.id
    save_settings()
    await msg.reply_text(f'<b>لینک سایت بدون فیلتر با موفقیت ذخیره شد!</b>')


@ApiClient.on_message(filters.user(SUDO) &  filters.regex(r'^/delform link$'))
async def del_nofilter_link_site(bot: Client, msg: Message):
    SETTINGS['no_fillter'] = 0
    save_settings()
    await msg.reply_text(f'<b>لینک سایت بدون فیلتر با موفقیت پاک شد!</b>')

# @ApiClient.on_message(filters.user(SUDO) & filters.reply & filters.regex(r'^/setform vip$'))
# async def set_vip_form(bot: Client, msg: Message):
#     SETTINGS['vip_form'] = msg.reply_to_message.id
#     save_settings()
#     await msg.reply_text(f'<b>فرم وی آی پی ذخیره شد !</b>')


# @ApiClient.on_message(filters.user(SUDO) & filters.regex(r'^/delform vip$'))
# async def del_vip_form(bot: Client, msg: Message):
#     SETTINGS['vip_form'] = 0
#     save_settings()
#     await msg.reply_text(f'<b>فرم وی آی پی پاک شد !</b>')



@ApiClient.on_message(filters.user(SUDO) & filters.reply & filters.regex(r'^/setform fulltime$'))
async def set_football_form(bot: Client, msg: Message):
    SETTINGS['footbal_form'] = msg.reply_to_message.id
    save_settings()
    await msg.reply_text(f'<b>فرم نتیجه دقیق ذخیره شد !</b>')


@ApiClient.on_message(filters.user(SUDO) & filters.regex(r'^/delform fulltime$'))
async def del_football_form(bot: Client, msg: Message):
    SETTINGS['footbal_form'] = 0
    save_settings()
    await msg.reply_text(f'<b>فرم نتیجه دقیق پاک شد !</b>')


@ApiClient.on_message(filters.user(SUDO) & filters.reply & filters.regex(r'^/setform ourbots$'))
async def set_haki_form(bot: Client, msg: Message):
    SETTINGS['ourbots'] = msg.reply_to_message.id
    save_settings()
    await msg.reply_text(f'<b> لیست ربات ذخیره شد !</b>')


@ApiClient.on_message(filters.user(SUDO) & filters.regex(r'^/delform ourbots$'))
async def del_haki_form(bot: Client, msg: Message):
    SETTINGS['ourbots'] = 0
    save_settings()
    await msg.reply_text(f'<b> لیست ربات  پاک شد !</b>')



@ApiClient.on_message(filters.user(SUDO) & filters.private & filters.regex('اطلاعات 🔭$'))
async def bot_info(bot: Client, msg: Message):
    t = db.All_Data_Text()
    c = db.All_user_count()
    file_name = "Bot_sub_info.html"
    with open(file_name, "w", encoding="utf-8") as f:
        f.write(t)
    status_msg = await msg.reply_text("📤 در حال آپلود فایل...")
    start_time = time.time()
    async def progress(current, total):
        if total == 0:
            return
        percent = int(current * 100 / total)
        try:
            await status_msg.edit_text(
                f"📤 در حال آپلود فایل...\n"
                f"📊 پیشرفت: {percent}%")
        except:
            pass
    await bot.send_document(msg.chat.id,file_name,caption=f'👥 Count : {c}',progress=progress)
    await status_msg.delete()
    os.remove(file_name)
    
@ApiClient.on_message(filters.user(SUDO) & filters.private & filters.regex('نجوا 📩$'))
async def send_message_All_member(bot: Client, msg: Message):
    message = await bot.ask(msg.from_user.id, 'شما در حال ارسال پیام به تمام کاربرای ربات هستین !\nلطفا پیام خود را بفرستین !')
    x = 0

    a = db.All_Users()
    for i in a:
       for b in i:
            await message.copy(int(b))
            x += 1
    await msg.reply_text(f'پیام با موفقیت به {x} کاربرای ربات ارسال شد !')


@ApiClient.on_message(filters.user(SUDO) & filters.command(r'^s'))
async def set_je(bot: Client, msg: Message):
    res = msg.command[1]
    name = await bot.get_chat(int(res))
    if int(res) in SETTINGS['channel_ids']:
        msg.reply('در جوین اجباری ها موجود می باشد ⁉️')
    else:
        SETTINGS['channel_link'][name.title] = name.invite_link
        SETTINGS['channel_ids'][int(res)] = name.invite_link
        save_settings()
        await msg.reply_text(f'➕ جوین اجباری جدید ✔️\n®️ نام : {name.title}\n©️شناسه : <code>{res}</code>\n➰ لینک :\n<code>{name.invite_link}</code>')


@ApiClient.on_message(filters.user(SUDO) & filters.command(r'^d'))
async def det_je(bot: Client, msg: Message):
    res = msg.command[1]

    name = await bot.get_chat(int(res))

    try:
        SETTINGS['channel_ids'].pop(int(res))
        SETTINGS['channel_link'].pop(name.title)
        save_settings()
        await msg.reply_text(f'➖ حذف جوین اجباری  ✔️\n®️ نام : {name.title}\n©️شناسه : <code>{res}</code>')
    except:
        await msg.reply('در جوین اجباری ها موجود نیست ⁉️')


@ApiClient.on_message(filters.user(SUDO) & filters.command(r'^resetj'))
async def reset_join(bot: Client, msg: Message):

    SETTINGS['channel_link'].clear()
    SETTINGS['channel_ids'].clear()
    await msg.reply_text(f'تمام جوین اجباری ها با موفقیت حذف شدن !')


@Client.on_message(filters.user(SUDO) & filters.command("todata"))
async def Add_database(bot: Client, msg: Message):
    if not msg.reply_to_message or not msg.reply_to_message.document:
        await msg.reply_text("⚠️ لطفاً روی فایل HTML ریپلای کنید.")
        return
    file_path = await msg.reply_to_message.download(file_name="users.html")

    status_msg = await msg.reply_text("📥 در حال دانلود فایل HTML ...")

    from bs4 import BeautifulSoup
    import asyncio, os

    with open(file_path, "r", encoding="utf-8") as f:
        soup = BeautifulSoup(f, "lxml")

    # ✅ فقط کاربران معتبر
    valid_rows = []
    for tr in soup.find_all("tr"):
        tds = tr.find_all("td")
        if len(tds) == 5 and tds[1].get_text(strip=True).isdigit():
            valid_rows.append(tds)

    total = len(valid_rows)

    if total == 0:
        await status_msg.edit_text("❌ هیچ کاربر معتبری در فایل پیدا نشد.")
        return

    added = 0
    skipped = 0

    await status_msg.edit_text(
        f"✅ {total} کاربر شناسایی شد\n🚀 شروع ورود به دیتابیس..."
    )

    for i, cols in enumerate(valid_rows, start=1):
        name = cols[0].get_text(strip=True)
        user_id = int(cols[1].get_text(strip=True))
        username = cols[2].get_text(strip=True) or None
        invited = int(cols[3].get_text(strip=True) or 0)
        join_time = cols[4].get_text(strip=True)

        if not db.User_id(user_id):
            db.Add_User(name, user_id, username, invited, join_time)
            added += 1
        else:
            skipped += 1

        # ✅ درصد واقعی
        if i % 300 == 0 or i == total:
            percent = int((i / total) * 100)
            await status_msg.edit_text(
                f"🔄 در حال پردازش داده‌ها...\n\n"
                f"📊 پیشرفت: {percent}%\n"
                f"✅ اضافه شده: {added}\n"
                f"♻️ تکراری: {skipped}"
            )
            await asyncio.sleep(0.2)

    await status_msg.edit_text(
        f"✅ عملیات با موفقیت انجام شد!\n\n"
        f"👥 کل کاربران: {total}\n"
        f"✅ اضافه شده: {added}\n"
        f"♻️ تکراری: {skipped}"
    )

    try:
        os.remove(file_path)
    except Exception:
        pass


@Client.on_message(filters.user(SUDO) & filters.command("adddata"))
async def Add_database_mem(bot: Client, msg: Message):
    if not msg.reply_to_message or not msg.reply_to_message.document:
        await msg.reply_text("⚠️ لطفاً روی فایل text ریپلای کنید.")
        return

    status_msg = await msg.reply_text("📥 در حال دانلود و پردازش فایل...")

    file_path = await msg.reply_to_message.download(file_name="users.txt")

    added = 0
    skipped = 0

    with open(file_path, "r", encoding="utf-8") as f:
        lines = [line.strip() for line in f if line.strip()]

    i = 0
    while i < len(lines):
        # رد کردن جداکننده
        if lines[i].startswith("="):
            i += 1
            continue

        try:
            user_id = lines[i]
            name = lines[i + 1]
            join_time = lines[i + 2]
        except IndexError:
            break

        i += 3

        # بررسی عددی بودن آیدی
        if not user_id.isdigit():
            skipped += 1
            continue

        user_id = int(user_id)
        username = "-"
        invited = 0

        # اگر قبلاً وجود نداشته باشه
        if not db.User_id(user_id):
            db.Add_User(
                name,
                user_id,
                username,
                invited,
                join_time
            )
            added += 1
        else:
            skipped += 1

    await status_msg.edit_text(
        f"✅ پردازش کامل شد\n\n"
        f"➕ کاربران اضافه‌شده: {added}\n"
        f"⛔️ کاربران تکراری / ردشده: {skipped}"
    )


@ApiClient.on_message(filters.user(SUDO) & filters.regex(r'^تنظیم جوین اجباری 🔒$'))
async def set_j(bot: Client, msg: Message):

    try:
        text=((await bot.ask(msg.from_user.id,f'<b>لطفا شناسه رو ارسال کنید !</b>',filters=filters.text,reply_markup=Buttons.Cancel,timeout=120)))
    except TimeoutError :pass

    if text.text == '❌ انصراف ❌':
        await bot.send_message(msg.from_user.id, f'سلام مدیر 💎\n🔧 از منوی زیر میتونید ربات را کنترل کنید 🔧', 
        reply_markup = Buttons.Management)

    try:
        b=((await bot.ask(msg.from_user.id,'<b>لطفا اسم دکمه رو ارسال کنید !</b>',filters=filters.text ,reply_markup=Buttons.Cancel,timeout=120)))
    except TimeoutError :pass

    if int(text.text) in SETTINGS['channel_ids']:
        await bot.send_message(msg.from_user.id,'در جوین اجباری ها موجود می باشد ⁉️')
    else:
        name = await bot.get_chat(int(text.text))

        SETTINGS['channel_link'][b.text] = name.invite_link
        SETTINGS['channel_ids'][int(text.text)] = name.invite_link
        save_settings()
        await bot.send_message(msg.from_user.id,f'➕ جوین اجباری جدید ✔️\n®️ نام : {name.title}\n©️شناسه : <code>{text.text}</code>\n➰ لینک :\n<code>{name.invite_link}</code>')


@ApiClient.on_message(filters.user(SUDO) & filters.regex(r'^حذف جوین اجباری 🔓$'))
async def del_jj(bot: Client, msg: Message):
    try:
        text=((await bot.ask(msg.from_user.id,f'<b>لطفا شناسه رو ارسال کنید !</b>',filters=filters.text,reply_markup=Buttons.Cancel,timeout=120)))
    except TimeoutError :pass

    try:
        b=((await bot.ask(msg.from_user.id,'<b>لطفا اسم دکمه رو ارسال کنید !</b>',filters=filters.text ,reply_markup=Buttons.Cancel,timeout=120)))
    except TimeoutError :pass

    if text.text == '❌ انصراف ❌':
        await bot.send_message(msg.from_user.id, f'سلام مدیر 💎\n🔧 از منوی زیر میتونید ربات را کنترل کنید 🔧', 
        reply_markup = Buttons.Management)
    try:
        name = await bot.get_chat(int(text.text))
        SETTINGS['channel_ids'].pop(int(text.text))
        SETTINGS['channel_link'].pop(b.text)
        save_settings()
        await bot.send_message(msg.from_user.id,f'➖ حذف جوین اجباری  ✔️\n®️ نام : {name.title}\n©️شناسه : <code>{text.text}</code>')

    except:
        await bot.send_message(msg.from_user.id, 'در جوین اجباری ها موجود نیست ⁉️')


@ApiClient.on_message(filters.user(SUDO) & filters.regex(r'^❌ انصراف ❌$'))
async def can_(bot: Client, msg: Message):
    await msg.reply('سلام مدیر 💎\n🔧 از منوی زیر میتونید ربات را کنترل کنید 🔧',
                    reply_markup = Buttons.Management )

