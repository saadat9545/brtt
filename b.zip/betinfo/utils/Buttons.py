from pyrogram.types import InlineKeyboardMarkup, InlineKeyboardButton, ReplyKeyboardMarkup , InlineQueryResultArticle, InputTextMessageContent
from pyrogram.types.bots_and_keyboards import force_reply 

Start = ReplyKeyboardMarkup([['💥 دریافت فرم رایگان 💥'],
                                ['🟢 سایت مورد تایید جهت شرطبندی 🟢'],
                                ['💰 زیرمجموعه گیری و کسب درآمد 💰'],
                                ['🤖 سایر ربات‌های ما 🤖'],
                                ['💬 ارتباط با پشتیبانی 💬']],resize_keyboard =True)
                           

bet_form = ReplyKeyboardMarkup([['⚽️ نتیجه دقیق برای آپشن گیری‌ ⚽️'],
                                ['💯 شوربت | شرطبندی بدون باخت 💯'],
                                ['🔄 بازگشت 🔄']],resize_keyboard =True)


Site_link = ReplyKeyboardMarkup([['🔗 آدرس بدون فیلتر‌ 🔗'],
                                ['🔄 بازگشت 🔄']],resize_keyboard =True)                       


back_Bot = ReplyKeyboardMarkup([['🔄 بازگشت 🔄']],resize_keyboard =True)    

  

buy_cancell = ReplyKeyboardMarkup([['🔙 انصراف']],resize_keyboard =True)    


back_Bot = ReplyKeyboardMarkup([['🔄 بازگشت 🔄']],resize_keyboard =True)    

    

Support = lambda username: InlineKeyboardMarkup(
    [
        [InlineKeyboardButton('📞 پشتیبانی', url=f'https://t.me/{username}')]
    ]
    )

Link_bot =  ReplyKeyboardMarkup([['حساب من👤' , '🔗 لینک اختصاصی'],
                                 ['🔄 بازگشت 🔄']],resize_keyboard =True)   



Management = ReplyKeyboardMarkup([
                                ['نجوا 📩'],
                                ['اطلاعات 🔭', '📊 وضعیت'],
                                ['تنظیم جوین اجباری 🔒'],
                                ['حذف جوین اجباری 🔓'],
                                ['پنل اصلی ⚙️']],resize_keyboard =True)


Cancel=ReplyKeyboardMarkup([['❌ انصراف ❌']],resize_keyboard =True)
