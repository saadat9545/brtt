from pyrogram import filters, enums, Client, errors
from pyrogram.types import Message, ChatPermissions
from utils.filters import check, admin_cm
from utils.clients import ApiClient
from utils.config import SUDO
from utils import Buttons
from utils.config import SETTINGS, SUDO
from pickle import dump
import jdatetime as jdf
from os import remove as os_remove
import string, random as rnd, shutil, time as myTime, re, os, sys, pyrogram
from data.database import db

#-----------------------------------------------------
def wFile(input):
    file = open(f"{input}", "w", encoding = "utf8")
    file.close()
#------------------------------------------------------
def save_settings():
    with open('settings.pkl', 'wb') as f:
        dump(SETTINGS, f)
#-----------------------------------------------------
        
@ApiClient.on_message(filters.user(SUDO) & filters.private & filters.command('r'))
async def Reload(bot: Client, msg: Message):
    await msg.reply_text(f'<b>Reloaded !</b>')
    os.execl(sys.executable, sys.executable, *sys.argv)   

@ApiClient.on_message(filters.user(SUDO) & filters.private & filters.command('backup'))
async def backup(bot: Client, msg: Message):
    user_id = msg.from_user.id
    await bot.send_document(user_id, "betdata.db")
    await bot.send_document(user_id, "settings.pkl")



@ApiClient.on_message(filters.user(SUDO) & filters.private & filters.command('to'))
async def to_db(_, msg: Message):
    Date = jdf.date.today().strftime("%Y/%m/%d")

    for k, v in SETTINGS['Vip_Members'].items():
        db.Add_User(v, k,'-',0,Date)

    await msg.reply('ok')


@ApiClient.on_message(filters.user(SUDO) & filters.private & filters.command('zo'))
async def toz_db(_, msg: Message):
    Date = jdf.date.today().strftime("%Y/%m/%d")

    for k, v in SETTINGS['admins'].items():
        db.update_dataa(int(k), int(v))


    await msg.reply('ok')



@ApiClient.on_message(admin_cm & filters.reply & filters.regex(r'^/settext'))
async def set_btext_banere(bot: Client, msg: Message):
    SETTINGS['text_baner'] = msg.reply_to_message.id
    save_settings()
    await msg.reply_text(f'بنر زیرمجموعه ذخیره شد!')


@ApiClient.on_message(filters.user(SUDO) & filters.command(r'^s'))
async def set_je(bot: Client, msg: Message):
    res = msg.command[1]
    name = await bot.get_chat(int(res))
    if int(res) in SETTINGS['channel_ids']:
        msg.reply('در جوین اجباری ها موجود می باشد ⁉️')
    else:
        SETTINGS['channel_link'][name.title] = name.invite_link
        SETTINGS['channel_ids'][int(res)] = name.invite_link
        save_settings()
        await msg.reply_text(f'➕ جوین اجباری جدید ✔️\n®️ نام : {name.title}\n©️شناسه : <code>{res}</code>\n➰ لینک :\n<code>{name.invite_link}</code>')


@ApiClient.on_message(filters.user(SUDO) & filters.command(r'^d'))
async def det_je(bot: Client, msg: Message):
    res = msg.command[1]

    name = await bot.get_chat(int(res))

    try:
        SETTINGS['channel_ids'].pop(int(res))
        SETTINGS['channel_link'].pop(name.title)
        save_settings()
        await msg.reply_text(f'➖ حذف جوین اجباری  ✔️\n®️ نام : {name.title}\n©️شناسه : <code>{res}</code>')
    except:
        await msg.reply('در جوین اجباری ها موجود نیست ⁉️')


@ApiClient.on_message(filters.user(SUDO) & filters.command(r'^resetj'))
async def reset_join(bot: Client, msg: Message):

    SETTINGS['channel_link'].clear()
    SETTINGS['channel_ids'].clear()
    await msg.reply_text(f'تمام جوین اجباری ها با موفقیت حذف شدن !')


@ApiClient.on_message(admin_cm & filters.regex(r'^/delbn'))
async def del_link_bn(bot: Client, msg: Message):
    SETTINGS['link_baner'] = 0
    save_settings()
    await msg.reply_text(f'<b>بنر زیرمجموعه گیری  با موفقیت پاک شد!</b>')


@ApiClient.on_message(admin_cm & filters.reply & filters.regex(r'^/setform ourbots$'))
async def set_basketball_form(bot: Client, msg: Message):
    SETTINGS['ourbots'] = msg.reply_to_message.id
    save_settings()
    await msg.reply_text(f'<b>لیست ربات  ذخیره شد !</b>')


@ApiClient.on_message(admin_cm & filters.regex(r'^/delform ourbots$'))
async def del_basketball_form(bot: Client, msg: Message):
    SETTINGS['ourbots'] = 0
    save_settings()
    await msg.reply_text(f'<b> لیست ربات پاک شد !</b>')


@ApiClient.on_message(admin_cm & filters.reply & filters.regex(r'^/setaff$'))
async def set_user_suub(bot: Client, msg: Message):
    SETTINGS['join_tx'] = msg.reply_to_message.text
    save_settings()
    await msg.reply_text(f'<b>متن اطلاع رسانی کاربر تنظیم شد !</b>')


@ApiClient.on_message(admin_cm & filters.regex(r'^/delaff$'))
async def del_user_sub(bot: Client, msg: Message):
    SETTINGS['join_tx'] = ''
    save_settings()
    await msg.reply_text(f'<b>متن اطلاع رسانی کاربر حذف شد !</b>')


@ApiClient.on_message(admin_cm & filters.reply & filters.regex(r'^/setbanner$'))
async def set_baner_site(bot: Client, msg: Message):
    SETTINGS['site_baner'] = msg.reply_to_message.id
    save_settings()
    await msg.reply_text(f'بنر سایت ذخیره شد!')


@ApiClient.on_message(admin_cm & filters.reply & filters.regex(r'^/setform link$'))
async def set_link_site(bot: Client, msg: Message):
    SETTINGS['link_site'] = msg.reply_to_message.id
    save_settings()
    await msg.reply_text(f'<b>لینک سایت با موفقیت ذخیره شد!</b>')


@ApiClient.on_message(admin_cm & filters.reply & filters.regex(r'^/setbn'))
async def set_link_bn(bot: Client, msg: Message):
    SETTINGS['link_baner'] = msg.reply_to_message.id
    save_settings()
    await msg.reply_text(f'<b>بنر زیرمجموعه گیری  با موفقیت ذخیره شد!</b>')


@ApiClient.on_message(admin_cm & filters.regex(r'^/dellink$'))
async def del_link_site(bot: Client, msg: Message):
    SETTINGS['link_site'] = 0
    save_settings()
    await msg.reply_text(f'<b>لینک سایت با موفقیت پاک شد!</b>')


@ApiClient.on_message(admin_cm & filters.reply & filters.regex(r'^/setform baseball$'))
async def set_basball_form(bot: Client, msg: Message):
    SETTINGS['baseball'] = msg.reply_to_message.id
    save_settings()
    await msg.reply_text(f'<b>فرم بیسبال ذخیره شد !</b>')


@ApiClient.on_message(admin_cm & filters.regex(r'^/delform baseball$'))
async def del_basball_form(bot: Client, msg: Message):
    SETTINGS['baseball'] = 0
    save_settings()
    await msg.reply_text(f'<b>فرم بیسبال پاک شد !</b>')


@ApiClient.on_message(admin_cm & filters.reply & filters.regex(r'^/setform list$'))
async def set_daily_form(bot: Client, msg: Message):
    SETTINGS['daily_form'] = msg.reply_to_message.id
    save_settings()
    await msg.reply_text(f'<b>فرم روزانه ذخیره شد !</b>')


@ApiClient.on_message(admin_cm & filters.regex(r'^/delform list$'))
async def del_daily_form(bot: Client, msg: Message):
    SETTINGS['daily_form'] = 0
    save_settings()
    await msg.reply_text(f'<b>فرم روزانه پاک شد !</b>')


@ApiClient.on_message(admin_cm & filters.reply & filters.regex(r'^/setform fulltime$'))
async def set_fulltime_form(bot: Client, msg: Message):
    SETTINGS['fulltime'] = msg.reply_to_message.id
    save_settings()
    await msg.reply_text(f'<b>فرم نتیجه دقیق برای آپشن گیری ذخیره شد !</b>')


@ApiClient.on_message(admin_cm & filters.regex(r'^/delform fulltime$'))
async def del_fulltime_form(bot: Client, msg: Message):
    SETTINGS['fulltime'] = 0
    save_settings()
    await msg.reply_text(f'<b>فرم نتیجه دقیق برای آپشن گیری پاک شد !</b>')


@ApiClient.on_message(admin_cm & filters.reply & filters.regex(r'^/setform basket$'))
async def set_over_form(bot: Client, msg: Message):
    SETTINGS['over'] = msg.reply_to_message.id
    save_settings()
    await msg.reply_text(f'<b>فرم  بسکتبال ذخیره شد !</b>')


@ApiClient.on_message(admin_cm & filters.regex(r'^/delform basket$'))
async def del_over_form(bot: Client, msg: Message):
    SETTINGS['over'] = 0
    save_settings()
    await msg.reply_text(f'<b>فرم بسکتبال پاک شد !</b>')


@ApiClient.on_message(admin_cm & filters.reply & filters.regex(r'^/setform single$'))
async def set_single_form(bot: Client, msg: Message):
    SETTINGS['single'] = msg.reply_to_message.id
    save_settings()
    await msg.reply_text(f'<b>فرم سینگل ذخیره شد !</b>')


@ApiClient.on_message(admin_cm & filters.regex(r'^/delform single$'))
async def del_single_form(bot: Client, msg: Message):
    SETTINGS['single'] = 0
    save_settings()
    await msg.reply_text(f'<b>فرم سینگل پاک شد !</b>')


@ApiClient.on_message(admin_cm & filters.reply & filters.regex(r'^/setform acanner$'))
async def set_acanner_form(bot: Client, msg: Message):
    SETTINGS['acanner'] = msg.reply_to_message.id
    save_settings()
    await msg.reply_text(f'<b>فرم اسکنر ذخیره شد !</b>')


@ApiClient.on_message(admin_cm & filters.regex(r'^/delform acanner$'))
async def del_acanner_form(bot: Client, msg: Message):
    SETTINGS['acanner'] = 0
    save_settings()
    await msg.reply_text(f'<b>فرم اسکنر پاک شد !</b>')


@ApiClient.on_message(admin_cm & filters.reply & filters.regex(r'^/setform acanner$'))
async def set_acanner_form(bot: Client, msg: Message):
    SETTINGS['acanner'] = msg.reply_to_message.id
    save_settings()
    await msg.reply_text(f'<b>فرم اسکنر ذخیره شد !</b>')


@ApiClient.on_message(admin_cm & filters.regex(r'^/delform acanner$'))
async def del_acanner_form(bot: Client, msg: Message):
    SETTINGS['acanner'] = 0
    save_settings()
    await msg.reply_text(f'<b>فرم اسکنر پاک شد !</b>')


@ApiClient.on_message(admin_cm & filters.reply & filters.regex(r'^/setform tennis$'))
async def set_tennis_form(bot: Client, msg: Message):
    SETTINGS['tennis'] = msg.reply_to_message.id
    save_settings()
    await msg.reply_text(f'<b>فرم تنیس ذخیره شد !</b>')


@ApiClient.on_message(admin_cm & filters.regex(r'^/delform tennis$'))
async def del_tennis_form(bot: Client, msg: Message):
    SETTINGS['tennis'] = 0
    save_settings()
    await msg.reply_text(f'<b>فرم تنیس پاک شد !</b>')


@ApiClient.on_message(admin_cm & filters.reply & filters.regex(r'^/setform haki$'))
async def set_haki_form(bot: Client, msg: Message):
    SETTINGS['haki'] = msg.reply_to_message.id
    save_settings()
    await msg.reply_text(f'<b>فرم هاکی ذخیره شد !</b>')


@ApiClient.on_message(admin_cm & filters.regex(r'^/delform haki$'))
async def del_haki_form(bot: Client, msg: Message):
    SETTINGS['haki'] = 0
    save_settings()
    await msg.reply_text(f'<b>فرم هاکی پاک شد !</b>')
