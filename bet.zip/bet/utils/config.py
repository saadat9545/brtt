from os.path import isfile
from pickle import load
from pyrogram import Client

API_ID = 15587752
API_HASH = '56c25355a160a391fdceb7f82d6a6197'
SUDO = [5823435734, 1009678891]
channel = [-1001855286455]
BOT_TOKEN = '6011952697:AAFW5s-WmGyj94MMBSlR5-dxsCkuQ6X_hVM'
LINKS = []

class Clients:
    api: Client = None


if isfile('settings.pkl'):
    with open('settings.pkl', 'rb') as f:
        SETTINGS = load(f)
else:
    SETTINGS = {
        'channel_ids': {},
        'channel_link': {},
        'baseball': 0,
        'fulltime': 0,
        'halftime': 0,
        'over': 0,
        'single': 0,
        'acanner': 0,
        'mix2': 0,
        'mix6': 0,
        'tennis': 0,
        'haki': 0,
        'site_baner': 0,
        'link_site': 0,
        'link_baner': 0,
        'daily_form': 0,
        'Sup_admin': "",
        'join_tx': "",

    }
