  #

import pathlib
import logging
import sqlite3 as db
from tabulate import tabulate
import datetime
import time
class Database:


    def __init__(self) -> None:    
        self.con = db.connect(f"betdata.db" , detect_types=db.PARSE_DECLTYPES, check_same_thread = False)
        self.c=self.con.cursor()#banner INT 
        self.c.execute('CREATE TABLE IF NOT EXISTS Users (Name TEXT , User_id INT PRIMARY KEY , Username TEXT, Invited INT, Join_time TEXT, last_seen INT )')
        # self.c.execute("""ALTER TABLE Users ADD COLUMN last_seen INTEGER""")
        self.con.commit()
        print('DataBase Has Successfully Loaded') 
    
    
    def Add_User(self, data1, data2, data3, data4, data5) -> bool:

        self.c.execute(
            "INSERT OR IGNORE INTO Users VALUES(? ,?, ?, ?, ?);", [data1, data2, data3, data4, data5]
        )
        self.con.commit()
        return True


    def User_id(self, user_id):
        query = 'SELECT User_id FROM Users WHERE User_id = ?'
        self.c.execute(query, [user_id])
        rows = self.c.fetchone()
        return rows
    def update_last_seen(self, user_id):
        now = int(time.time())

        self.c.execute("""
            INSERT INTO Users (User_id, last_seen)
            VALUES (?, ?)
            ON CONFLICT(User_id)
            DO UPDATE SET last_seen = excluded.last_seen
        """, (user_id, now))

        self.con.commit()

    def online_stats(self, live=60, active=300, daily=86400):
        now = int(time.time())

        self.c.execute("""
            SELECT
                SUM(last_seen >= ?) AS live,
                SUM(last_seen >= ?) AS active,
                SUM(last_seen >= ?) AS daily
            FROM Users
        """, (now-live, now-active, now-daily))

        return self.c.fetchone()


    # def All_Data_Text(self) -> str:
    #     Text='--------------❈ 𝐁𝐨𝐭 𝐢𝐧𝐟𝐨 ❈---------------\n\n'
    #     Tabels={'Users':['Name','User_id','Username','Invited', 'Date']}
    #     for i in Tabels :
    #         Data=self.c.execute(f'SELECT * FROM {i}').fetchall()
    #         tab=tabulate(Data , Tabels[i],  tablefmt="grid")
    #         Text+=f"{tab} \n \n "
    #     return Text
    

    def User_info(self, user_id):
        query = 'SELECT name,username,Invited,Join_time FROM Users WHERE User_id = ?'
        self.c.execute(query, [user_id])
        rows = self.c.fetchone()
        self.con.commit()        
        text = f'✦ نام : {rows[0]}\n✦ یوزرنیم : {rows[1]}\n✦ تعداد دعوت به ربات : {rows[2]}\n✦ تاریخ عضویت در ربات : {rows[3]}'
        return text

    def User_information(self, user_id):
        query = 'SELECT name,username,Invited,Join_time FROM Users WHERE User_id = ?'
        self.c.execute(query, [user_id])
        rows = self.c.fetchone()
        self.con.commit()        
        text = (f'[✏️] اسم کاربر :  {rows[0]}\n'
                f'[🖇] آیدی عددی : <code>{user_id}</code>\n'
                f'[💠] یوزرنیم : <code>{rows[1]}</code>\n'
                f'[♟] تعداد زیر مجموعه : <code>{rows[2]}</code>\n'
                f'[⏳] تاریخ عضویت در ربات : <code>{rows[3]}</code>')

        return text
    
    def update_data(self, user_id):
        query = f"UPDATE Users SET Invited=Invited +{1} WHERE User_id = ?;"
        self.c.execute(query, [user_id])
        self.con.commit()
        return True


    
    def All_Users(self):
        self.c.execute('SELECT User_id FROM Users')
        rows=self.c.fetchall()
        return rows
   
   
    def All_user_count(self) -> int:
        x = self.c.execute(f'SELECT COUNT(*) FROM Users')
        count = x.fetchall()[0][0]
        return count

    def select_invited(self, user_id):
        query = 'SELECT Invited FROM Users WHERE User_id = ?'
        self.c.execute(query, [user_id])
        rows = self.c.fetchone()
        self.con.commit
        return rows[0]
    



    def All_Data_Text(self) -> str:
        import json  # برای تبدیل داده‌ها به JSON معتبر

        html_text = '''
        <!DOCTYPE html>
        <html lang="fa" dir="rtl">
        <head>
            <meta charset="UTF-8">
            <meta name="viewport" content="width=device-width, initial-scale=1.0">
            <meta name="description" content="صفحه حرفه‌ای نمایش اطلاعات کاربران ربات با فیلترها، صفحه‌بندی و طراحی خفن">
            <title>اطلاعات ربات</title>
            <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css" integrity="sha512-iecdLmaskl7CVkqkXNQ/ZH/XLlvWZOJyj7Yy7tcenmpD1ypASozpmT/E0iPtmFIB46ZmdtAc9eNBvH0H/ZpiBw==" crossorigin="anonymous" referrerpolicy="no-referrer" />
            
            <style>
                @import url('https://fonts.googleapis.com/css2?family=Vazirmatn:wght@300;400;500;600;700&display=swap');

                :root {
                    --primary-color: #00e6b8;
                    --secondary-color: #00ffcc;
                    --accent-color: #ff00ff;
                    --bg-gradient: linear-gradient(135deg, rgba(33,33,33,1) 0%, rgba(74,74,74,1) 50%, rgba(33,33,33,1) 100%);
                    --glass-bg: rgba(255,255,255,0.05);
                    --glass-border: rgba(255,255,255,0.1);
                    --text-color: #fff;
                    --shadow-color: rgba(0,0,0,0.5);
                    --blur-amount: 15px;
                    --transition-speed: 0.4s;
                    --disabled-color: #555;
                    --hover-glow: 0 0 15px var(--primary-color);
                }

                * {
                    margin: 0;
                    padding: 0;
                    box-sizing: border-box;
                }

                body {
                    font-family: 'Vazirmatn', sans-serif;
                    background: var(--bg-gradient);
                    color: var(--text-color);
                    min-height: 100vh;
                    display: flex;
                    justify-content: center;
                    align-items: flex-start;
                    padding: 20px;
                    overflow-x: hidden;
                    position: relative;
                }

                body::before {
                    content: '';
                    position: absolute;
                    top: 0;
                    left: 0;
                    width: 100%;
                    height: 100%;
                    background: radial-gradient(circle, rgba(0,230,184,0.1) 0%, transparent 70%);
                    z-index: -1;
                }

                .glass-container {
                    width: 100%;
                    max-width: 1400px;
                    background: var(--glass-bg);
                    border-radius: 25px;
                    padding: 50px;
                    box-shadow: 0 10px 40px var(--shadow-color);
                    backdrop-filter: blur(var(--blur-amount));
                    -webkit-backdrop-filter: blur(var(--blur-amount));
                    border: 1px solid var(--glass-border);
                    animation: fadeIn 1s ease-out;
                    margin: 60px auto;
                    position: relative;
                    overflow: hidden;
                }

                .glass-container::before {
                    content: '';
                    position: absolute;
                    top: -50%;
                    left: -50%;
                    width: 200%;
                    height: 200%;
                    background: radial-gradient(circle, rgba(255,255,255,0.05) 0%, transparent 70%);
                    animation: rotate 30s linear infinite;
                    z-index: -1;
                }

                @keyframes rotate {
                    from { transform: rotate(0deg); }
                    to { transform: rotate(360deg); }
                }

                @keyframes fadeIn {
                    from { opacity: 0; transform: translateY(60px) scale(0.95); }
                    to { opacity: 1; transform: translateY(0) scale(1); }
                }

                h1 {
                    text-align: center;
                    margin-bottom: 40px;
                    font-weight: 700;
                    font-size: 2.5rem;
                    color: var(--primary-color);
                    text-shadow: var(--hover-glow);
                    letter-spacing: 2px;
                    position: relative;
                }

                h1::after {
                    content: '';
                    position: absolute;
                    bottom: -10px;
                    left: 50%;
                    transform: translateX(-50%);
                    width: 100px;
                    height: 2px;
                    background: linear-gradient(90deg, transparent, var(--secondary-color), transparent);
                }

                .stats {
                    text-align: center;
                    margin-bottom: 20px;
                    font-size: 16px;
                    color: var(--secondary-color);
                    animation: fadeIn 1.5s;
                }

                .filter-container {
                    display: flex;
                    flex-wrap: wrap;
                    gap: 15px;
                    margin-bottom: 30px;
                    justify-content: center;
                    position: relative;
                }

                .filter-group {
                    display: flex;
                    flex-direction: column;
                    min-width: 200px;
                    position: relative;
                }

                .filter-group label {
                    font-size: 14px;
                    margin-bottom: 5px;
                    color: var(--secondary-color);
                }

                .filter-input {
                    padding: 12px 15px;
                    border: none;
                    border-radius: 8px;
                    background: rgba(255,255,255,0.1);
                    color: var(--text-color);
                    font-size: 14px;
                    outline: none;
                    transition: all var(--transition-speed);
                }

                .filter-input:focus {
                    background: rgba(255,255,255,0.2);
                    box-shadow: var(--hover-glow);
                }

                .search-container {
                    position: relative;
                    width: 100%;
                    max-width: 400px;
                    margin: 0 auto 20px;
                }

                #searchInput {
                    width: 100%;
                    padding: 15px 45px 15px 20px;
                    border: none;
                    border-radius: 10px;
                    background: rgba(255,255,255,0.15);
                    color: var(--text-color);
                    font-size: 16px;
                    outline: none;
                    transition: all var(--transition-speed);
                }

                #searchInput:focus {
                    background: rgba(255,255,255,0.25);
                    box-shadow: var(--hover-glow);
                }

                #searchInput::placeholder {
                    color: rgba(255,255,255,0.6);
                }

                .search-icon {
                    position: absolute;
                    right: 15px;
                    top: 50%;
                    transform: translateY(-50%);
                    color: rgba(255,255,255,0.7);
                    font-size: 20px;
                    transition: color var(--transition-speed);
                }

                #searchInput:focus + .search-icon {
                    color: var(--primary-color);
                }

                .reset-button {
                    background: rgba(255,255,255,0.08);
                    border: 1px solid var(--glass-border);
                    color: var(--text-color);
                    padding: 12px 20px;
                    border-radius: 8px;
                    cursor: pointer;
                    transition: all var(--transition-speed);
                    font-size: 14px;
                    display: flex;
                    align-items: center;
                    gap: 5px;
                    margin: 10px auto 0;
                    max-width: 200px;
                }

                .reset-button:hover {
                    background: var(--accent-color);
                    color: #000;
                    box-shadow: var(--hover-glow);
                }

                .table-wrapper {
                    overflow-x: auto;
                    border-radius: 15px;
                    background: rgba(0,0,0,0.15);
                    margin-bottom: 30px;
                    box-shadow: 0 5px 20px rgba(0,0,0,0.2);
                }

                table {
                    width: 100%;
                    border-collapse: collapse;
                    min-width: 900px;
                }

                thead {
                    background: linear-gradient(90deg, var(--primary-color) 0%, var(--secondary-color) 100%);
                    color: #000;
                }

                th, td {
                    padding: 15px 20px;
                    text-align: center;
                    font-size: 15px;
                    border-bottom: 1px solid var(--glass-border);
                    transition: all var(--transition-speed);
                }

                th {
                    font-weight: 600;
                    position: sticky;
                    top: 0;
                    z-index: 2;
                    text-shadow: 0 1px 2px rgba(0,0,0,0.3);
                }

                tbody tr {
                    background: linear-gradient(90deg, rgba(255,255,255,0.02) 0%, rgba(255,255,255,0.08) 100%);
                    transition: transform var(--transition-speed), box-shadow var(--transition-speed);
                }

                tbody tr:hover {
                    transform: translateY(-2px) scale(1.01);
                    box-shadow: var(--hover-glow);
                    background: linear-gradient(90deg, rgba(255,255,255,0.1) 0%, rgba(255,255,255,0.15) 100%);
                }

                .copyable {
                    cursor: pointer;
                    position: relative;
                }

                .copyable:hover::after {
                    content: 'کپی';
                    position: absolute;
                    bottom: -20px;
                    left: 50%;
                    transform: translateX(-50%);
                    background: var(--primary-color);
                    color: #000;
                    padding: 5px 10px;
                    border-radius: 5px;
                    font-size: 12px;
                    opacity: 0.9;
                    z-index: 10;
                }

                .no-result {
                    text-align: center;
                    padding: 50px;
                    color: #aaa;
                    font-size: 20px;
                    display: none;
                    animation: fadeIn 0.5s;
                    text-shadow: 0 0 5px var(--accent-color);
                }

                .pagination {
                    display: flex;
                    justify-content: center;
                    align-items: center;
                    flex-wrap: wrap;
                    gap: 8px;
                    margin-top: 20px;
                }

                .pagination button {
                    background: rgba(255,255,255,0.08);
                    border: 1px solid var(--glass-border);
                    color: var(--text-color);
                    padding: 10px 15px;
                    border-radius: 50px;
                    cursor: pointer;
                    transition: all var(--transition-speed);
                    font-size: 14px;
                    min-width: 40px;
                }

                .pagination button:hover {
                    background: var(--primary-color);
                    color: #000;
                    box-shadow: var(--hover-glow);
                }

                .pagination button.active {
                    background: var(--secondary-color);
                    color: #000;
                    font-weight: bold;
                    box-shadow: var(--hover-glow);
                }

                .pagination button:disabled {
                    background: rgba(255,255,255,0.03);
                    color: var(--disabled-color);
                    cursor: not-allowed;
                }

                @media (max-width: 1024px) {
                    .glass-container {
                        padding: 30px;
                        margin: 40px auto;
                    }

                    h1 {
                        font-size: 2rem;
                    }

                    .filter-container {
                        display: grid;
                        grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
                        gap: 15px;
                    }

                    .filter-group {
                        width: 100%;
                    }

                    .reset-button {
                        grid-column: span 2;
                        justify-self: center;
                        max-width: 200px;
                    }
                }

                @media (max-width: 768px) {
                    .glass-container {
                        padding: 20px;
                        margin: 20px auto;
                    }

                    h1 {
                        font-size: 1.8rem;
                    }

                    th, td {
                        padding: 10px 12px;
                        font-size: 13px;
                    }

                    .pagination {
                        gap: 5px;
                        justify-content: space-around;
                    }

                    .pagination button {
                        padding: 8px 12px;
                        font-size: 13px;
                        flex-grow: 1;
                    }

                    .search-container {
                        max-width: 100%;
                    }

                    .reset-button {
                        grid-column: span 1;
                        width: 100%;
                    }
                }

                @media (max-width: 480px) {
                    h1 {
                        font-size: 1.5rem;
                    }

                    th, td {
                        padding: 8px 10px;
                        font-size: 12px;
                    }

                    .table-wrapper {
                        margin: 0 -20px;
                        padding: 0 20px;
                        overflow-x: scroll;
                    }

                    table {
                        min-width: 600px;
                    }

                    .pagination button {
                        padding: 6px 10px;
                        font-size: 12px;
                        min-width: 35px;
                    }

                    .filter-container {
                        grid-template-columns: 1fr;
                    }

                    .reset-button {
                        margin-top: 10px;
                    }
                }
            </style>
        </head>
        <body>
            <div class="glass-container">
                <h1><i class="fa-solid fa-robot"></i> اطلاعات ربات <i class="fa-solid fa-robot"></i></h1>
                <div class="stats" id="stats">تعداد کاربران: 0 (فیلترشده: 0)</div>
                <div class="search-container">
                    <input type="text" id="searchInput" oninput="applyFilters()" placeholder="جستجو بر اساس نام، شناسه، آیدی...">
                    <i class="fa-solid fa-magnifying-glass search-icon"></i>
                </div>
                <div class="filter-container">
                    <div class="filter-group">
                        <label>حداقل تعداد دعوت</label>
                        <input type="number" id="minInvites" class="filter-input" min="0" oninput="applyFilters()" placeholder="حداقل">
                    </div>
                    <div class="filter-group">
                        <label>حداکثر تعداد دعوت</label>
                        <input type="number" id="maxInvites" class="filter-input" min="0" oninput="applyFilters()" placeholder="حداکثر">
                    </div>
                    <div class="filter-group">
                        <label>تاریخ عضویت از (شمسی YYYY/MM/DD)</label>
                        <input type="text" id="startDate" class="filter-input" oninput="applyFilters()" placeholder="YYYY/MM/DD">
                    </div>
                    <div class="filter-group">
                        <label>تاریخ عضویت تا (شمسی YYYY/MM/DD)</label>
                        <input type="text" id="endDate" class="filter-input" oninput="applyFilters()" placeholder="YYYY/MM/DD">
                    </div>
                    <button class="reset-button" onclick="resetFilters()"><i class="fa-solid fa-trash-can"></i> پاک کردن فیلترها</button>
                </div>
                <div class="table-wrapper">
                    <table id="dataTable">
                        <thead>
                            <tr>
                                <th><i class="fa-solid fa-hashtag"></i> شماره</th>
                                <th><i class="fa-solid fa-user"></i> نام</th>
                                <th><i class="fa-solid fa-id-card"></i> شناسه</th>
                                <th><i class="fa-solid fa-at"></i> آیدی</th>
                                <th><i class="fa-solid fa-users"></i> تعداد دعوت</th>
                                <th><i class="fa-solid fa-calendar-days"></i> تاریخ عضویت</th>
                            </tr>
                        </thead>
                        <tbody id="tableBody">
                        </tbody>
                    </table>
                </div>
                <div class="no-result" id="noResult"><i class="fa-solid fa-face-sad-tear"></i> هیچ نتیجه‌ای یافت نشد</div>
                <div class="pagination" id="pagination"></div>
            </div>
            <script>
                const allData = ''' + json.dumps([list(row) for row in self.c.execute('SELECT * FROM Users').fetchall()]) + ''';

                let filteredData = [...allData];
                let currentPage = 1;
                const rowsPerPage = 50;
                const maxVisiblePages = 5;

                function jalaliToGregorian(jy, jm, jd) {
                    jy = parseInt(jy);
                    jm = parseInt(jm);
                    jd = parseInt(jd);

                    if (isNaN(jy) || isNaN(jm) || isNaN(jd) || jy < 1300 || jy > 1500 || jm < 1 || jm > 12 || jd < 1 || jd > 31) return null;

                    const isLeapJalali = ((jy % 33) % 4 === 1 || (jy % 33) === 0);
                    const daysInJalaliMonth = [31, 31, 31, 31, 31, 31, 30, 30, 30, 30, 30, isLeapJalali ? 30 : 29];
                    if (jd > daysInJalaliMonth[jm - 1]) return null;

                    jy += 1595;
                    let days = -355668 + (365 * jy) + (Math.floor(jy / 33) * 8) + Math.floor(((jy % 33) + 3) / 4) + jd + ((jm < 7) ? (jm - 1) * 31 : ((jm - 7) * 30) + 186);

                    let gy = 400 * Math.floor(days / 146097);
                    days %= 146097;
                    if (days > 36524) {
                        gy += 100 * Math.floor(--days / 36524);
                        days %= 36524;
                        if (days >= 365) days++;
                    }
                    gy += 4 * Math.floor(days / 1461);
                    days %= 1461;
                    if (days > 365) {
                        gy += Math.floor((days - 1) / 365);
                        days = (days - 1) % 365;
                    }
                    let gd = days + 1;
                    const sal_a = [0, 31, ((gy % 4 === 0 && gy % 100 !== 0) || (gy % 400 === 0)) ? 29 : 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31];
                    let gm = 0;
                    for (gm = 0; gm < 13 && gd > sal_a[gm]; gm++) gd -= sal_a[gm];

                    return new Date(gy, gm - 1, gd);
                }

                function parseJalaliToDate(dateStr) {
                    if (!dateStr) return null;
                    dateStr = dateStr.replace(/-/g, '/');
                    const parts = dateStr.split('/');
                    if (parts.length !== 3) return null;
                    const [jy, jm, jd] = parts.map(p => parseInt(p, 10));
                    return jalaliToGregorian(jy, jm, jd);
                }

                function formatJalali(dateStr) {
                    if (!dateStr) return 'نامشخص';
                    return dateStr.replace(/-/g, '/');
                }

                function applyFilters() {
                    const search = document.getElementById('searchInput').value.trim().normalize('NFC').toLowerCase();
                    const minInvites = parseInt(document.getElementById('minInvites').value, 10) || 0;
                    const maxInvites = parseInt(document.getElementById('maxInvites').value, 10) || Infinity;
                    const startDateInput = document.getElementById('startDate').value.trim();
                    const endDateInput = document.getElementById('endDate').value.trim();

                    let startDate = parseJalaliToDate(startDateInput);
                    if (startDate) startDate.setHours(0, 0, 0, 0);
                    else startDate = new Date(0);

                    let endDate = parseJalaliToDate(endDateInput);
                    if (endDate) endDate.setHours(23, 59, 59, 999);
                    else endDate = new Date(8640000000000000);

                    filteredData = allData.filter(row => {
                        const searchMatch = row.some(cell => {
                            const cellStr = String(cell).normalize('NFC').toLowerCase();
                            return cellStr.includes(search);
                        });

                        const invites = parseInt(row[3], 10);
                        const invitesMatch = !isNaN(invites) && invites >= minInvites && invites <= maxInvites;

                        const joinDateStr = row[4] ? formatJalali(row[4]) : '';
                        let joinDate = parseJalaliToDate(joinDateStr);
                        if (joinDate) joinDate.setHours(0, 0, 0, 0);
                        const dateMatch = (joinDate && joinDate >= startDate && joinDate <= endDate);

                        return searchMatch && invitesMatch && dateMatch;
                    });

                    currentPage = 1;
                    renderTable();
                    updateStats();
                }

                function resetFilters() {
                    document.getElementById('searchInput').value = '';
                    document.getElementById('minInvites').value = '';
                    document.getElementById('maxInvites').value = '';
                    document.getElementById('startDate').value = '';
                    document.getElementById('endDate').value = '';
                    filteredData = [...allData];
                    currentPage = 1;
                    renderTable();
                    updateStats();
                }

                function renderTable() {
                    const tableBody = document.getElementById('tableBody');
                    tableBody.innerHTML = '';

                    const start = (currentPage - 1) * rowsPerPage;
                    const end = start + rowsPerPage;
                    const pageData = filteredData.slice(start, end);

                    if (pageData.length === 0) {
                        document.getElementById('noResult').style.display = 'block';
                        document.getElementById('pagination').style.display = 'none';
                        return;
                    } else {
                        document.getElementById('noResult').style.display = 'none';
                        document.getElementById('pagination').style.display = 'flex';
                    }

                    pageData.forEach((row, index) => {
                        const tr = document.createElement('tr');
                        const rowNum = start + index + 1;
                        tr.innerHTML = `
                            <td>${rowNum}</td>
                            <td>${row[0] || 'نامشخص'}</td>
                            <td class="copyable" onclick="copyToClipboard('${row[1] || ''}')">${row[1] || 'نامشخص'}</td>
                            <td>${row[2] || 'نامشخص'}</td>
                            <td>${row[3] || 0}</td>
                            <td>${formatJalali(row[4])}</td>
                        `;
                        tableBody.appendChild(tr);
                    });

                    renderPagination();
                }

                function copyToClipboard(text) {
                    navigator.clipboard.writeText(text).then(() => {
                        alert('شناسه کپی شد: ' + text);
                    }).catch(err => {
                        console.error('خطا در کپی: ', err);
                    });
                }

                function renderPagination() {
                    const pagination = document.getElementById('pagination');
                    pagination.innerHTML = '';

                    const totalPages = Math.ceil(filteredData.length / rowsPerPage);
                    if (totalPages <= 1) return;

                    const prevBtn = document.createElement('button');
                    prevBtn.innerHTML = '<i class="fa-solid fa-chevron-right"></i> قبلی';
                    prevBtn.disabled = currentPage === 1;
                    prevBtn.onclick = () => { currentPage--; renderTable(); };
                    pagination.appendChild(prevBtn);

                    const startPage = Math.max(1, currentPage - Math.floor(maxVisiblePages / 2));
                    const endPage = Math.min(totalPages, startPage + maxVisiblePages - 1);

                    if (startPage > 1) {
                        pagination.appendChild(createPageBtn(1));
                        if (startPage > 2) pagination.appendChild(createEllipsis());
                    }

                    for (let i = startPage; i <= endPage; i++) {
                        const btn = createPageBtn(i);
                        if (i === currentPage) btn.classList.add('active');
                        pagination.appendChild(btn);
                    }

                    if (endPage < totalPages) {
                        if (endPage < totalPages - 1) pagination.appendChild(createEllipsis());
                        pagination.appendChild(createPageBtn(totalPages));
                    }

                    const nextBtn = document.createElement('button');
                    nextBtn.innerHTML = 'بعدی <i class="fa-solid fa-chevron-left"></i>';
                    nextBtn.disabled = currentPage === totalPages;
                    nextBtn.onclick = () => { currentPage++; renderTable(); };
                    pagination.appendChild(nextBtn);
                }

                function createPageBtn(page) {
                    const btn = document.createElement('button');
                    btn.textContent = page;
                    btn.onclick = () => { currentPage = page; renderTable(); };
                    return btn;
                }

                function createEllipsis() {
                    const span = document.createElement('span');
                    span.textContent = '...';
                    return span;
                }

                function updateStats() {
                    const total = allData.length;
                    const filtered = filteredData.length;
                    document.getElementById('stats').textContent = `تعداد کاربران: ${total} (فیلترشده: ${filtered})`;
                }

                updateStats();
                renderTable();
            </script>
        </body>
        </html>
        '''

        return html_text


db = Database()