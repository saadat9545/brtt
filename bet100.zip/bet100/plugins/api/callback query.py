# -*- coding: utf-8 -*-
from pyrogram import filters, Client, enums
from pyrogram.types import Message, CallbackQuery, InlineKeyboardMarkup, InlineKeyboardButton
from utils.clients import ApiClient
from utils.config import SUDO, SETTINGS
from pickle import dump
from utils import Buttons
from data.database import db
import jdatetime as jdf

def save_settings():
    with open('settings.pkl', 'wb') as f:
        dump(SETTINGS, f)
 

@ApiClient.on_callback_query(filters.regex('^joine_ok') , group=0)
async def join_check(bot: Client, cl: CallbackQuery):
    user_id = cl.from_user.id
    user_fullname = cl.from_user.first_name
    username = cl.from_user.username
    Date = jdf.date.today().strftime("%Y/%m/%d")

    not_joined = []
    for channel in SETTINGS['channel_ids']:
        try:
            member = await bot.get_chat_member(chat_id = int(channel) , user_id = user_id)
            if member.status in (enums.ChatMemberStatus.LEFT, enums.ChatMemberStatus.BANNED):
                not_joined.append(channel)
                return
        except Exception as e:
            not_joined.append(channel)



    if not_joined:
        await cl.answer(f"شما هنوز در کانال‌ها و گپ عضو نشدید ⚠️", show_alert = False)
    else:
        await bot.delete_messages(cl.from_user.id, cl.message.id)

        text = (f'✦ به پیشرفته‌ترین و متفاوت‌ترین ربات فرم‌دهی‌ در تلگرام خوش آمدید 🤖\n'
                f'✦ در این ربات فقط فرم‌های 100 میلیونی تومانی آپلود میشود 💰\n'
                f'✦ برای استفاده از ربات، لطفا گزینه مورد نظر خود را انتخاب کنی')



        await bot.send_message(user_id, text,reply_markup = Buttons.Start) 
        if not db.User_id(user_id):
            db.Add_User(user_fullname, user_id, username,0,Date)
            for sudo in SUDO:
                await bot.send_message(sudo, f'◈ کـاربر {user_fullname}\n ◂ آیدی : {user_id}\nعضو ربات شد 🎉')
