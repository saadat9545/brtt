from os.path import isfile
from pickle import load
from pyrogram import Client
import os
API_ID = 15587752
API_HASH = '56c25355a160a391fdceb7f82d6a6197'
SUDO = [5823435734, 1009678891]
BOT_TOKEN = '8161517141:AAH3l4CdYsRb2XnKetWty51qYxViz-7e_Mk'
BASE_DIR = os.path.dirname(os.path.abspath(__file__))
DATA_DIR = os.path.join(BASE_DIR, "data")
ZIP_NAME = os.path.join(BASE_DIR, "files.zip")
LINKS = []
class Clients:
    api: Client = None



if isfile('settings.pkl'):
    with open('settings.pkl', 'rb') as f:
        SETTINGS = load(f)
else:
    SETTINGS = {
        'channel_ids': {},
        'channel_link': {},
        'ourbots': 0,
        'basket_form': 0,
        'footbal_form': 0,
        'vip_form': 0,
        'link_site': 0,
        'text_baner': '',
        'link_baner': 0,
        'no_fillter': 0,

    }
