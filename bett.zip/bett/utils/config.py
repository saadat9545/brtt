from os.path import isfile
from pickle import load
from pyrogram import Client

API_ID = 15587752
API_HASH = '56c25355a160a391fdceb7f82d6a6197'
SUDO = [5823435734, 1009678891]
BOT_TOKEN = '7115449134:AAFgai1bLxT57v5WgziJDvSKu3JJaEE55k4'
LINKS = []

class Clients:
    api: Client = None


if isfile('settings.pkl'):
    with open('settings.pkl', 'rb') as f:
        SETTINGS = load(f)
else:
    SETTINGS = {
        'channel_ids': {},
        'channel_link': {},
        'baseball': 0,
        'basketball': 0,
        'tennis': 0,
        'haki': 0,
        'over': 0,
        'site_baner': 0,
        'link_site': 0,
        'link_baner': 0,
        'no_fillter': 0,
        'text_baner': 0,
        'join_tx': "",
        'Sup_admin': "",

    }
