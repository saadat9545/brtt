from django.contrib import admin
from django.contrib.auth.admin import UserAdmin
from .models import CustomUser, Master, Seller


# ۱. تعریف و ثبت ادمین برای مدل اصلی (CustomUser)
@admin.register(CustomUser)
class CustomUserAdmin(UserAdmin):
    list_display = ('username', 'first_name', 'last_name', 'role', 'status', 'is_active')
    list_filter = ('role', 'status', 'is_active')
    search_fields = ('username', 'first_name', 'last_name', 'phone_number', 'national_code')

    fieldsets = UserAdmin.fieldsets + (
        ('اطلاعات تکمیلی و پرسنلی', {
            'fields': (
                'role', 'department', 'phone_number', 'profile_picture',
                'national_code', 'address', 'salary', 'status', 'hire_date', 'termination_date'
            )
        }),
    )


# ۲. ثبت منوی اختصاصی استادکاران
@admin.register(Master)
class MasterAdmin(CustomUserAdmin):
    list_display = ('username', 'first_name', 'last_name', 'role', 'department', 'status', 'phone_number')
    list_filter = ('department', 'status', 'is_active')

    fieldsets = UserAdmin.fieldsets + (
        ('اطلاعات تکمیلی و پرسنلی', {
            'fields': (
                'role', 'department', 'phone_number', 'profile_picture',
                'national_code', 'address', 'salary', 'status', 'hire_date', 'termination_date'
            )
        }),
    )

    def get_queryset(self, request):
        return super(UserAdmin, self).get_queryset(request).filter(role='master')


# ۳. ثبت منوی اختصاصی فروشندگان
@admin.register(Seller)
class SellerAdmin(CustomUserAdmin):
    list_display = ('username', 'first_name', 'last_name', 'role', 'status', 'phone_number')
    list_filter = ('status', 'is_active')

    # در اینجا دپارتمان حذف شده است چون فروشنده نیازی به آن ندارد
    fieldsets = UserAdmin.fieldsets + (
        ('اطلاعات تکمیلی و پرسنلی', {
            'fields': (
                'role', 'phone_number', 'profile_picture',
                'national_code', 'address', 'salary', 'status', 'hire_date', 'termination_date'
            )
        }),
    )

    def get_queryset(self, request):
        return super(UserAdmin, self).get_queryset(request).filter(role='seller')
