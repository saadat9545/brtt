from django.db import models
from django.contrib.auth.models import AbstractUser
from django.core.validators import RegexValidator

class CustomUser(AbstractUser):
    ROLE_CHOICES = (
        ('admin', 'مدیر کل'),
        ('master', 'استاد کار'),
        ('seller', 'فروشنده'),
    )

    DEPARTMENT_CHOICES = (
        ('cake', 'دپارتمان کیک'),
        ('dessert', 'دپارتمان دسر'),
        ('sweat', 'دپارتمان شیرینی'),
        ('caka_moor', 'دپارتمان کیک صبحانه'),
        ('bread', 'دپارتمان نان'),
    )

    STATUS_CHOICES = (
        ('active', 'فعال'),
        ('inactive', 'غیرفعال (مرخصی/تعلیق)'),
        ('terminated', 'قطع همکاری'),
    )

    phone_regex = RegexValidator(
        regex=r'^09\d{9}$',
        message="شماره موبایل باید ۱۱ رقمی باشد و با 09 شروع شود."
    )

    # --- فیلدهای قبلی ---
    role = models.CharField(max_length=10, choices=ROLE_CHOICES, default='seller', verbose_name='نقش کاربر')
    department = models.CharField(max_length=20, choices=DEPARTMENT_CHOICES, blank=True, null=True, verbose_name='دپارتمان (مخصوص استادکار)')
    phone_number = models.CharField(max_length=15, unique=True, null=True, blank=True, verbose_name='شماره موبایل')
    profile_picture = models.ImageField(upload_to='staff_photos/%Y/%m/', blank=True, null=True, verbose_name='عکس پرسنلی')
    first_name = models.CharField(max_length=150, verbose_name='نام')
    last_name = models.CharField(max_length=150, verbose_name='نام خانوادگی')

    # --- فیلدهای جدید مدیریت پرسنل ---
    national_code = models.CharField(max_length=10, blank=True, null=True, verbose_name='کد ملی')
    address = models.TextField(blank=True, null=True, verbose_name='آدرس')
    salary = models.DecimalField(max_digits=12, decimal_places=0, blank=True, null=True, verbose_name='حقوق (تومان)')
    status = models.CharField(max_length=15, choices=STATUS_CHOICES, default='active', verbose_name='وضعیت کاری')
    hire_date = models.DateField(blank=True, null=True, verbose_name='تاریخ استخدام')
    termination_date = models.DateField(blank=True, null=True, verbose_name='تاریخ قطع همکاری')

    REQUIRED_FIELDS = ['first_name', 'last_name', 'phone_number']

    class Meta:
        verbose_name = 'پرسنل'
        verbose_name_plural = 'لیست پرسنل'

    def __str__(self):
        full_name = self.get_full_name()
        display_name = full_name if full_name else self.username

        if self.role == 'master' and self.department:
            return f"{display_name} ({self.get_department_display()})"
        return f"{display_name} ({self.get_role_display()})"

    def save(self, *args, **kwargs):
        # اگر وضعیت کاربر غیرفعال یا قطع همکاری باشد، دسترسی ورود او به سیستم (is_active) بسته می‌شود
        if self.status in ['inactive', 'terminated']:
            self.is_active = False
        else:
            self.is_active = True
        super().save(*args, **kwargs)


# --- اضافه شدن مدل‌های پروکسی برای پنل ادمین ---

class Master(CustomUser):
    class Meta:
        proxy = True
        verbose_name = 'استاد کار'
        verbose_name_plural = 'لیست استاد کاران'


class Seller(CustomUser):
    class Meta:
        proxy = True
        verbose_name = 'فروشنده'
        verbose_name_plural = 'لیست فروشندگان'
