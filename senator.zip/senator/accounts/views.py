from django.contrib.auth.views import LoginView
from django.urls import reverse_lazy
from django.contrib.auth.decorators import login_required
from django.shortcuts import render, get_object_or_404
from order.models import Order  # مطمئن شوید مدل Order ایمپورت شده است
import json
from accounts.models import CustomUser
from django.contrib.auth import get_user_model
from django.utils import timezone
from datetime import timedelta
from django.shortcuts import redirect
from django.contrib import messages
from django.contrib.auth.decorators import login_required
from home.views import role_required
from datetime import datetime
from django.db.models import Q  # <--- اضافه کردن Q برای جستجوی پیشرفته
import jdatetime
from order.models import Order
from datetime import date, timedelta
from django.db.models import Q

class CustomLoginView(LoginView):
    template_name = 'login.html'
    redirect_authenticated_user = True

    def get_success_url(self):
        user = self.request.user

        # Preserve the order opened from a notification after signing in.
        next_url = self.get_redirect_url()
        if next_url:
            return next_url

        # هدایت بر اساس نقش
        if user.is_superuser or user.role == 'admin':
            return reverse_lazy('admin_dashboard')
        elif user.role == 'master':
            return reverse_lazy('master_dashboard')
        elif user.role == 'seller':
            return reverse_lazy('seller_dashboard')

        # مسیر پیش‌فرض در صورت نداشتن نقش
        return reverse_lazy('login')




User = get_user_model()
def settings(request):
    # کدهای مربوط به تنظیمات
    return render(request, 'base_admin.html')


# def order_management(request):
#     # کدهای مربوط به مدیریت سفارشات
#     return render(request, 'base_admin.html')
#

# def staff_management(request):
#     # بعداً می‌توانید منطق مدیریت استادکاران را اینجا بنویسید
#     return render(request, 'staff_management.html')
#

# def seller_management(request):
#     # کدهای مربوط به مدیریت فروشندگان
#     return render(request, 'base_admin.html') # یا هر قالب دیگری که دارید


@login_required
@role_required(allowed_roles=['admin'])
def admin_dashboard(request):
    today = timezone.now().date()
    yesterday = today - timedelta(days=1)

    # --- 1. آمار سفارشات ---
    today_orders = Order.objects.filter(created_at__date=today).count()
    yesterday_orders = Order.objects.filter(created_at__date=yesterday).count()

    if yesterday_orders > 0:
        yesterday_compare = round(((today_orders - yesterday_orders) / yesterday_orders) * 100)
    else:
        yesterday_compare = 100 if today_orders > 0 else 0

    # --- 2. آمار نمودار (۷ روز گذشته) ---
    chart_labels = []
    chart_data = []
    for i in range(6, -1, -1):
        day = today - timedelta(days=i)
        # می‌توانید نام روزها را شمسی کنید، اینجا فعلا تاریخ میلادی/فرمت ساده است
        chart_labels.append(day.strftime("%m/%d"))
        count = Order.objects.filter(created_at__date=day).count()
        chart_data.append(count)

    sellers = CustomUser.objects.filter(role='seller', is_superuser=False).order_by('-date_joined')
    masters = CustomUser.objects.filter(role='master', is_superuser=False).order_by('-date_joined')

    context = {
        'today_orders': today_orders,
        'yesterday_compare': yesterday_compare,
        'chart_labels': json.dumps(chart_labels),
        'chart_data': json.dumps(chart_data),

        # اطلاعات استادکاران
        'total_staff': masters.count(),
        'active_staff': masters.filter(is_active=True).count(),
        'staff_list': masters,  # ارسال کل لیست برای فعال شدن اسکرول در HTML
        # اطلاعات فروشندگان
        'total_sellers': sellers.count(),
        'active_sellers': sellers.filter(is_active=True).count(),
        'seller_list': sellers,
    }
    print("تعداد استادکاران پیدا شده:", masters.count())
    print("تعداد فروشندگان پیدا شده:", sellers.count())

    return render(request, 'admin_dashboard.html', context)




@login_required
def master_dashboard(request):
    if request.user.role != 'master' or not request.user.is_active:
        return redirect('login')
    search_query = request.GET.get('search', '').strip()
    selected_date_str = request.GET.get('date')

    today_gregorian = date.today()

    if selected_date_str:
        try:
            y, m, d = map(int, selected_date_str.split('-'))
            gregorian_date = date(y, m, d)
        except ValueError:
            gregorian_date = today_gregorian
    else:
        gregorian_date = today_gregorian

    # 1. سفارشات استادکار در تاریخ انتخاب شده
    orders = Order.objects.filter(
        master=request.user,
        delivery_date=gregorian_date
    ).order_by('delivery_time')

    if search_query:
        # اصلاح نام فیلدها طبق مدل شما
        orders = orders.filter(
            Q(customer_name__icontains=search_query) |
            Q(id__icontains=search_query) |
            Q(customer_phone__icontains=search_query) |
            Q(customer_phone_2__icontains=search_query)
        )

    # 2. سفارشات پیش‌رو (از فردا تا 7 روز آینده - محدود شده به 15 عدد)
    tomorrow = today_gregorian + timedelta(days=1)
    next_week = today_gregorian + timedelta(days=7)

    upcoming_orders_qs = Order.objects.filter(
        master=request.user,
        delivery_date__gte=tomorrow,
        delivery_date__lte=next_week
    ).order_by('delivery_date', 'delivery_time')[:15]

    # ساخت یک دیکشنری برای گروه‌بندی سفارشات بر اساس تاریخ شمسی
    grouped_upcoming_orders = {}

    for order in upcoming_orders_qs:
        if order.delivery_date:
            j_date = jdatetime.date.fromgregorian(date=order.delivery_date)
            order.shamsi_date = j_date.strftime('%Y/%m/%d')
            date_str = f"{j_date.day} {jdatetime.date.j_months_fa[j_date.month - 1]}"
            order.shamsi_date_str = date_str

            # اگر این تاریخ هنوز در دیکشنری نیست، آن را بساز
            if date_str not in grouped_upcoming_orders:
                grouped_upcoming_orders[date_str] = []

            # اضافه کردن سفارش به لیستِ همان تاریخ
            grouped_upcoming_orders[date_str].append(order)

    # اضافه کردن تاریخ شمسی ثبت و تحویل به سفارشات لیست اصلی برای نمایش در مدال
    for order in orders:
        # تاریخ تحویل شمسی
        if order.delivery_date:
            j_del_date = jdatetime.date.fromgregorian(date=order.delivery_date)
            order.shamsi_delivery_date = j_del_date.strftime('%Y/%m/%d')

        # تاریخ ثبت شمسی (created_at معمولا datetime است)
        if order.created_at:
            j_create_date = jdatetime.datetime.fromgregorian(datetime=order.created_at)
            order.shamsi_created_at = j_create_date.strftime('%Y/%m/%d %H:%M')

    context = {
        'orders': orders,
        'grouped_upcoming_orders': grouped_upcoming_orders,
        'search_query': search_query,
        'is_today': gregorian_date == today_gregorian,
    }

    return render(request, 'master_dashboard.html', context)


@login_required
def seller_dashboard(request):
    search_query = request.GET.get('search', '').strip()
    selected_date_str = request.GET.get('date')

    today_gregorian = date.today()

    if selected_date_str:
        try:
            y, m, d = map(int, selected_date_str.split('-'))
            gregorian_date = date(y, m, d)
        except ValueError:
            gregorian_date = today_gregorian
    else:
        gregorian_date = today_gregorian

    # 1. سفارشات استادکار در تاریخ انتخاب شده
    orders = Order.objects.filter(
        # master=request.user,
        delivery_date=gregorian_date
    ).order_by('delivery_time')

    if search_query:
        # اصلاح نام فیلدها طبق مدل شما
        orders = orders.filter(
            Q(customer_name__icontains=search_query) |
            Q(id__icontains=search_query) |
            Q(customer_phone__icontains=search_query) |
            Q(customer_phone_2__icontains=search_query)
        )

    # 2. سفارشات پیش‌رو (از فردا تا 7 روز آینده - محدود شده به 15 عدد)
    # today = timezone.now().date()
    today_cake_count = Order.objects.filter(delivery_date=gregorian_date, order_type='cake').count()
    today_pastry_count = Order.objects.filter(delivery_date=gregorian_date, order_type='pastry').count()

    canceled_orders_count = Order.objects.filter(delivery_date=gregorian_date,status='canceled').count()
    pending_orders_count = Order.objects.filter(delivery_date=gregorian_date,status='pending').count()

    tomorrow = today_gregorian + timedelta(days=1)
    next_week = today_gregorian + timedelta(days=7)

    upcoming_orders_qs = Order.objects.filter(
        # master=request.user,
        delivery_date__gte=tomorrow,
        delivery_date__lte=next_week
    ).order_by('delivery_date', 'delivery_time')[:15]

    # ساخت یک دیکشنری برای گروه‌بندی سفارشات بر اساس تاریخ شمسی
    grouped_upcoming_orders = {}

    for order in upcoming_orders_qs:
        if order.delivery_date:
            j_date = jdatetime.date.fromgregorian(date=order.delivery_date)
            order.shamsi_date = j_date.strftime('%Y/%m/%d')
            date_str = f"{j_date.day} {jdatetime.date.j_months_fa[j_date.month - 1]}"
            order.shamsi_date_str = date_str

            # اگر این تاریخ هنوز در دیکشنری نیست، آن را بساز
            if date_str not in grouped_upcoming_orders:
                grouped_upcoming_orders[date_str] = []

            # اضافه کردن سفارش به لیستِ همان تاریخ
            grouped_upcoming_orders[date_str].append(order)

    # اضافه کردن تاریخ شمسی ثبت و تحویل به سفارشات لیست اصلی برای نمایش در مدال
    for order in orders:
        # تاریخ تحویل شمسی
        if order.delivery_date:
            j_del_date = jdatetime.date.fromgregorian(date=order.delivery_date)
            order.shamsi_delivery_date = j_del_date.strftime('%Y/%m/%d')

        # تاریخ ثبت شمسی (created_at معمولا datetime است)
        if order.created_at:
            j_create_date = jdatetime.datetime.fromgregorian(datetime=order.created_at)
            order.shamsi_created_at = j_create_date.strftime('%Y/%m/%d %H:%M')

    context = {
        'orders': orders,
        'grouped_upcoming_orders': grouped_upcoming_orders,
        'search_query': search_query,
        'today_cake_count': today_cake_count,
        'is_today': gregorian_date == today_gregorian,
        'today_pastry_count': today_pastry_count,
        'canceled_orders_count': canceled_orders_count,
        'pending_orders_count': pending_orders_count,
    }

    return render(request, 'seller_dashboard.html', context)


def seller_order_detail(request, order_id):
    order = get_object_or_404(Order, id=order_id)
    return render(request, "base_seller.html", {"order": order})


    # query = request.GET.get('q', '').strip()
    # date_query = request.GET.get('date', '')
    #
    # # --- تنظیم تاریخ انتخاب شده ---
    # if date_query:
    #     try:
    #         selected_date = datetime.strptime(date_query, '%Y-%m-%d').date()
    #     except ValueError:
    #         selected_date = timezone.now().date()
    # else:
    #     selected_date = timezone.now().date()
    #
    # # --- گرفتن سفارشات همان روز بر اساس تاریخ تحویل ---
    # orders = Order.objects.filter(
    #     delivery_date=selected_date
    # ).order_by('delivery_time')  # مرتب‌سازی بر اساس ساعت تحویل
    #
    # # --- اعمال جستجوی پیشرفته ---
    # if query:
    #     orders = orders.filter(
    #         Q(id__icontains=query) |
    #         Q(customer_name__icontains=query) |
    #         Q(customer_phone__icontains=query)
    #     )
    #
    # # --- محاسبه آمار (بر اساس تاریخ تحویل امروز) ---
    # today = timezone.now().date()
    #
    # today_orders_count = Order.objects.filter(delivery_date=today).count()
    # today_cake_count = Order.objects.filter(delivery_date=today, order_type='cake').count()
    # today_pastry_count = Order.objects.filter(delivery_date=today, order_type='pastry').count()
    #
    # canceled_orders_count = Order.objects.filter(status='canceled').count()
    # pending_orders_count = Order.objects.filter(status='pending').count()
    #
    # context = {
    #     'orders': orders,
    #     'selected_date': selected_date,
    #     'today_orders_count': today_orders_count,
    #     'today_cake_count': today_cake_count,
    #     'today_pastry_count': today_pastry_count,
    #     'canceled_orders_count': canceled_orders_count,
    #     'pending_orders_count': pending_orders_count,
    # }
    #
    # return render(request, 'seller_dashboard.html', context)
