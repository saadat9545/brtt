# customers/forms.py

import jdatetime
from django import forms
from django.core.validators import RegexValidator

from .models import Customer, CustomerNote


DIGITS = str.maketrans("۰۱۲۳۴۵۶۷۸۹٠١٢٣٤٥٦٧٨٩", "01234567890123456789")

BASE_INPUT = (
    "w-full bg-[#141414]/80 border border-white/[0.07] rounded-xl px-4 py-3 "
    "text-xs text-gray-200 placeholder:text-gray-500/70 shadow-inner shadow-black/40 "
    "focus:outline-none focus:border-primary/40 focus:ring-1 focus:ring-primary/20 "
    "focus:bg-[#171717] transition-colors [color-scheme:dark]"
)
CHECKBOX_CLS = "w-4 h-4 accent-amber-500 bg-transparent rounded"

# فقط این دو الزامی هستند
REQUIRED_FIELDS = {"last_name", "phone_number"}


phone_validator = RegexValidator(
    regex=r"^09\d{9}$",
    message="شماره موبایل باید با ۰۹ شروع شده و ۱۱ رقم باشد."
)

national_id_validator = RegexValidator(
    regex=r"^\d{10}$",
    message="کد ملی باید ۱۰ رقم باشد."
)


class JalaliDateField(forms.DateField):
    """ورودی تاریخ شمسی (۱۴۰۳/۰۵/۲۱) با تبدیل خودکار به میلادی."""

    def to_python(self, value):
        if value in self.empty_values:
            return None
        if not isinstance(value, str):
            return super().to_python(value)

        raw = value.strip().translate(DIGITS).replace("-", "/")
        parts = [p for p in raw.split("/") if p]
        if len(parts) != 3:
            raise forms.ValidationError("تاریخ را به شکل ۱۴۰۳/۰۵/۲۱ وارد کنید.")
        try:
            y, m, d = (int(p) for p in parts)
            return jdatetime.date(y, m, d).togregorian()
        except ValueError:
            raise forms.ValidationError("تاریخ شمسی معتبر نیست.")


class CustomerForm(forms.ModelForm):
    phone_number = forms.CharField(
        label="شماره موبایل",
        validators=[phone_validator],
        widget=forms.TextInput(attrs={
            "placeholder": "09xxxxxxxxx",
            "maxlength": 11,
            "inputmode": "numeric",
            "dir": "ltr",
            "autocomplete": "tel",
            "class": BASE_INPUT + " text-center tracking-widest",
        }),
    )
    national_id = forms.CharField(
        label="کد ملی",
        required=False,
        validators=[national_id_validator],
        widget=forms.TextInput(attrs={
            "maxlength": 10,
            "inputmode": "numeric",
            "dir": "ltr",
            "autocomplete": "off",
            "class": BASE_INPUT + " text-center tracking-widest",
        }),
    )
    birth_date = JalaliDateField(
        label="تاریخ تولد",
        required=False,
        widget=forms.TextInput(attrs={
            "data-jdp": "",
            "autocomplete": "off",
            "inputmode": "numeric",
            "dir": "ltr",
            "placeholder": "۱۴۰۳/۰۵/۲۱",
            "class": BASE_INPUT + " text-center tracking-widest",
        }),
    )

    class Meta:
        model = Customer
        fields = [
            "first_name",
            "last_name",
            "phone_number",
            "national_id",
            "birth_date",
            "email",
            "address",
            "tier",
            "acquisition_source",
            "referrer",
            "is_vip",
            "is_active",
        ]
        labels = {
            "first_name": "نام",
            "last_name": "نام خانوادگی",
            "email": "ایمیل",
            "address": "آدرس",
            "tier": "سطح عضویت",
            "acquisition_source": "نحوه آشنایی",
            "referrer": "معرف",
            "is_vip": "VIP",
            "is_active": "فعال",
        }
        widgets = {
            "address": forms.Textarea(attrs={"rows": 2}),
            "referrer": forms.Select(attrs={"class": "select2"}),
        }

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)

        # مشتری نمی‌تواند معرف خودش باشد
        qs = Customer.objects.filter(is_active=True)
        if self.instance.pk:
            qs = qs.exclude(pk=self.instance.pk)
        self.fields["referrer"].queryset = qs
        self.fields["referrer"].empty_label = "--- بدون معرف ---"

        # تزریق استایل‌های تم دارک + تنظیم الزامی‌بودن
        for name, field in self.fields.items():
            field.required = name in REQUIRED_FIELDS

            w = field.widget
            if isinstance(w, forms.CheckboxInput):
                w.attrs["class"] = CHECKBOX_CLS
                continue

            if isinstance(w, forms.Textarea):
                w.attrs.setdefault("rows", 3)
                w.attrs["class"] = BASE_INPUT + " resize-none leading-relaxed"
            elif isinstance(w, forms.Select):
                existing = w.attrs.get("class", "")
                w.attrs["class"] = f"{BASE_INPUT} appearance-none cursor-pointer {existing}".strip()
            else:
                w.attrs.setdefault("class", BASE_INPUT)
                w.attrs.setdefault("placeholder", field.label or "")

        # نمایش تاریخ ذخیره‌شده به شمسی
        if self.instance.pk and self.instance.birth_date:
            self.initial["birth_date"] = jdatetime.date.fromgregorian(
                date=self.instance.birth_date
            ).strftime("%Y/%m/%d")

    def clean_national_id(self):
        """اعتبارسنجی الگوریتمی کد ملی ایران + یکتایی."""
        nid = (self.cleaned_data.get("national_id") or "").strip().translate(DIGITS)
        if not nid:
            return ""

        if len(set(nid)) == 1:
            raise forms.ValidationError("کد ملی وارد شده معتبر نیست.")

        digits = [int(d) for d in nid]
        check = digits[9]
        total = sum(d * (10 - i) for i, d in enumerate(digits[:9]))
        remainder = total % 11
        valid = check == remainder if remainder < 2 else check == 11 - remainder
        if not valid:
            raise forms.ValidationError("کد ملی وارد شده معتبر نیست.")

        qs = Customer.objects.filter(national_id=nid)
        if self.instance.pk:
            qs = qs.exclude(pk=self.instance.pk)
        if qs.exists():
            raise forms.ValidationError("این کد ملی قبلاً ثبت شده است.")

        return nid

    def clean_phone_number(self):
        phone = (self.cleaned_data.get("phone_number") or "").strip().translate(DIGITS)
        qs = Customer.objects.filter(phone_number=phone)
        if self.instance.pk:
            qs = qs.exclude(pk=self.instance.pk)
        if qs.exists():
            raise forms.ValidationError("این شماره موبایل قبلاً ثبت شده است.")
        return phone


class CustomerNoteForm(forms.ModelForm):
    class Meta:
        model = CustomerNote
        fields = ["text", "created_by"]
        widgets = {
            "text": forms.Textarea(attrs={
                "rows": 4,
                "placeholder": "یادداشت را وارد کنید...",
                "class": BASE_INPUT + " resize-none leading-relaxed",
            }),
            "created_by": forms.TextInput(attrs={
                "class": BASE_INPUT,
                "placeholder": "نام ثبت‌کننده",
            }),
        }
        labels = {
            "text": "متن یادداشت",
            "created_by": "ثبت‌کننده",
        }
