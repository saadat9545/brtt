# models.py

from django.db import models
from django.utils import timezone


class Customer(models.Model):

    class TierLevel(models.TextChoices):
        BRONZE = "bronze", "برنزی"
        SILVER = "silver", "نقره‌ای"
        GOLD = "gold", "طلایی"
        VIP = "vip", "ویژه"

    class AcquisitionSource(models.TextChoices):
        UNKNOWN = "unknown", "نامشخص"
        WALK_IN = "walk_in", "مراجعه حضوری"
        INSTAGRAM = "instagram", "اینستاگرام"
        TELEGRAM = "telegram", "تلگرام"
        REFERRAL = "referral", "معرفی دوستان"
        OTHER = "other", "سایر"

    # اطلاعات پایه
    first_name = models.CharField(max_length=100, verbose_name="نام")
    last_name = models.CharField(max_length=100, verbose_name="نام خانوادگی")
    phone_number = models.CharField(
        max_length=15,
        unique=True,
        verbose_name="شماره تلفن"
    )
    national_id = models.CharField(
        max_length=10,
        blank=True,
        null=True,
        unique=True,
        verbose_name="کد ملی"
    )
    birth_date = models.DateField(
        blank=True,
        null=True,
        verbose_name="تاریخ تولد"
    )

    # اطلاعات باشگاه
    tier = models.CharField(
        max_length=10,
        choices=TierLevel.choices,
        default=TierLevel.BRONZE,
        verbose_name="سطح عضویت"
    )
    points = models.PositiveIntegerField(default=0, verbose_name="امتیاز")
    acquisition_source = models.CharField(
        max_length=20,
        choices=AcquisitionSource.choices,
        default=AcquisitionSource.UNKNOWN,
        verbose_name="منبع آشنایی"
    )
    referrer = models.ForeignKey(
        "self",
        on_delete=models.SET_NULL,
        null=True,
        blank=True,
        related_name="referrals",
        verbose_name="معرف"
    )
    email = models.EmailField(blank=True, null=True, verbose_name='ایمیل')
    address = models.TextField(blank=True, null=True, verbose_name='آدرس')
    # وضعیت
    is_active = models.BooleanField(default=True, verbose_name="فعال")
    is_vip = models.BooleanField(default=False, verbose_name="مشتری ویژه")

    # تاریخ‌ها
    joined_at = models.DateTimeField(default=timezone.now, verbose_name="تاریخ عضویت")
    updated_at = models.DateTimeField(auto_now=True, verbose_name="آخرین بروزرسانی")

    class Meta:
        verbose_name = "مشتری"
        verbose_name_plural = "مشتریان"
        ordering = ["-joined_at"]
        permissions = [
            ("manage_customer_vip", "امکان تعیین مشتری ویژه"),
        ]

    def __str__(self):
        return f"{self.first_name} {self.last_name} ({self.phone_number})"

    def get_full_name(self):
        return f"{self.first_name} {self.last_name}"


class CustomerNote(models.Model):
    customer = models.ForeignKey(
        Customer,
        on_delete=models.CASCADE,
        related_name="notes",
        verbose_name="مشتری"
    )
    text = models.TextField(verbose_name="متن یادداشت")
    created_by = models.CharField(
        max_length=150,
        blank=True,
        verbose_name="ثبت‌کننده"
    )
    created_at = models.DateTimeField(auto_now_add=True, verbose_name="تاریخ ثبت")

    class Meta:
        verbose_name = "یادداشت مشتری"
        verbose_name_plural = "یادداشت‌های مشتریان"
        ordering = ["-created_at"]

    def __str__(self):
        return f"یادداشت برای {self.customer} - {self.created_at:%Y/%m/%d}"
