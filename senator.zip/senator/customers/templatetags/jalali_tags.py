# customers/templatetags/jalali_tags.py
"""فیلترهای تبدیل تاریخ میلادی به شمسی، مبتنی بر jdatetime."""

import datetime

import jdatetime
from django import template
from django.utils import timezone
from decimal import Decimal, InvalidOperation

register = template.Library()

JALALI_MONTH_NAMES = (
    'فروردین', 'اردیبهشت', 'خرداد', 'تیر', 'مرداد', 'شهریور',
    'مهر', 'آبان', 'آذر', 'دی', 'بهمن', 'اسفند',
)

# jdatetime: شنبه = 0 ... جمعه = 6
JALALI_WEEKDAYS = ('شنبه', 'یکشنبه', 'دوشنبه', 'سه‌شنبه', 'چهارشنبه', 'پنجشنبه', 'جمعه')

PERSIAN_DIGITS = str.maketrans('0123456789', '۰۱۲۳۴۵۶۷۸۹')


def _localize(value):
    """datetime آگاه از timezone را به وقت محلی پروژه می‌آورد."""
    if isinstance(value, datetime.datetime) and timezone.is_aware(value):
        return timezone.localtime(value)
    return value


def _to_jalali(value):
    """date/datetime میلادی → (jdate, time یا None). در ورودی نامعتبر None برمی‌گرداند."""
    value = _localize(value)

    if isinstance(value, datetime.datetime):
        return jdatetime.date.fromgregorian(date=value.date()), value.time()
    if isinstance(value, datetime.date):
        return jdatetime.date.fromgregorian(date=value), None
    return None, None


def _render(jdate, time_part, fmt):
    """توکن‌های سبک Django را با مقادیر شمسی جایگزین می‌کند."""
    tokens = {
        'Y': f'{jdate.year:04d}',
        'y': f'{jdate.year % 100:02d}',
        'F': JALALI_MONTH_NAMES[jdate.month - 1],
        'm': f'{jdate.month:02d}',
        'n': str(jdate.month),
        'd': f'{jdate.day:02d}',
        'j': str(jdate.day),
        'l': JALALI_WEEKDAYS[jdate.weekday()],
    }
    if time_part is not None:
        tokens.update({
            'H': f'{time_part.hour:02d}',
            'i': f'{time_part.minute:02d}',
            's': f'{time_part.second:02d}',
        })

    # کاراکتر به کاراکتر تا جایگزینی‌ها روی هم نیفتند؛ \ برای escape
    out, escaped = [], False
    for ch in fmt:
        if escaped:
            out.append(ch)
            escaped = False
        elif ch == '\\':
            escaped = True
        else:
            out.append(tokens.get(ch, ch))
    return ''.join(out)


@register.filter(name='jalali')
def jalali(value, fmt='Y/m/d'):
    """
    {{ obj.joined_at|jalali }}             → 1405/06/28
    {{ obj.joined_at|jalali:"j F Y" }}     → 28 شهریور 1405
    {{ obj.joined_at|jalali:"l j F Y" }}   → جمعه 28 شهریور 1405
    """
    jdate, time_part = _to_jalali(value)
    if jdate is None:
        return ''
    return _render(jdate, time_part, fmt)


@register.filter(name='jalali_time')
def jalali_time(value, fmt='Y/m/d H:i'):
    """مثل jalali، با ساعت و دقیقه. روی ورودی date خالص، توکن‌های زمان حذف می‌شوند."""
    jdate, time_part = _to_jalali(value)
    if jdate is None:
        return ''
    if time_part is None:
        fmt = fmt.replace('H:i:s', '').replace('H:i', '').strip()
    return _render(jdate, time_part, fmt).strip()


@register.filter(name='fa_digits')
def fa_digits(value):
    """ارقام لاتین را به فارسی تبدیل می‌کند."""
    return str(value).translate(PERSIAN_DIGITS)



@register.filter
def sub(value, arg):
    """تفریق دو عدد؛ در صورت خطا صفر برمی‌گرداند."""
    try:
        return Decimal(str(value or 0)) - Decimal(str(arg or 0))
    except (TypeError, ValueError, InvalidOperation):
        return 0


@register.filter
def order_status_class(status):
    return {
        'done': 'text-bg-success',
        'canceled': 'text-bg-danger',
    }.get(status, 'text-bg-warning')



@register.filter
def order_status_class(status):
    return {
        'done':     'bg-emerald-500/10 text-emerald-400 border-emerald-500/20',
        'canceled': 'bg-red-500/10 text-red-400 border-red-500/20',
        'pending':  'bg-amber-500/10 text-amber-400 border-amber-500/20',
    }.get(status, 'bg-white/5 text-textMuted border-white/10')
