# views.py

from django.shortcuts import render, get_object_or_404, redirect
from django.contrib import messages
from django.contrib.auth.decorators import login_required, permission_required
from django.db.models import Q
from django.core.paginator import Paginator
from django.http import JsonResponse
from django.views.decorators.http import require_POST
from django.urls import reverse

from .models import Customer, CustomerNote
from .forms import CustomerForm, CustomerNoteForm
from django.db.models import Sum, Count, Avg, Max, F

from django import template
from datetime import datetime
import zoneinfo


# ─── لیست مشتریان ────────────────────────────────────────────────────────────

@login_required
def customer_list(request):
    customers = Customer.objects.filter(is_active=True).order_by('-joined_at')
    return render(request, 'customers/customer_list.html', {'customers': customers})
# ─── جزئیات مشتری ────────────────────────────────────────────────────────────
@login_required
def customer_detail(request, pk):
    customer = get_object_or_404(Customer, pk=pk)

    qs = customer.orders.all()

    stats = qs.aggregate(
        cnt=Count('id'),
        total=Sum('price'),
        deposit=Sum('deposit'),
        avg=Avg('price'),
        last=Max('created_at'),
    )

    status = request.GET.get('status')
    if status in {'pending', 'done', 'canceled'}:
        qs = qs.filter(status=status)

    # مانده هر سفارش در دیتابیس محاسبه می‌شود، بدون فیلتر sub
    qs = qs.annotate(remaining=F('price') - F('deposit')).order_by('-created_at')

    page = Paginator(qs, 20).get_page(request.GET.get('page'))

    total = stats['total'] or 0
    deposit = stats['deposit'] or 0

    return render(request, 'customers/customer_detail.html', {
        'customer': customer,
        'orders': page,
        'orders_count': stats['cnt'] or 0,
        'total_spent': total,
        'total_deposit': deposit,
        'remaining': total - deposit,
        'avg_spent': stats['avg'] or 0,
        'last_order_date': stats['last'],
    })
# ─── ایجاد مشتری جدید ────────────────────────────────────────────────────────

@login_required
def customer_create(request):
    """ثبت مشتری جدید."""
    if request.method == "POST":
        form = CustomerForm(request.POST)
        if form.is_valid():
            customer = form.save()
            messages.success(request, f"مشتری «{customer.get_full_name()}» با موفقیت ثبت شد.")
            return redirect("customers:customer_detail", pk=customer.pk)
    else:
        form = CustomerForm()

    return render(request, "customers/customer_form.html", {"form": form, "action": "ثبت"})


# ─── ویرایش مشتری ────────────────────────────────────────────────────────────
@login_required
def customer_edit(request, pk):
    """ویرایش اطلاعات مشتری."""
    customer = get_object_or_404(Customer, pk=pk)
    form = CustomerForm(request.POST or None, instance=customer)

    if request.method == "POST":
        if form.is_valid():
            form.save()
            messages.success(request, "اطلاعات مشتری بروزرسانی شد.")
            return redirect("customers:customer_detail", pk=customer.pk)
        messages.error(request, "لطفاً خطاهای فرم را برطرف کنید.")

    return render(request, "customers/customer_form.html", {
        "form": form,
        "customer": customer,
        "action": "ویرایش",
        "cancel_url": reverse("customers:customer_detail", args=[customer.pk]),
    })


# ─── غیرفعال کردن مشتری ──────────────────────────────────────────────────────

@login_required
@require_POST
def customer_deactivate(request, pk):
    """غیرفعال کردن مشتری (حذف نرم)."""
    customer = get_object_or_404(Customer, pk=pk)
    customer.is_active = False
    customer.save(update_fields=["is_active"])
    messages.warning(request, f"مشتری «{customer.get_full_name()}» غیرفعال شد.")
    return redirect("customers:customer_list")


# ─── تغییر سطح VIP ───────────────────────────────────────────────────────────

@login_required
@permission_required("customers.manage_customer_vip", raise_exception=True)
@require_POST
def customer_toggle_vip(request, pk):
    """تغییر وضعیت VIP مشتری (فقط برای کاربران مجاز)."""
    customer = get_object_or_404(Customer, pk=pk)
    customer.is_vip = not customer.is_vip
    if customer.is_vip:
        customer.tier = Customer.TierLevel.VIP
    customer.save(update_fields=["is_vip", "tier"])
    status = "فعال" if customer.is_vip else "غیرفعال"
    messages.success(request, f"وضعیت VIP مشتری {status} شد.")
    return redirect("customers:customer_detail", pk=customer.pk)


# ─── افزودن امتیاز ───────────────────────────────────────────────────────────

@login_required
@require_POST
def customer_add_points(request, pk):
    """افزودن امتیاز به مشتری."""
    customer = get_object_or_404(Customer, pk=pk)

    try:
        amount = int(request.POST.get("points", 0))
        if amount <= 0:
            raise ValueError
    except (ValueError, TypeError):
        messages.error(request, "مقدار امتیاز نامعتبر است.")
        return redirect("customers:customer_detail", pk=customer.pk)

    customer.points += amount
    customer.save(update_fields=["points"])
    messages.success(request, f"{amount} امتیاز به مشتری اضافه شد.")
    return redirect("customers:customer_detail", pk=customer.pk)


# ─── یادداشت‌ها ───────────────────────────────────────────────────────────────

@login_required
@require_POST
def note_add(request, customer_pk):
    """افزودن یادداشت به مشتری."""
    customer = get_object_or_404(Customer, pk=customer_pk)
    form = CustomerNoteForm(request.POST)

    if form.is_valid():
        note = form.save(commit=False)
        note.customer = customer
        note.created_by = request.user.get_full_name() or request.user.username
        note.save()
        messages.success(request, "یادداشت ثبت شد.")
    else:
        messages.error(request, "خطا در ثبت یادداشت.")

    return redirect("customers:customer_detail", pk=customer_pk)


@login_required
@require_POST
def note_delete(request, pk):
    """حذف یادداشت."""
    note = get_object_or_404(CustomerNote, pk=pk)
    customer_pk = note.customer_id
    note.delete()
    messages.success(request, "یادداشت حذف شد.")
    return redirect("customers:customer_detail", pk=customer_pk)


# ─── API ساده برای جستجوی Ajax ───────────────────────────────────────────────

@login_required
def customer_search_api(request):
    """جستجوی سریع مشتری برای فیلدهای autocomplete."""
    q = request.GET.get("q", "").strip()
    results = []

    if len(q) >= 2:
        customers = Customer.objects.filter(
            Q(first_name__icontains=q) |
            Q(last_name__icontains=q) |
            Q(phone_number__icontains=q),
            is_active=True,
        )[:10]

        results = [
            {
                "id": c.pk,
                "text": str(c),
                "tier": c.get_tier_display(),
                "points": c.points,
            }
            for c in customers
        ]

    return JsonResponse({"results": results})



