from django.db.models import Q


def is_manager(user):
    return user.is_authenticated and user.is_active and (user.is_superuser or user.role == 'admin')


def can_manage_customers(user):
    return is_manager(user) or (user.is_authenticated and user.is_active and user.role == 'seller')


def can_manage_vip(user):
    return is_manager(user) or (can_manage_customers(user) and user.has_perm('customers.manage_customer_vip'))


def visible_orders(user, queryset):
    if can_manage_customers(user):
        return queryset
    if user.is_authenticated and user.is_active and user.role == 'master':
        return queryset.filter(master=user)
    return queryset.none()
