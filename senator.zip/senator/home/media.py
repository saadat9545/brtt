from pathlib import Path

from django.contrib.auth.decorators import login_required
from django.http import FileResponse, Http404
from django.views.decorators.http import require_safe
from django.views.decorators.cache import never_cache

from accounts.models import CustomUser
from order.models import OrderImage
from .access import is_manager, visible_orders


@login_required
@require_safe
@never_cache
def private_media(request, path):
    image = OrderImage.objects.filter(image=path).select_related('order').first()
    if image:
        if not visible_orders(request.user, image.order.__class__.objects.filter(pk=image.order_id)).exists():
            raise Http404
        field = image.image
    else:
        users = CustomUser.objects.filter(profile_picture=path)
        if not is_manager(request.user):
            users = users.filter(pk=request.user.pk)
        user = users.first()
        if not user or not user.profile_picture:
            raise Http404
        field = user.profile_picture
    # Legacy uploads are restricted to raster formats; arbitrary files are never served inline.
    content_type = {'.jpg': 'image/jpeg', '.jpeg': 'image/jpeg', '.png': 'image/png',
                    '.webp': 'image/webp', '.gif': 'image/gif'}.get(Path(field.name).suffix.lower())
    if not content_type:
        raise Http404
    try:
        response = FileResponse(field.open('rb'), content_type=content_type)
    except FileNotFoundError:
        raise Http404
    response['Content-Security-Policy'] = "default-src 'none'; sandbox"
    response['X-Content-Type-Options'] = 'nosniff'
    return response
