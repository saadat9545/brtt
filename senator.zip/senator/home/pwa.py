"""Public, same-origin resources used by the installed web application."""
from pathlib import Path

from django.http import FileResponse, Http404, HttpResponse, JsonResponse
from django.shortcuts import render
from django.urls import reverse
from django.views.decorators.http import require_safe


ASSETS = Path(__file__).resolve().parent.parent / "static" / "pwa"


@require_safe
def manifest(request):
    return JsonResponse({
        "id": "/",
        "name": "سناتور | مدیریت سفارش‌ها",
        "short_name": "سناتور",
        "description": "مدیریت سفارش‌ها، مشتریان و پرسنل سناتور",
        "lang": "fa",
        "dir": "rtl",
        "start_url": reverse("login"),
        "scope": "/",
        "display": "standalone",
        "background_color": "#1a0f2e",
        "theme_color": "#2c1a4d",
        "icons": [
            {"src": reverse("pwa_icon", args=[size]),
             "sizes": f"{size}x{size}", "type": "image/png", "purpose": "any"}
            for size in (192, 512)
        ],
    }, content_type="application/manifest+json")


@require_safe
def service_worker(request):
    response = HttpResponse(
        (ASSETS / "sw.js").read_text(encoding="utf-8"),
        content_type="application/javascript",
    )
    response["Cache-Control"] = "no-cache"
    return response


@require_safe
def install_script(request):
    return HttpResponse(
        (ASSETS / "install.js").read_text(encoding="utf-8"),
        content_type="application/javascript",
    )


@require_safe
def icon(request, size):
    if size not in (192, 512):
        raise Http404
    return FileResponse((ASSETS / f"icon-{size}.png").open("rb"), content_type="image/png")


@require_safe
def offline(request):
    return render(request, "pwa/offline.html")
