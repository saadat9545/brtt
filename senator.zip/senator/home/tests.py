
from io import BytesIO

from PIL import Image
from django.template.loader import get_template
from django.test import SimpleTestCase, override_settings
from django.urls import reverse


@override_settings(ALLOWED_HOSTS=['testserver'])
class PwaTests(SimpleTestCase):
    def test_manifest_and_real_icon_sizes_are_public(self):
        response = self.client.get(reverse('pwa_manifest'))
        self.assertEqual(response.status_code, 200)
        self.assertEqual(response['Content-Type'], 'application/manifest+json')
        manifest = response.json()
        self.assertEqual(manifest['start_url'], reverse('login'))
        self.assertEqual(manifest['scope'], '/')
        self.assertEqual(manifest['display'], 'standalone')
        self.assertEqual(len(manifest['icons']), 2)
        for icon in manifest['icons']:
            response = self.client.get(icon['src'])
            self.assertEqual(response.status_code, 200)
            with Image.open(BytesIO(b''.join(response.streaming_content))) as image:
                self.assertEqual(f'{image.width}x{image.height}', icon['sizes'])

    def test_worker_is_at_root_and_revalidated(self):
        self.assertEqual(reverse('pwa_service_worker'), '/sw.js')
        response = self.client.get('/sw.js')
        self.assertEqual(response.status_code, 200)
        self.assertEqual(response['Content-Type'], 'application/javascript')
        self.assertEqual(response['Cache-Control'], 'no-cache')

    def test_login_includes_install_resources(self):
        response = self.client.get(reverse('login'))
        self.assertContains(response, reverse('pwa_manifest'))
        self.assertContains(response, reverse('pwa_install_script'))
        self.assertNotContains(response, '/static/sw.js')

    def test_base_templates_include_install_resources(self):
        for name in ('base.html', 'base_admin.html', 'base_seller.html',
                     'base_master.html', 'customers/base.html'):
            with self.subTest(template=name):
                html = get_template(name).render({})
                self.assertIn(reverse('pwa_manifest'), html)
                self.assertIn(reverse('pwa_install_script'), html)

    def test_offline_screen_needs_no_login(self):
        response = self.client.get(reverse('pwa_offline'))
        self.assertContains(response, 'ارتباط با سناتور برقرار نیست')

    def test_unknown_icons_return_not_found(self):
        self.assertEqual(self.client.get('/pwa/icon-999.png').status_code, 404)

    def test_public_resources_reject_posts(self):
        for url in ('/manifest.webmanifest', '/sw.js', '/offline/',
                    '/pwa/install.js', '/pwa/icon-192.png'):
            with self.subTest(url=url):
                self.assertEqual(self.client.post(url).status_code, 405)
