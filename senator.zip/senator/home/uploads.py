from io import BytesIO
from uuid import uuid4
import warnings

from django.core.exceptions import ValidationError
from django.core.files.base import ContentFile
from PIL import Image, ImageOps, UnidentifiedImageError


def clean_image(upload):
    """Decode and re-encode uploads; never serve user-supplied HTML or metadata."""
    if upload.size > 5 * 1024 * 1024:
        raise ValidationError('حجم هر تصویر باید حداکثر ۵ مگابایت باشد.')
    try:
        with warnings.catch_warnings():
            warnings.simplefilter('error', Image.DecompressionBombWarning)
            upload.seek(0)
            with Image.open(upload) as image:
                if image.width * image.height > 20_000_000:
                    raise ValidationError('ابعاد تصویر بیش از حد مجاز است.')
                image.load()
                image = ImageOps.exif_transpose(image).convert('RGB')
                image.thumbnail((3000, 3000))
                output = BytesIO()
                image.save(output, format='JPEG', quality=90)
    except (UnidentifiedImageError, OSError, ValueError, Image.DecompressionBombError, Image.DecompressionBombWarning):
        raise ValidationError('فایل باید یک تصویر معتبر باشد.')
    finally:
        upload.seek(0)
    return ContentFile(output.getvalue(), name=f'{uuid4().hex}.jpg')
