from django.urls import path
from accounts.views import CustomLoginView, admin_dashboard, master_dashboard, seller_dashboard
from django.contrib.auth.views import LogoutView # این خط را اضافه کنید
from accounts import views
from home.views import health

urlpatterns = [
    path('health/', health, name='health'),
    path('', CustomLoginView.as_view(), name='login'),  # صفحه لاگین

    # مسیر پنل‌ها
    path('dashboard/admin/', admin_dashboard, name='admin_dashboard'),
    path('dashboard/master/', master_dashboard, name='master_dashboard'),
    # path('dashboard/seller/', seller_dashboard, name='seller_dashboard'),
    path('seller/orders/', seller_dashboard, name='seller_orders'),  # نام باید دقیقاً این باشد
    path('logout/', LogoutView.as_view(), name='logout'),
    # path('staff_management/', views.staff_management, name='staff_management'),
    # path('order_management/', views.order_management, name='order_management'),
    # path('settings/', views.settings, name='settings'),



]
