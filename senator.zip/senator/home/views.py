from django.shortcuts import render, redirect
from django.http import JsonResponse
from django.db import connection
from django.views.decorators.http import require_GET
from functools import wraps
from django.contrib.auth.views import LoginView
from django.core.exceptions import PermissionDenied

class CustomLoginView(LoginView):
    template_name = 'login.html'

    redirect_authenticated_user = True

    # در صورت نیاز به ارسال متغیرهای اضافی به قالب، می‌توانید از متد زیر استفاده کنید
    def get_context_data(self, **kwargs):
        context = super().get_context_data(**kwargs)
        # مثال: context['shop_name'] = 'مرکز تخصصی کیک و دسر سناتور'
        return context

@require_GET
def health(request):
    try:
        with connection.cursor() as cursor:
            cursor.execute('SELECT 1')
            cursor.fetchone()
        return JsonResponse({'ok': True, 'database': True})
    except Exception:
        return JsonResponse({'ok': False, 'database': False}, status=503)



def role_required(allowed_roles):
    """
    دکوراتوری برای محدود کردن دسترسی بر اساس نقش کاربر
    allowed_roles: لیستی از نقش‌های مجاز مثلا ['admin', 'master']
    """

    def decorator(view_func):
        @wraps(view_func)
        def _wrapped_view(request, *args, **kwargs):
            # ۱. اول چک میکنیم کاربر اصلا لاگین کرده یا نه
            if not request.user.is_authenticated:
                return redirect('login')  # نام url صفحه لاگین خود را جایگزین کنید

            # ۲. ادمین‌های کل سیستم (superuser) همیشه دسترسی دارند
            if request.user.is_superuser:
                return view_func(request, *args, **kwargs)

            # ۳. چک میکنیم آیا نقش کاربر در لیست نقش‌های مجاز این صفحه هست؟
            if getattr(request.user, 'role', None) in allowed_roles:
                return view_func(request, *args, **kwargs)
            else:
                # اگر کاربر مجاز نبود، خطای 403 (عدم دسترسی) میدهیم
                raise PermissionDenied

                # نکته: به جای خطای 403 میتوانید او را به داشبورد خودش پاس دهید:
                # if request.user.role == 'master': return redirect('master_dashboard')

        return _wrapped_view

    return decorator
