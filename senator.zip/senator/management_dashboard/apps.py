from django.apps import AppConfig


class management_dashboardConfig(AppConfig):
    name = 'management_dashboard'
