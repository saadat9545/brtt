from django.urls import path, include
from . import views


urlpatterns = [
    # آدرس های مدیریت استاد کاران
    path('staff_management/', views.staff_management, name='staff_management'),
    path('staff/add/', views.add_staff, name='add_staff'),
    path('staff/action/<int:user_id>/<str:action>/', views.staff_action, name='staff_action'),
    path('staff/edit/<int:id>/', views.edit_staff, name='edit_staff'),

    # فروشندگان
    path('sellers/', views.seller_management, name='seller_management'),
    path('seller/add/', views.add_staff, name='add_seller'),

    path('sellers/edit/<int:id>/', views.edit_seller, name='edit_seller'),
    path('sellers/action/<int:seller_id>/<str:action>/', views.seller_action, name='seller_action'),

    path('sellers/toggle-status/<int:id>/', views.toggle_seller_status, name='toggle_seller_status'),


    #سفارشات
    path('order_management/', views.order_management, name='order_management'),

    path('settings/', views.settings, name='settings'),

]