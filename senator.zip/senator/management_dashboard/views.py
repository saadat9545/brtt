from django.shortcuts import render, redirect, get_object_or_404
from django.contrib.auth import get_user_model
from django.contrib.auth.decorators import login_required
from django.core.paginator import Paginator
from django.db.models import Q
from django.contrib import messages
from home.views import role_required

from accounts.models import CustomUser

User = get_user_model()


@login_required
@role_required(allowed_roles=['admin'])
def staff_management(request):
    # تغییر اصلی اینجاست: فیلتر کردن بر اساس نقش استادکار
    staff_queryset = User.objects.filter(role='master', is_superuser=False).order_by('-date_joined')

    departments = []
    search_query = request.GET.get('q', '')
    if search_query:
        staff_queryset = staff_queryset.filter(
            Q(first_name__icontains=search_query) |
            Q(last_name__icontains=search_query) |
            Q(phone_number__icontains=search_query)
        )
    total_staff = staff_queryset.count()
    active_staff = staff_queryset.filter(is_active=True).count()
    inactive_staff = staff_queryset.filter(is_active=False).count()

    paginator = Paginator(staff_queryset, 10)
    page_number = request.GET.get('page')
    page_obj = paginator.get_page(page_number)

    context = {
        'staff_list': page_obj,
        'total_staff': total_staff,
        'active_staff': active_staff,
        'inactive_staff': inactive_staff,
        'search_query': search_query,
        'departments': departments,
    }
    return render(request, 'staff_management.html', context)

@login_required
@role_required(allowed_roles=['admin'])
def add_staff(request):
    if request.method == "POST":
        username = request.POST.get('username')
        password = request.POST.get('password')
        if not username or not password:
            messages.error(request, 'وارد کردن نام کاربری و رمز عبور الزامی است.')
            return redirect('staff_management')

        if CustomUser.objects.filter(username=username).exists():
            messages.error(request, 'این نام کاربری از قبل وجود دارد. لطفاً نام دیگری انتخاب کنید.')
            return redirect('staff_management')

        try:
            new_staff = CustomUser.objects.create_user(username=username, password=password)
            new_staff.status = 'active'
            new_staff.save()

            messages.success(request, 'پرسنل جدید با موفقیت ثبت شد.')
        except Exception as e:
            messages.error(request, f'خطایی در ثبت رخ داد: {str(e)}')

        return redirect('staff_management')
    return redirect('staff_management')

@login_required
@role_required(allowed_roles=['admin']) # اگر دکوراتور کاستوم دارید

@login_required
def staff_action(request, user_id, action):
    staff = get_object_or_404(CustomUser, id=user_id)

    if action == 'toggle_active':
        staff.is_active = not staff.is_active
        if not staff.is_active:
            staff.status = 'inactive'
        else:
            staff.status = 'active'
        staff.save()
        messages.success(request, "وضعیت اکانت با موفقیت تغییر کرد.")

    elif action == 'terminate':
        staff.status = 'terminated'
        staff.is_active = False
        staff.save()
        messages.success(request, "وضعیت به قطع همکاری تغییر یافت.")

    elif action == 'delete':
        staff.delete()
        messages.success(request, "پرسنل با موفقیت حذف شد.")

    return redirect('staff_management')


@login_required
@role_required(allowed_roles=['admin'])
def edit_staff(request, id):
    if request.method == 'POST':
        staff = get_object_or_404(User, id=id)

        staff.phone_number = request.POST.get('phone_number', staff.phone_number)
        staff.first_name = request.POST.get('first_name', staff.first_name)
        staff.last_name = request.POST.get('last_name', staff.last_name)
        staff.national_code = request.POST.get('national_code', staff.national_code)
        staff.department = request.POST.get('department', staff.department)

        if 'profile_picture' in request.FILES:
            staff.profile_picture = request.FILES['profile_picture']

        staff.save()
        messages.success(request, 'اطلاعات پرسنل با موفقیت بروزرسانی شد.')

    return redirect('staff_management')


# @login_required
# @role_required(allowed_roles=['admin'])
# def seller_management(request):
#     # کدهای مربوط به مدیریت فروشندگان
#     return render(request, 'base_admin.html') # یا هر قالب دیگری که دارید
#
#
#




@login_required
@role_required(allowed_roles=['admin'])
def order_management(request):
    return render(request, 'base_admin.html')


@login_required
@role_required(allowed_roles=['admin'])
def settings(request):
    # کدهای مربوط به تنظیمات
    return render(request, 'base_admin.html')


@login_required
@role_required(allowed_roles=['admin'])
def seller_management(request):
    if request.method == 'POST':
        username = request.POST.get('username')
        password = request.POST.get('password')
        first_name = request.POST.get('first_name')
        last_name = request.POST.get('last_name')
        phone_number = request.POST.get('phone_number')
        national_code = request.POST.get('national_code')
        address = request.POST.get('address')
        hire_date = request.POST.get('hire_date') or None
        profile_picture = request.FILES.get('profile_picture')

        if CustomUser.objects.filter(username=username).exists():
            messages.error(request, 'این نام کاربری قبلاً ثبت شده است.')
            return redirect('seller_management')

        user = CustomUser.objects.create_user(
            username=username,
            password=password,
            first_name=first_name,
            last_name=last_name,
            phone_number=phone_number,
            national_code=national_code,
            address=address,
            hire_date=hire_date,
            role='seller',
            profile_picture=profile_picture
        )
        messages.success(request, 'فروشنده با موفقیت اضافه شد.')
        return redirect('seller_management')

    # --- بخش مربوط به نمایش لیست و آمار (درخواست GET) ---

    # دریافت فروشندگان و مرتب‌سازی بر اساس تاریخ عضویت
    sellers = CustomUser.objects.filter(role='seller', is_superuser=False).order_by('-date_joined')

    # محاسبه آمار
    total_sellers = sellers.count()
    active_sellers = sellers.filter(status='active').count()
    # برای محاسبه آمار مرخصی و قطع همکاری، باید وضعیت‌های مربوطه را در مدل CustomUser داشته باشید
    # فرض می‌کنیم وضعیت مرخصی 'on_leave' و قطع همکاری 'terminated' است
    on_leave_sellers = sellers.filter(status='on_leave').count()
    terminated_sellers = sellers.filter(status='terminated').count()
    inactive_sellers = sellers.filter(is_active=False).count()
    context = {
        'sellers': sellers,
        'total_sellers': total_sellers,
        'active_sellers': active_sellers,
        'on_leave_sellers': on_leave_sellers,
        'inactive_sellers': inactive_sellers,
    }

    return render(request, 'seller_management.html', context)

@login_required
@role_required(allowed_roles=['admin'])
def edit_seller(request, id):
    if request.method == 'POST':
        seller = get_object_or_404(CustomUser, id=id, role='seller')

        seller.first_name = request.POST.get('first_name', seller.first_name)
        seller.last_name = request.POST.get('last_name', seller.last_name)
        seller.phone_number = request.POST.get('phone_number', seller.phone_number)
        seller.national_code = request.POST.get('national_code', seller.national_code)
        seller.address = request.POST.get('address', seller.address)

        if request.FILES.get('profile_picture'):
            seller.profile_picture = request.FILES.get('profile_picture')

        seller.save()
        messages.success(request, 'اطلاعات فروشنده با موفقیت بروزرسانی شد.')

    return redirect('seller_management')


@login_required
@role_required(allowed_roles=['admin'])
def toggle_seller_status(request, id):
    # تغییر وضعیت بین فعال و غیرفعال (مرخصی/تعلیق)
    seller = get_object_or_404(CustomUser, id=id, role='seller')
    if seller.status == 'active':
        seller.status = 'inactive'
        messages.warning(request, 'وضعیت فروشنده به مرخصی/تعلیق تغییر یافت.')
    else:
        seller.status = 'active'
        messages.success(request, 'اکانت فروشنده مجدداً فعال شد.')
    seller.save()  # متد save شما is_active را هم تنظیم می‌کند
    return redirect('seller_management')



@login_required
def seller_action(request, seller_id, action):
    if request.method == 'POST':
        # پیدا کردن فروشنده
        seller = get_object_or_404(CustomUser, id=seller_id, role='seller')

        if action == 'toggle_active':
            if seller.is_active:
                seller.status = 'inactive'
                seller.is_active = False
                messages.warning(request, f'اکانت فروشنده ({seller.username}) به حالت مرخصی/تعلیق درآمد.')
            else:
                seller.status = 'active'
                seller.is_active = True
                messages.success(request, f'اکانت فروشنده ({seller.username}) مجدداً فعال شد.')
            seller.save()

        elif action == 'terminate':
            seller.status = 'terminated'
            seller.is_active = False
            seller.save()
            messages.error(request, f'وضعیت فروشنده ({seller.username}) به قطع همکاری تغییر یافت.')

        elif action == 'delete':
            seller.delete()
            messages.success(request, 'سوابق فروشنده با موفقیت از سیستم حذف شد.')

    return redirect('seller_management')

@login_required
@role_required(allowed_roles=['admin'])
def add_seller(request):
    if request.method == "POST":
        username = request.POST.get('username')
        password = request.POST.get('password')
        if not username or not password:
            messages.error(request, 'وارد کردن نام کاربری و رمز عبور الزامی است.')
            return redirect('seller_management')

        if CustomUser.objects.filter(username=username).exists():
            messages.error(request, 'این نام کاربری از قبل وجود دارد. لطفاً نام دیگری انتخاب کنید.')
            return redirect('seller_management')

        try:
            new_staff = CustomUser.objects.create_user(username=username, password=password)
            new_staff.status = 'active'
            new_staff.save()

            messages.success(request, 'پرسنل جدید با موفقیت ثبت شد.')
        except Exception as e:
            messages.error(request, f'خطایی در ثبت رخ داد: {str(e)}')

        return redirect('seller_management')
    return redirect('seller_management')
