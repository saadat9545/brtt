from django.contrib import admin

from .models import OrderNotification, PushDelivery


@admin.register(OrderNotification)
class OrderNotificationAdmin(admin.ModelAdmin):
    list_display = ('id', 'order', 'recipient', 'created_at', 'read_at')
    list_filter = ('read_at',)
    readonly_fields = ('order', 'recipient', 'created_at', 'read_at')

    def has_add_permission(self, request):
        return False


@admin.register(PushDelivery)
class PushDeliveryAdmin(admin.ModelAdmin):
    list_display = ('id', 'notification', 'attempts', 'sent_at', 'abandoned', 'next_attempt_at', 'last_error')
    list_filter = ('abandoned', 'sent_at')
    readonly_fields = ('notification', 'subscription', 'attempts', 'sent_at', 'abandoned', 'next_attempt_at', 'last_error')

    def has_add_permission(self, request):
        return False
