from pathlib import Path

from django.conf import settings


def push_configuration():
    directory = Path(settings.WEBPUSH_KEY_DIR)
    private_key = settings.WEBPUSH_PRIVATE_KEY or str(directory / "private.pem")
    public_key = settings.WEBPUSH_PUBLIC_KEY
    if not public_key and (directory / "public.txt").is_file():
        public_key = (directory / "public.txt").read_text(encoding="ascii").strip()
    configured = bool(public_key and (settings.WEBPUSH_PRIVATE_KEY or Path(private_key).is_file()))
    return {"configured": configured, "private_key": private_key, "public_key": public_key}
