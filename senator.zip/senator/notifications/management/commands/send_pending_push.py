import time

from django.core.management.base import BaseCommand, CommandError
from django.db import close_old_connections

from notifications.config import push_configuration
from notifications.services import deliver_pending


class Command(BaseCommand):
    help = "Retry queued Push deliveries; use --loop as a supervised production worker."

    def add_arguments(self, parser):
        parser.add_argument("--loop", action="store_true")

    def handle(self, *args, **options):
        if not push_configuration()["configured"]:
            raise CommandError("Run setup_webpush or configure WEBPUSH_PRIVATE_KEY and WEBPUSH_PUBLIC_KEY first.")
        try:
            while True:
                close_old_connections()
                count = deliver_pending()
                if count or not options["loop"]:
                    self.stdout.write(f"Accepted by push service: {count}")
                if not options["loop"]:
                    break
                time.sleep(15)
        except KeyboardInterrupt:
            pass
