import base64
from pathlib import Path

from cryptography.hazmat.primitives import serialization
from cryptography.hazmat.primitives.asymmetric import ec
from django.conf import settings
from django.core.management.base import BaseCommand, CommandError


class Command(BaseCommand):
    help = "Create persistent VAPID keys once; existing private keys are never overwritten."

    def handle(self, *args, **options):
        directory = Path(settings.WEBPUSH_KEY_DIR)
        directory.mkdir(parents=True, exist_ok=True)
        private_path = directory / "private.pem"
        public_path = directory / "public.txt"
        if private_path.exists():
            key = serialization.load_pem_private_key(private_path.read_bytes(), password=None)
            if not isinstance(key, ec.EllipticCurvePrivateKey) or not isinstance(key.curve, ec.SECP256R1):
                raise CommandError("The existing private key is not a P-256 VAPID key.")
        else:
            key = ec.generate_private_key(ec.SECP256R1())
            with private_path.open("xb") as file:
                file.write(key.private_bytes(serialization.Encoding.PEM, serialization.PrivateFormat.PKCS8,
                                             serialization.NoEncryption()))
            private_path.chmod(0o600)
        public = key.public_key().public_bytes(serialization.Encoding.X962,
                                               serialization.PublicFormat.UncompressedPoint)
        public_path.write_text(base64.urlsafe_b64encode(public).rstrip(b"=").decode("ascii"), encoding="ascii")
        self.stdout.write(self.style.SUCCESS("Web Push keys are ready. Keep .webpush private and backed up."))
