from django.conf import settings
from django.db import models
from django.urls import reverse
from django.utils import timezone
from urllib.parse import urlencode


class PushSubscription(models.Model):
    user = models.ForeignKey(settings.AUTH_USER_MODEL, on_delete=models.CASCADE)
    endpoint = models.URLField(max_length=2048, unique=True)
    p256dh = models.CharField(max_length=100)
    auth = models.CharField(max_length=32)
    application_url = models.URLField(max_length=255)
    session_key = models.CharField(max_length=40)
    updated_at = models.DateTimeField(auto_now=True)

    def subscription_info(self):
        return {"endpoint": self.endpoint, "keys": {"p256dh": self.p256dh, "auth": self.auth}}


class OrderNotification(models.Model):
    recipient = models.ForeignKey(settings.AUTH_USER_MODEL, on_delete=models.CASCADE)
    order = models.ForeignKey("order.Order", on_delete=models.CASCADE)
    created_at = models.DateTimeField(default=timezone.now)
    read_at = models.DateTimeField(null=True, blank=True)

    class Meta:
        ordering = ["-id"]
        constraints = [models.UniqueConstraint(fields=["recipient", "order"], name="unique_order_notification")]
        indexes = [
            models.Index(fields=["recipient", "read_at", "-id"], name="notif_recipient_read_idx"),
        ]

    def payload(self):
        query = urlencode({"date": self.order.delivery_date.isoformat(), "order": self.order_id,
                           "notification": self.pk})
        # Lock-screen notifications deliberately omit customer names and phone numbers.
        return {
            "id": self.pk,
            "recipient_id": self.recipient_id,
            "title": "سفارش جدید سناتور",
            "body": f"سفارش شماره {self.order_id} به شما سپرده شد. برای مشاهده جزئیات بزنید.",
            "url": reverse("master_dashboard") + "?" + query,
            "tag": f"senator-order-{self.pk}",
            "read": self.read_at is not None,
        }


class PushDelivery(models.Model):
    notification = models.ForeignKey(OrderNotification, on_delete=models.CASCADE)
    subscription = models.ForeignKey(PushSubscription, on_delete=models.CASCADE)
    attempts = models.PositiveSmallIntegerField(default=0)
    next_attempt_at = models.DateTimeField(default=timezone.now, db_index=True)
    sent_at = models.DateTimeField(null=True, blank=True)
    abandoned = models.BooleanField(default=False)
    last_error = models.CharField(max_length=80, blank=True)

    class Meta:
        constraints = [models.UniqueConstraint(fields=["notification", "subscription"], name="unique_push_delivery")]
        indexes = [
            models.Index(fields=["sent_at", "abandoned", "next_attempt_at"], name="push_pending_idx"),
        ]
