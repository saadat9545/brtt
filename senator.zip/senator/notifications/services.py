import json
import logging
from datetime import timedelta

import requests
from django.conf import settings
from django.core.exceptions import ValidationError
from django.db.models import F
from django.utils import timezone
from pywebpush import WebPushException, webpush

from .config import push_configuration
from .models import PushDelivery
from .validation import validate_endpoint

logger = logging.getLogger(__name__)


class PushSession(requests.Session):
    def request(self, method, url, **kwargs):
        # Subscription endpoints must never redirect requests into a private network.
        validate_endpoint(url)
        kwargs["allow_redirects"] = False
        return super().request(method, url, **kwargs)


def deliver_pending(notification_id=None, limit=100):
    config = push_configuration()
    if not config["configured"]:
        return 0
    now = timezone.now()
    pending = PushDelivery.objects.filter(sent_at__isnull=True, abandoned=False, next_attempt_at__lte=now)
    if notification_id is not None:
        pending = pending.filter(notification_id=notification_id)
    ids = list(pending.order_by("next_attempt_at", "pk").values_list("pk", flat=True)[:limit])
    sent = 0
    for pk in ids:
        # A conditional update is also a lease, preventing two workers sending the same row together.
        if not PushDelivery.objects.filter(pk=pk, sent_at__isnull=True, abandoned=False,
                                           next_attempt_at__lte=now).update(
                next_attempt_at=now + timedelta(minutes=2), attempts=F("attempts") + 1):
            continue
        delivery = PushDelivery.objects.select_related(
            "subscription__user", "notification__order"
        ).filter(pk=pk).first()
        if delivery is None:
            continue
        subscription, notification = delivery.subscription, delivery.notification
        if (subscription.user_id != notification.recipient_id or not subscription.user.is_active
                or subscription.user.role != "master" or notification.order.master_id != subscription.user_id
                or notification.order.status == "canceled"
                or notification.created_at < now - timedelta(days=1)):
            PushDelivery.objects.filter(pk=pk).update(abandoned=True, last_error="recipient_or_order_changed")
            continue
        try:
            with PushSession() as session:
                response = webpush(
                    subscription_info=subscription.subscription_info(),
                    data=json.dumps(notification.payload(), ensure_ascii=False),
                    vapid_private_key=config["private_key"],
                    vapid_claims={"sub": settings.WEBPUSH_SUBJECT or subscription.application_url},
                    ttl=86400,
                    headers={"Urgency": "high"},
                    timeout=5,
                    requests_session=session,
                )
            if not 200 <= response.status_code < 300:
                raise WebPushException("Push service rejected notification", response=response)
        except Exception as exc:
            response = getattr(exc, "response", None)
            status = response.status_code if response is not None else None
            if status in (404, 410):
                subscription.delete()
                continue
            # Never log subscription secrets, payloads, or full provider exception text.
            error = f"http_{status}" if status else type(exc).__name__
            PushDelivery.objects.filter(pk=pk).update(
                last_error=error,
                abandoned=isinstance(exc, ValidationError) or delivery.attempts >= 8,
                next_attempt_at=timezone.now() + timedelta(seconds=min(60 * 2 ** min(delivery.attempts - 1, 6), 3600)),
            )
            logger.warning("Push delivery %s deferred (%s)", pk, error)
        else:
            PushDelivery.objects.filter(pk=pk).update(sent_at=timezone.now(), last_error="")
            sent += 1
    return sent
