from django.contrib.auth.signals import user_logged_out
from django.db import transaction
from django.db.models.signals import post_save
from django.dispatch import receiver

from order.models import Order
from .models import OrderNotification, PushDelivery, PushSubscription
from .services import deliver_pending


@receiver(post_save, sender=Order)
def notify_assigned_master(sender, instance, created, raw=False, **kwargs):
    if raw or not created or not instance.master_id:
        return
    if instance.master.role != "master" or not instance.master.is_active:
        return
    notification, _ = OrderNotification.objects.get_or_create(recipient=instance.master, order=instance)
    PushDelivery.objects.bulk_create([
        PushDelivery(notification=notification, subscription=subscription)
        for subscription in PushSubscription.objects.filter(user=instance.master)
    ], ignore_conflicts=True)
    # Keep delivery after commit so failed orders never generate a push.
    transaction.on_commit(lambda: deliver_pending(notification.pk), robust=True)


@receiver(user_logged_out)
def remove_logged_out_device(sender, request, user, **kwargs):
    if user is not None and request is not None and request.session.session_key:
        PushSubscription.objects.filter(user=user, session_key=request.session.session_key).delete()
