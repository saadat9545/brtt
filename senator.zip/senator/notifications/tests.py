import base64
import json
import tempfile
from datetime import timedelta
from io import StringIO
from pathlib import Path
from unittest.mock import Mock, patch

from cryptography.hazmat.primitives import serialization
from cryptography.hazmat.primitives.asymmetric import ec
from django.core.files.uploadedfile import SimpleUploadedFile
from django.core.management import call_command
from django.db import transaction
from django.test import Client, TestCase, override_settings
from django.urls import reverse
from django.utils import timezone
from pywebpush import WebPushException
from requests import Response

from accounts.models import CustomUser
from order.models import Order
from .models import OrderNotification, PushDelivery, PushSubscription
from .services import PushSession, deliver_pending


@override_settings(ALLOWED_HOSTS=['testserver', 'localhost'], WEBPUSH_PRIVATE_KEY='test-private-key',
                   WEBPUSH_PUBLIC_KEY='test-public-key', WEBPUSH_SUBJECT='https://senator.example')
class NotificationTests(TestCase):
    @classmethod
    def setUpTestData(cls):
        cls.master = CustomUser.objects.create_user(username='master', role='master', password='test-password')
        cls.other = CustomUser.objects.create_user(username='other', role='master')
        cls.seller = CustomUser.objects.create_user(username='seller', role='seller')
        public = ec.generate_private_key(ec.SECP256R1()).public_key().public_bytes(
            serialization.Encoding.X962, serialization.PublicFormat.UncompressedPoint)
        cls.keys = {
            'p256dh': base64.urlsafe_b64encode(public).rstrip(b'=').decode(),
            'auth': base64.urlsafe_b64encode(b'0123456789abcdef').rstrip(b'=').decode(),
        }

    def subscription(self, user=None, suffix='device'):
        return PushSubscription.objects.create(
            user=user or self.master, endpoint=f'https://fcm.googleapis.com/fcm/send/{suffix}',
            **self.keys, application_url='https://senator.example/', session_key='device-session')

    def order(self, **kwargs):
        defaults = dict(master=self.master, customer_name='Private name', customer_phone='09123456789',
                        delivery_date=timezone.localdate(), order_type='cake', registered_by=self.seller)
        defaults.update(kwargs)
        return Order.objects.create(**defaults)

    def post_json(self, name, data, **kwargs):
        return self.client.post(reverse(name), data=json.dumps(data), content_type='application/json',
                                secure=True, **kwargs)

    def test_order_notifies_only_assigned_master_on_all_their_devices_once(self):
        self.subscription(suffix='phone')
        self.subscription(suffix='desktop')
        self.subscription(self.other, 'other')
        with patch('notifications.signals.deliver_pending') as send:
            with self.captureOnCommitCallbacks(execute=True):
                order = self.order()
                self.assertFalse(send.called)
                order.description = 'Changed'
                order.save()
            send.assert_called_once()
        notification = OrderNotification.objects.get()
        self.assertEqual(notification.recipient, self.master)
        self.assertEqual(PushDelivery.objects.count(), 2)
        self.assertFalse(PushDelivery.objects.exclude(subscription__user=self.master).exists())

    def test_unassigned_order_has_no_notification(self):
        self.order(master=None)
        self.assertFalse(OrderNotification.objects.exists())

    def test_rolled_back_order_never_sends_or_leaves_notification(self):
        self.subscription()
        with patch('notifications.signals.deliver_pending') as send:
            with self.captureOnCommitCallbacks(execute=True):
                with self.assertRaises(RuntimeError):
                    with transaction.atomic():
                        self.order()
                        raise RuntimeError('upload failed')
            send.assert_not_called()
        self.assertFalse(Order.objects.exists())
        self.assertFalse(OrderNotification.objects.exists())
        self.assertFalse(PushDelivery.objects.exists())

    def order_post(self, **kwargs):
        data = dict(customer_name='Test Customer', phone_1='09123456789', delivery_date='1405/06/28',
                    order_type='cake', assigned_to=str(self.master.pk), price='1000', deposit='0')
        data.update(kwargs)
        self.client.force_login(self.seller)
        return self.client.post(reverse('seller_add_order'), data)

    def test_seller_registration_creates_notification_after_success(self):
        with patch('notifications.signals.deliver_pending') as send:
            with self.captureOnCommitCallbacks(execute=True):
                response = self.order_post()
            self.assertRedirects(response, reverse('seller_orders'), fetch_redirect_response=False)
            send.assert_called_once_with(OrderNotification.objects.get().pk)
        self.assertEqual(Order.objects.get().master, self.master)

    def test_image_failure_rolls_back_order_and_notification(self):
        with patch('seller_dashboard.views.OrderImage.objects.create', side_effect=RuntimeError('upload failed')):
            with patch('notifications.signals.deliver_pending') as send:
                with self.captureOnCommitCallbacks(execute=True):
                    self.order_post(images=SimpleUploadedFile('image.jpg', b'fake'))
                send.assert_not_called()
        self.assertFalse(Order.objects.exists())
        self.assertFalse(OrderNotification.objects.exists())

    def test_registration_rejects_nonmaster_inactive_and_malformed_recipient(self):
        self.master.status = 'inactive'
        self.master.save()
        for recipient in (str(self.seller.pk), str(self.master.pk), 'bad-id'):
            with self.subTest(recipient=recipient):
                self.order_post(assigned_to=recipient)
                self.assertFalse(Order.objects.exists())

    @patch('notifications.services.webpush')
    def test_delivery_payload_is_private_and_success_is_not_resent(self, send):
        sub = self.subscription()
        self.order()
        send.return_value = Mock(status_code=201)
        self.assertEqual(deliver_pending(), 1)
        self.assertEqual(deliver_pending(), 0)
        send.assert_called_once()
        args = send.call_args.kwargs
        self.assertEqual(args['subscription_info'], sub.subscription_info())
        self.assertEqual(args['headers']['Urgency'], 'high')
        self.assertEqual(args['timeout'], 5)
        self.assertNotIn('Private name', args['data'])
        self.assertNotIn('09123456789', args['data'])
        payload = json.loads(args['data'])
        self.assertIn('order=', payload['url'])
        self.assertIsNotNone(PushDelivery.objects.get().sent_at)

    @patch('notifications.services.webpush', side_effect=TimeoutError('private endpoint secret'))
    def test_outage_preserves_order_and_retries_later(self, send):
        self.subscription()
        with self.captureOnCommitCallbacks(execute=True):
            self.order()
        delivery = PushDelivery.objects.get()
        self.assertTrue(Order.objects.exists())
        self.assertIsNone(delivery.sent_at)
        self.assertEqual(delivery.last_error, 'TimeoutError')
        self.assertGreater(delivery.next_attempt_at, timezone.now())
        self.assertEqual(deliver_pending(), 0)
        send.side_effect = None
        send.return_value = Mock(status_code=201)
        PushDelivery.objects.update(next_attempt_at=timezone.now() - timedelta(seconds=1))
        self.assertEqual(deliver_pending(), 1)

    @patch('notifications.services.webpush')
    def test_expired_device_is_removed(self, send):
        self.subscription()
        self.order()
        response = Response()
        response.status_code = 410
        send.side_effect = WebPushException('Gone', response=response)
        deliver_pending()
        self.assertFalse(PushSubscription.objects.exists())
        self.assertTrue(OrderNotification.objects.exists())

    @patch('notifications.services.webpush')
    def test_reassignment_cancels_queued_delivery_to_previous_master(self, send):
        self.subscription()
        order = self.order()
        order.master = self.other
        order.save()
        deliver_pending()
        send.assert_not_called()
        self.assertTrue(PushDelivery.objects.get().abandoned)
        self.client.force_login(self.master)
        self.assertEqual(self.client.get(reverse('notifications:inbox')).json()['unread_count'], 0)

    def test_inbox_and_read_are_scoped_to_recipient(self):
        self.order()
        notification = OrderNotification.objects.get()
        self.client.force_login(self.other)
        self.assertEqual(self.client.get(reverse('notifications:inbox')).json()['notifications'], [])
        self.assertEqual(self.client.post(reverse('notifications:read', args=[notification.pk])).status_code, 404)
        self.client.force_login(self.master)
        response = self.client.get(reverse('notifications:inbox'))
        self.assertIn('no-store', response['Cache-Control'])
        self.assertEqual(response.json()['unread_count'], 1)
        url = reverse('notifications:read', args=[notification.pk])
        self.assertEqual(self.client.get(url).status_code, 405)
        self.assertEqual(self.client.post(url).status_code, 200)
        self.assertEqual(self.client.get(reverse('notifications:inbox')).json()['unread_count'], 0)

    def test_inbox_retains_unread_and_only_three_read_notifications(self):
        for _ in range(7):
            self.order()
        ids = list(OrderNotification.objects.values_list('pk', flat=True))
        OrderNotification.objects.filter(pk__in=ids[2:]).update(read_at=timezone.now())
        self.client.force_login(self.master)
        data = self.client.get(reverse('notifications:inbox')).json()
        self.assertEqual([item['id'] for item in data['notifications']], ids[:5])
        self.assertEqual(data['unread_count'], 2)
        for pk in ids[:2]:
            self.client.post(reverse('notifications:read', args=[pk]))
        data = self.client.get(reverse('notifications:inbox')).json()
        self.assertEqual([item['id'] for item in data['notifications']], ids[:3])
        self.assertEqual(data['unread_count'], 0)

    def test_unauthenticated_and_seller_cannot_use_notification_api(self):
        self.assertEqual(self.client.get(reverse('notifications:inbox')).status_code, 401)
        self.client.force_login(self.seller)
        self.assertEqual(self.client.get(reverse('notifications:inbox')).status_code, 403)
        self.assertEqual(self.post_json('notifications:subscribe', {}).status_code, 403)

    def test_subscription_validation_and_ownership(self):
        self.client.force_login(self.master)
        payload = {'endpoint': 'https://fcm.googleapis.com/fcm/send/test', 'keys': self.keys}
        for endpoint in ('http://127.0.0.1/', 'https://localhost/', 'https://fcm.googleapis.com.evil.example/',
                         'https://fcm.googleapis.com:8443/push', 'https://user:pass@fcm.googleapis.com/push'):
            with self.subTest(endpoint=endpoint):
                self.assertEqual(self.post_json('notifications:subscribe', {**payload, 'endpoint': endpoint}).status_code, 400)
        self.assertEqual(self.post_json('notifications:subscribe', {**payload, 'keys': {}}).status_code, 400)
        self.assertEqual(self.post_json('notifications:subscribe', payload).status_code, 200)
        self.assertEqual(self.post_json('notifications:subscribe', payload).status_code, 200)
        self.assertEqual(PushSubscription.objects.count(), 1)
        self.assertEqual(PushSubscription.objects.get().user, self.master)
        self.client.force_login(self.other)
        self.post_json('notifications:unsubscribe', {'endpoint': payload['endpoint']})
        self.assertTrue(PushSubscription.objects.exists())
        self.post_json('notifications:subscribe', payload)
        self.assertEqual(PushSubscription.objects.get().user, self.other)

    def test_csrf_is_required(self):
        client = Client(enforce_csrf_checks=True)
        client.force_login(self.master)
        self.assertEqual(client.post(reverse('notifications:subscribe'), '{}', content_type='application/json').status_code, 403)

    def test_logout_revokes_only_that_device(self):
        self.client.force_login(self.master)
        own = self.subscription()
        own.session_key = self.client.session.session_key
        own.save()
        other = self.subscription(suffix='other-device')
        self.client.post(reverse('logout'))
        self.assertFalse(PushSubscription.objects.filter(pk=own.pk).exists())
        self.assertTrue(PushSubscription.objects.filter(pk=other.pk).exists())

    def test_login_preserves_notification_link_but_rejects_external_redirect(self):
        target = '/dashboard/master/?date=2026-09-19&order=1&notification=1'
        response = self.client.post(reverse('login'), {'username': 'master', 'password': 'test-password', 'next': target})
        self.assertEqual(response.url, target)
        self.client.logout()
        response = self.client.post(reverse('login'), {'username': 'master', 'password': 'test-password', 'next': 'https://evil.example/'})
        self.assertEqual(response.url, reverse('master_dashboard'))

    def test_panel_renders_notification_controls(self):
        self.client.force_login(self.master)
        response = self.client.get(reverse('master_dashboard'))
        self.assertContains(response, 'enable-order-push')
        self.assertContains(response, reverse('notifications:script'))

    def test_real_encryption_signing_and_key_setup_without_network(self):
        self.subscription()
        self.order()
        with tempfile.TemporaryDirectory() as directory:
            with override_settings(WEBPUSH_KEY_DIR=directory, WEBPUSH_PRIVATE_KEY='', WEBPUSH_PUBLIC_KEY=''):
                call_command('setup_webpush', stdout=StringIO())
                private = (Path(directory) / 'private.pem').read_bytes()
                call_command('setup_webpush', stdout=StringIO())
                self.assertEqual((Path(directory) / 'private.pem').read_bytes(), private)
                response = Response()
                response.status_code = 201
                with patch('requests.Session.request', return_value=response) as request:
                    self.assertEqual(deliver_pending(), 1)
                    self.assertFalse(request.call_args.kwargs['allow_redirects'])
                    self.assertIn('authorization', {key.lower() for key in request.call_args.kwargs['headers']})
                    self.assertIsInstance(request.call_args.kwargs['data'], bytes)
