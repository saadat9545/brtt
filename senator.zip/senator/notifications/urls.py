from django.urls import path
from . import views

app_name = "notifications"
urlpatterns = [
    path("", views.inbox, name="inbox"),
    path("subscribe/", views.subscribe, name="subscribe"),
    path("unsubscribe/", views.unsubscribe, name="unsubscribe"),
    path("<int:pk>/read/", views.mark_read, name="read"),
    path("client.js", views.client_script, name="script"),
]
