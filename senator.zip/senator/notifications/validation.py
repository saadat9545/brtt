import base64
import binascii
from urllib.parse import urlsplit

from cryptography.hazmat.primitives.asymmetric import ec
from django.core.exceptions import ValidationError


def validate_endpoint(endpoint):
    if not isinstance(endpoint, str) or len(endpoint) > 2048:
        raise ValidationError("نشانی سرویس اعلان نامعتبر است.")
    try:
        url = urlsplit(endpoint)
        host = url.hostname or ""
        allowed = host == "fcm.googleapis.com" or any(
            host == domain or host.endswith("." + domain)
            for domain in ("push.services.mozilla.com", "push.apple.com", "notify.windows.com")
        )
        if (url.scheme != "https" or not allowed or url.port not in (None, 443)
                or url.username or url.password or url.fragment):
            raise ValueError
    except ValueError:
        raise ValidationError("نشانی سرویس اعلان پشتیبانی نمی‌شود.")
    return endpoint


def validate_subscription(data):
    try:
        endpoint = validate_endpoint(data["endpoint"])
        keys = data["keys"]
        p256dh, auth = keys["p256dh"], keys["auth"]
        if not isinstance(p256dh, str) or not isinstance(auth, str) or len(p256dh) > 100 or len(auth) > 32:
            raise ValueError
        point = base64.b64decode(p256dh + "=" * (-len(p256dh) % 4), altchars=b"-_", validate=True)
        secret = base64.b64decode(auth + "=" * (-len(auth) % 4), altchars=b"-_", validate=True)
        if len(point) != 65 or point[0] != 4 or len(secret) != 16:
            raise ValueError
        ec.EllipticCurvePublicKey.from_encoded_point(ec.SECP256R1(), point)
    except (KeyError, TypeError, ValueError, binascii.Error):
        raise ValidationError("اطلاعات فعال‌سازی اعلان نامعتبر است.")
    return endpoint, p256dh, auth
