import json
from functools import wraps
from pathlib import Path

from django.conf import settings
from django.core.exceptions import ValidationError
from django.db import transaction
from django.http import HttpResponse, JsonResponse
from django.shortcuts import get_object_or_404
from django.utils import timezone
from django.views.decorators.cache import never_cache
from django.views.decorators.http import require_GET, require_POST

from .config import push_configuration
from .models import OrderNotification, PushSubscription
from .validation import validate_endpoint, validate_subscription


def master_only(view):
    @wraps(view)
    def wrapped(request, *args, **kwargs):
        if not request.user.is_authenticated:
            return JsonResponse({"error": "ابتدا وارد حساب شوید."}, status=401)
        if request.user.role != "master" or not request.user.is_active:
            return JsonResponse({"error": "این بخش مخصوص استادکار است."}, status=403)
        return view(request, *args, **kwargs)
    return never_cache(wrapped)


@require_GET
@master_only
def inbox(request):
    notifications = OrderNotification.objects.filter(
        recipient=request.user, order__master=request.user
    ).exclude(order__status="canceled").select_related("order")
    config = push_configuration()
    # Unread orders remain accessible; retain only three read items in history.
    unread = list(notifications.filter(read_at__isnull=True)[:50])
    recent_read = list(notifications.filter(read_at__isnull=False)[:3])
    items = sorted(unread + recent_read, key=lambda item: item.pk, reverse=True)
    return JsonResponse({
        "notifications": [item.payload() for item in items],
        "unread_count": OrderNotification.objects.filter(
            recipient=request.user, order__master=request.user,
            read_at__isnull=True,
        ).exclude(order__status="canceled").count(),
        "public_key": config["public_key"] if config["configured"] else "",
        "configured": config["configured"],
    })


def json_body(request):
    if len(request.body) > 8192:
        raise ValueError
    body = json.loads(request.body)
    if not isinstance(body, dict):
        raise ValueError
    return body


@require_POST
@master_only
def subscribe(request):
    if not push_configuration()["configured"]:
        return JsonResponse({"error": "ارسال اعلان هنوز روی سرور فعال نشده است."}, status=503)
    try:
        endpoint, p256dh, auth = validate_subscription(json_body(request))
    except (ValueError, ValidationError) as exc:
        message = exc.messages[0] if isinstance(exc, ValidationError) else "درخواست نامعتبر است."
        return JsonResponse({"error": message}, status=400)
    origin = request.build_absolute_uri("/")
    if not request.is_secure():
        if request.get_host().split(":")[0] not in ("localhost", "127.0.0.1", "[::1]"):
            return JsonResponse({"error": "برای اعلان گوشی، سایت باید با HTTPS باز شود."}, status=400)
        origin = origin.replace("http://", "https://", 1)
    if not request.session.session_key:
        request.session.save()
    with transaction.atomic():
        # A browser endpoint belongs to one signed-in account at a time.
        PushSubscription.objects.filter(endpoint=endpoint).exclude(user=request.user).delete()
        PushSubscription.objects.update_or_create(endpoint=endpoint, defaults={
            "user": request.user, "p256dh": p256dh, "auth": auth,
            "application_url": origin, "session_key": request.session.session_key,
        })
    return JsonResponse({"ok": True})


@require_POST
@master_only
def unsubscribe(request):
    try:
        endpoint = validate_endpoint(json_body(request).get("endpoint"))
    except (ValueError, ValidationError):
        return JsonResponse({"error": "درخواست نامعتبر است."}, status=400)
    PushSubscription.objects.filter(user=request.user, endpoint=endpoint).delete()
    return JsonResponse({"ok": True})


@require_POST
@master_only
def mark_read(request, pk):
    notification = get_object_or_404(OrderNotification, pk=pk, recipient=request.user,
                                     order__master=request.user)
    if notification.read_at is None:
        OrderNotification.objects.filter(pk=pk, read_at__isnull=True).update(read_at=timezone.now())
    return JsonResponse({"ok": True})


@require_GET
def client_script(request):
    return HttpResponse((Path(settings.BASE_DIR) / "static/pwa/notifications.js").read_text(encoding="utf-8"),
                        content_type="application/javascript")
