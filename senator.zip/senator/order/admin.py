from django.contrib import admin
from .models import Order
import jdatetime


from django.contrib import admin
from .models import Order
import jdatetime

@admin.register(Order)
class OrderAdmin(admin.ModelAdmin):
    # فیلدهای weight و quantity به لیست اضافه شدند
    list_display = ('customer_name', 'taken_by', 'registered_by', 'master', 'weight', 'quantity', 'status', 'price', 'get_shamsi_created_at',
                    'get_shamsi_delivery_date')

    list_filter = ('status', 'taken_by', 'registered_by', 'master', 'created_at', 'delivery_date')

    search_fields = ('customer_name', 'customer_phone', 'taken_by__username', 'registered_by__username',
                     'master__username')

    autocomplete_fields = ('taken_by', 'registered_by', 'master')

    @admin.display(description='تاریخ و زمان ثبت', ordering='created_at')
    def get_shamsi_created_at(self, obj):
        if obj.created_at:
            shamsi_date = jdatetime.datetime.fromgregorian(datetime=obj.created_at)
            return shamsi_date.strftime('%Y/%m/%d %H:%M')
        return "-"

    @admin.display(description='تاریخ تحویل', ordering='delivery_date')
    def get_shamsi_delivery_date(self, obj):
        if obj.delivery_date:
            # تغییر به jdatetime.date به جای datetime و حذف ساعت و دقیقه
            shamsi_date = jdatetime.date.fromgregorian(date=obj.delivery_date)
            return shamsi_date.strftime('%Y/%m/%d')
        return "-"
