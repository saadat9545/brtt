from .models import OrderAudit


def snapshot(order):
    fields = ('customer_id', 'customer_name', 'customer_phone', 'customer_phone_2', 'delivery_date',
              'delivery_time', 'order_type', 'sponge', 'filling', 'cake_text', 'description', 'weight',
              'quantity', 'price', 'deposit', 'status', 'master_id', 'taken_by_id')
    return {name: str(getattr(order, name)) if getattr(order, name) is not None else None for name in fields}


def record(order, actor, action, before=None):
    OrderAudit.objects.create(order=order, order_number=order.pk, actor=actor,
                              action=action, before=before or {}, after=snapshot(order))
