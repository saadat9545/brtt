from decimal import Decimal, InvalidOperation
import re

from django import forms
from django.db.models import Q
from accounts.models import CustomUser
from customers.forms import JalaliDateField
from customers.validators import normalize_mobile, DIGIT_TRANSLATION
from home.access import is_manager
from .models import Order


class MoneyField(forms.IntegerField):
    def to_python(self, value):
        if isinstance(value, str):
            value = value.translate(DIGIT_TRANSLATION).replace(',', '').replace('٬', '').strip()
        return super().to_python(value)


class OrderForm(forms.ModelForm):
    price = MoneyField(min_value=0, max_value=2_147_483_647, required=False, label='مبلغ کل')
    deposit = MoneyField(min_value=0, max_value=2_147_483_647, required=False, label='بیعانه')
    quantity = MoneyField(min_value=1, max_value=1_000_000, required=False, label='تعداد')
    order_type = forms.ChoiceField(choices=[('cake', 'کیک'), ('pastry', 'شیرینی'), ('other', 'سایر')], label='نوع سفارش')

    class Meta:
        model = Order
        fields = ['customer_name', 'customer_phone', 'customer_phone_2', 'delivery_date', 'delivery_time',
                  'order_type', 'sponge', 'filling', 'cake_text', 'description', 'weight', 'quantity',
                  'price', 'deposit', 'master', 'taken_by']
        labels = {'customer_name': 'نام مشتری', 'customer_phone': 'موبایل مشتری', 'customer_phone_2': 'موبایل دوم',
                  'master': 'استادکار', 'taken_by': 'گیرنده سفارش', 'sponge': 'اسفنج', 'filling': 'فیلینگ',
                  'cake_text': 'متن روی کیک', 'description': 'توضیحات'}
        widgets = {'delivery_date': forms.DateInput(attrs={'type': 'date'}, format='%Y-%m-%d'),
                   'delivery_time': forms.TimeInput(attrs={'type': 'time'}, format='%H:%M'),
                   'description': forms.Textarea(attrs={'rows': 3}), 'cake_text': forms.TextInput()}

    def __init__(self, *args, user, jalali=False, **kwargs):
        super().__init__(*args, **kwargs)
        self.fields['master'].queryset = CustomUser.objects.filter(role='master', is_active=True)
        self.fields['taken_by'].required = False
        self.fields['taken_by'].queryset = CustomUser.objects.filter(is_active=True).filter(Q(role='seller') | Q(pk=user.pk))
        if not is_manager(user):
            self.fields['taken_by'].queryset = CustomUser.objects.filter(pk=user.pk)
        if jalali:
            self.fields['delivery_date'] = JalaliDateField(label='تاریخ تحویل (شمسی)')
        for field in self.fields.values():
            field.widget.attrs.setdefault('class', 'w-full rounded-xl p-3 bg-gray-900 border border-gray-600 text-white')

    def clean_customer_phone(self):
        return normalize_mobile(self.cleaned_data['customer_phone'])

    def clean_customer_phone_2(self):
        value = self.cleaned_data.get('customer_phone_2')
        return normalize_mobile(value) if value else ''

    def clean_weight(self):
        value = (self.cleaned_data.get('weight') or '').translate(DIGIT_TRANSLATION).strip()
        if value:
            parts = re.split(r'\s*(?:تا|-)\s*', value)
            try:
                numbers = [Decimal(x) for x in parts]
                if len(numbers) > 2 or any(not n.is_finite() or n <= 0 or n > 10000 for n in numbers) or numbers != sorted(numbers):
                    raise ValueError
            except (InvalidOperation, ValueError):
                raise forms.ValidationError('وزن مثبت وارد کنید؛ مانند ۱٫۵ یا ۱ تا ۲.')
        return value

    def clean(self):
        data = super().clean()
        for name in ('price', 'deposit'):
            if name not in self.errors:
                data[name] = data.get(name) or 0
        if data.get('deposit', 0) > data.get('price', 0):
            self.add_error('deposit', 'بیعانه نمی‌تواند از مبلغ کل بیشتر باشد.')
        return data
