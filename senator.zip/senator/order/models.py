from django.db import models
from django.conf import settings
from django.db import models
from django.conf import settings
from  accounts.models import CustomUser
from customers.models import Customer  # بالای فایل


class Order(models.Model):
    STATUS_CHOICES = (
        ('pending', 'در انتظار'),
        ('registered', 'ثبت شده'),
        ('in_progress', 'در حال انجام'),
        ('canceled', 'لغو شده'),
    )
    customer = models.ForeignKey(
        Customer,
        null=True,
        blank=True,
        on_delete=models.SET_NULL,
        related_name='orders'
    )
    # --- فیلدهای مشتری ---
    customer_name = models.CharField(max_length=255)
    customer_phone = models.CharField(max_length=20)
    customer_phone_2 = models.CharField(max_length=20, blank=True, null=True)

    # --- زمان‌بندی (اصلاح شده) ---
    delivery_date = models.DateField(verbose_name='تاریخ تحویل')
    delivery_time = models.TimeField(verbose_name='ساعت تحویل', blank=True, null=True)
    created_at = models.DateTimeField(auto_now_add=True, verbose_name='تاریخ و ساعت ثبت')

    # --- جزئیات سفارش ---
    order_type = models.CharField(max_length=100, choices=[('cake', '???'), ('pastry', '??????'), ('other', '????')])
    sponge = models.CharField(max_length=255, blank=True, null=True)
    filling = models.CharField(max_length=255, blank=True, null=True)
    description = models.TextField(blank=True, null=True)
    cake_text = models.TextField(blank=True, null=True)
    # اضافه کردن فیلدهای وزن و تعداد
    weight = models.CharField(verbose_name='وزن', blank=True, null=True)
    quantity = models.IntegerField(verbose_name='تعداد', blank=True, null=True)

    # --- فیلدهای مالی ---
    price = models.IntegerField(default=0)
    deposit = models.IntegerField(default=0)

    # --- وضعیت ---
    status = models.CharField(max_length=20, choices=STATUS_CHOICES, default='pending')

    # --- ارتباط با کاربران ---
    taken_by = models.ForeignKey(settings.AUTH_USER_MODEL, related_name='taken_orders', on_delete=models.SET_NULL,
                                 null=True)
    registered_by = models.ForeignKey(settings.AUTH_USER_MODEL, related_name='registered_orders',
                                      on_delete=models.SET_NULL, null=True)

    # فیلد اختصاصی استادکار (بدون فیلد اضافی assigned_to)
    master = models.ForeignKey(
        settings.AUTH_USER_MODEL,
        related_name='master_orders',
        on_delete=models.SET_NULL,
        null=True,
        blank=True
    )

    class Meta:
        ordering = ['-created_at']
        indexes = [models.Index(fields=['delivery_date', 'delivery_time']), models.Index(fields=['master', 'delivery_date'])]

    def __str__(self):
        return f"سفارش {self.id} - {self.customer_name}"

class OrderImage(models.Model):
    order = models.ForeignKey(Order, on_delete=models.CASCADE, related_name='images')
    image = models.ImageField(upload_to='order_images/')
    caption = models.CharField(max_length=255, null=True, blank=True) #

class OrderAudit(models.Model):
    order = models.ForeignKey(Order, null=True, on_delete=models.SET_NULL, related_name='audit_entries')
    order_number = models.PositiveBigIntegerField()
    actor = models.ForeignKey(settings.AUTH_USER_MODEL, null=True, on_delete=models.SET_NULL)
    action = models.CharField(max_length=30, choices=[('create', '???'), ('edit', '??????'), ('delete', '???'), ('cancel_order', '???'), ('reactivate_order', '????????? ????'), ('start_order', '???? ??????????'), ('complete_order', '?????')])
    before = models.JSONField(default=dict)
    after = models.JSONField(default=dict)
    created_at = models.DateTimeField(auto_now_add=True)

    class Meta:
        ordering = ['-created_at', '-pk']
