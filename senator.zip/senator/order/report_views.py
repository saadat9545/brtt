﻿from django.shortcuts import render
from django.contrib.auth.decorators import login_required
from django.db.models import Q
from django.core.paginator import Paginator
from .models import Order

@login_required
def order_report(request):
    if getattr(request.user, 'role', None) == 'seller':
        from django.shortcuts import redirect
        return redirect('seller_orders')
    qs = Order.objects.select_related('master','taken_by').order_by('-delivery_date','-delivery_time','-id')
    if getattr(request.user, 'role', None) == 'master' and not request.user.is_superuser:
        qs = qs.filter(master=request.user)
    start = request.GET.get('start_date','').strip()
    end = request.GET.get('end_date','').strip()
    search = request.GET.get('q','').strip()
    if start:
        qs = qs.filter(delivery_date__gte=start)
    if end:
        qs = qs.filter(delivery_date__lte=end)
    if search:
        qs = qs.filter(Q(customer_name__icontains=search)|Q(customer_phone__icontains=search))
    paginator = Paginator(qs, 50)
    page_number = request.GET.get('page', 1)
    orders = paginator.get_page(page_number)
    return render(request, 'order_report.html', {
        'orders': orders,
        'start_date': start,
        'end_date': end,
        'search': search,
    })

