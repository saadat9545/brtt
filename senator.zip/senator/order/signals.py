from django.db import transaction
from django.db.models.signals import post_delete, pre_save
from django.dispatch import receiver
from accounts.models import CustomUser
from .models import OrderImage


def remove_after_commit(field):
    if field and field.name:
        storage, name = field.storage, field.name
        transaction.on_commit(lambda: storage.delete(name), robust=True)


@receiver(post_delete, sender=OrderImage)
def delete_order_file(sender, instance, **kwargs):
    remove_after_commit(instance.image)


@receiver(post_delete, sender=CustomUser)
def delete_profile_file(sender, instance, **kwargs):
    remove_after_commit(instance.profile_picture)


@receiver(pre_save, sender=CustomUser)
def replace_profile_file(sender, instance, **kwargs):
    if instance.pk:
        old = sender.objects.filter(pk=instance.pk).first()
        if old and old.profile_picture != instance.profile_picture:
            remove_after_commit(old.profile_picture)
