from django.test import TestCase
from django.urls import reverse
from django.utils import timezone
from accounts.models import CustomUser
from .models import Order


class OrderReportTests(TestCase):
    def test_report_limits_rows_and_preserves_master_scope(self):
        master = CustomUser.objects.create_user(username='report-master', role='master')
        other = CustomUser.objects.create_user(username='report-other', role='master')
        Order.objects.bulk_create([
            Order(master=master, customer_name='Report', customer_phone='09123456789',
                  order_type='cake', delivery_date=timezone.localdate()) for _ in range(53)
        ] + [Order(master=other, customer_name='Other', customer_phone='09123456789',
                   order_type='cake', delivery_date=timezone.localdate())])
        self.client.force_login(master)
        first = self.client.get(reverse('orders:order_report'))
        self.assertEqual(len(first.context['orders']), 50)
        self.assertEqual(first.context['orders'].paginator.count, 53)
        second = self.client.get(reverse('orders:order_report'), {'page': 2, 'q': 'Report'})
        self.assertEqual(len(second.context['orders']), 3)
        self.assertContains(second, 'q=Report')
        self.assertTrue(all(order.master_id == master.pk for order in second.context['orders']))
        self.assertFalse(set(o.pk for o in first.context['orders']) & set(o.pk for o in second.context['orders']))
