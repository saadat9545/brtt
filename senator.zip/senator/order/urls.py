﻿from django.urls import path
from seller_dashboard import views
from .report_views import order_report

app_name = 'orders'

urlpatterns = [
    path('', order_report, name='order_report'),
    path('<int:pk>/', views.seller_order_detail, name='order_detail'),
    path('create/', views.seller_add_order, name='order_create'),
]
