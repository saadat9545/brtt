from django.urls import path
from . import views
from accounts.views import CustomLoginView, admin_dashboard, master_dashboard, seller_dashboard
urlpatterns = [
    # لیست سفارشات
    # path('orders/', views.seller_orders, name='seller_orders'),

    path('', seller_dashboard, name='seller_dashboard'),
    path('orders/add/', views.seller_add_order, name='seller_add_order'),
    path("orders/<int:order_id>/", views.seller_order_detail, name="seller_order_detail"),
    path('orders/', seller_dashboard, name='نام_url_لیست_سفارشات'),
    # path('seller_dashboard/customer', views.seller_dashboard_customer, name='seller_dashboard_customer'),

]
