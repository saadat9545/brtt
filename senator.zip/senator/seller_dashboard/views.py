from django.shortcuts import render, redirect, get_object_or_404
from django.contrib import messages
from django.contrib.auth.decorators import login_required
from order.models import Order, OrderImage
from accounts.models import CustomUser
import jdatetime
from django.urls import reverse
from customers.models import Customer
from django.db import transaction


@login_required
def seller_add_order(request):
    sellers = CustomUser.objects.filter(role='seller', is_superuser=False)
    cake_masters = CustomUser.objects.filter(role='master', department='cake', is_superuser=False, is_active=True)
    pastry_masters = CustomUser.objects.filter(role='master', department='sweat', is_superuser=False, is_active=True)

    context = {
        'sellers': sellers,
        'cake_masters': cake_masters,
        'pastry_masters': pastry_masters,
    }

    if request.method == 'POST':
        customer_name = request.POST.get('customer_name')
        phone_1 = request.POST.get('phone_1')
        phone_2 = request.POST.get('phone_2')

        vazn_str = request.POST.get('weight')
        vazn = vazn_str if vazn_str else None

        tedad_str = request.POST.get('quantity')
        tedad = int(tedad_str) if tedad_str else None

        delivery_date_str = request.POST.get('delivery_date')
        delivery_time = request.POST.get('delivery_time')

        order_type = request.POST.get('order_type')
        cake_sponge = request.POST.get('cake_sponge') if order_type == 'cake' else None
        cake_filling = request.POST.get('cake_filling') if order_type == 'cake' else None
        description = request.POST.get('description')

        total_price_str = request.POST.get('total_price')
        deposit_str = request.POST.get('deposit')

        total_price = int(total_price_str.replace(',', '')) if total_price_str else 0
        deposit = int(deposit_str.replace(',', '')) if deposit_str else 0

        if not delivery_time:
            delivery_time = None

        delivery_date_gregorian = None
        if delivery_date_str:
            persian_to_english = str.maketrans('۰۱۲۳۴۵۶۷۸۹', '0123456789')
            delivery_date_str = delivery_date_str.translate(persian_to_english)
            try:
                year, month, day = map(int, delivery_date_str.split('/'))
                delivery_date_gregorian = jdatetime.date(year, month, day).togregorian()
            except ValueError:
                messages.error(request, 'فرمت تاریخ نامعتبر است.')
                return redirect('seller_add_order')

        master_id = request.POST.get('assigned_to')
        assigned_master = None
        if master_id:
            try:
                assigned_master = CustomUser.objects.filter(id=master_id, role='master', is_active=True).first()
            except (ValueError, TypeError):
                assigned_master = None
            if assigned_master is None:
                messages.error(request, 'استادکار انتخاب‌شده معتبر یا فعال نیست.')
                return redirect('seller_add_order')

        taken_by_id = request.POST.get('taken_by')
        taken_by_user = request.user
        if taken_by_id:
            taken_by_user = CustomUser.objects.filter(id=taken_by_id).first()

        # ── مدیریت مشتری ──────────────────────────────────────────────
        # ── مدیریت مشتری ──────────────────────────────────────────────
        customer_obj = None
        if phone_1:
            name_parts = (customer_name or '').strip().split(' ', 1)
            first_name = name_parts[0] or 'نامشخص'  # اگه نام خالی بود fallback
            last_name = name_parts[1] if len(name_parts) > 1 else ''

            try:
                customer_obj, created = Customer.objects.get_or_create(
                    phone_number=phone_1,
                    defaults={
                        'first_name': first_name,
                        'last_name': last_name,
                    }
                )
                print(f"[DEBUG customer] obj={customer_obj.id}, created={created}, name={customer_obj.first_name}")
            except Exception as e:
                print(f"[DEBUG customer ERROR] {e}")
                # ادامه می‌دیم حتی اگه customer ثبت نشد
        else:
            print(f"[DEBUG customer] phone_1 is empty, skipping")

        # ──────────────────────────────────────────────────────────────

        try:
            with transaction.atomic():
                new_order = Order.objects.create(
                    registered_by=request.user,
                    taken_by=taken_by_user,
                    master=assigned_master,
                    customer=customer_obj,
                    customer_name=customer_name,
                    customer_phone=phone_1,
                    customer_phone_2=phone_2,
                    delivery_date=delivery_date_gregorian,
                    delivery_time=delivery_time,
                    order_type=order_type,
                    weight=vazn,
                    quantity=tedad,
                    sponge=cake_sponge,
                    filling=cake_filling,
                    description=description,
                    price=total_price,
                    deposit=deposit
                )

                images = request.FILES.getlist('images')
                captions = request.POST.getlist('captions')

                for i, img in enumerate(images):
                    cap = captions[i] if i < len(captions) else ""
                    OrderImage.objects.create(order=new_order, image=img, caption=cap)

            messages.success(request, 'سفارش با موفقیت ثبت شد.')
            return redirect('seller_orders')

        except Exception as e:
            print(f"Error creating order: {str(e)}")
            messages.error(request, f'خطایی در ثبت سفارش رخ داد: {str(e)}')
            return redirect('seller_add_order')

    return render(request, 'seller_add_order.html', context)








def seller_orders(request):
    # دریافت کلمه جستجو شده
    query = request.GET.get('q', '')

    # دریافت همه سفارشات
    orders = Order.objects.all().order_by('-id')

    # اگر چیزی سرچ شده بود، فیلتر کن
    if query:
        orders = orders.filter(customer_name__icontains=query)  # یا فیلترهای دیگر

    context = {
        'orders': orders,
        # متغیرهای آماری شما مثل today_orders_count و ... هم باید اینجا پاس داده شوند
    }

    return render(request, 'seller_dashboard.html', context)


@login_required
def seller_order_detail(request, order_id):
    # ۱. دریافت سفارش
    order = get_object_or_404(
        Order.objects.select_related('taken_by', 'registered_by', 'master'),
        id=order_id
    )

    # ۲. پردازش درخواست‌های POST برای لغو و حذف (باید قبل از بقیه محاسبات باشد)
    if request.method == 'POST':
        action = request.POST.get('action')

        if action == 'cancel_order':
            order.status = 'canceled'
            order.save()
            messages.warning(request, f'سفارش #{order.id} با موفقیت لغو شد.')
            return redirect('seller_order_detail', order_id=order.id)

        # اضافه شدن بخش فعال‌سازی مجدد
        elif action == 'reactivate_order':
            order.status = 'pending'  # یا 'registered' (بسته به منطق برنامه شما)
            order.save()
            messages.success(request, f'سفارش #{order.id} مجدداً فعال شد.')
            return redirect('seller_order_detail', order_id=order.id)

        elif action == 'delete_order':

            order_id_deleted = order.id

            order.delete()

            messages.error(request, f'سفارش #{order_id_deleted} برای همیشه حذف شد.')

            # ۱. گرفتن آدرس اصلی داشبورد

            url = reverse('seller_dashboard')

            # ۲. گرفتن پارامتر تاریخ از درخواست (اگر در آدرس وجود داشت)

            date_param = request.GET.get('date', '')

            # ۳. چسباندن پارامتر به انتهای آدرس در صورت وجود

            if date_param:
                url += f'?date={date_param}'

            return redirect(url)

        elif action == 'edit_order':


            order.customer_name = request.POST.get('customer_name', order.customer_name)

            order.customer_phone = request.POST.get('customer_phone', order.customer_phone)

            order.customer_phone_2 = request.POST.get('customer_phone_2', order.customer_phone_2)

            # مشخصات فنی کیک / سفارش

            order.order_type = request.POST.get('order_type', order.order_type)

            order.sponge = request.POST.get('sponge', order.sponge)

            order.filling = request.POST.get('filling', order.filling)

            # order.cake_text = request.POST.get('description', order.cake_text)

            order.description = request.POST.get('description', order.description)

            # فیلدهای عددی (اگر مقداری ارسال شده بود، آپدیت کن)

            weight = request.POST.get('weight')

            if weight: order.weight = weight

            quantity = request.POST.get('quantity')

            if quantity: order.quantity = quantity

            price = request.POST.get('price')

            if price: order.price = price

            deposit = request.POST.get('deposit')

            if deposit: order.deposit = deposit

            # تاریخ و زمان تحویل

            delivery_time = request.POST.get('delivery_time')

            if delivery_time: order.delivery_time = delivery_time

            delivery_date = request.POST.get('delivery_date')

            if delivery_date:
                # ⚠️ نکته مهم: اگر در فرانت‌اند از تقویم شمسی استفاده می‌کنید،

                # مقدار ارسال شده شمسی است و باید اینجا به میلادی تبدیل شود.

                # در غیر این صورت همین خط کافیست.

                order.delivery_date = delivery_date

            order.save()
            return redirect('seller_order_detail', order_id=order.id)

    order_images = order.images.all()

    # ۴. تبدیل تاریخ و زمان به شمسی
    if order.created_at:
        order.shamsi_created_at = jdatetime.datetime.fromgregorian(
            datetime=order.created_at
        ).strftime('%Y/%m/%d %H:%M')
    else:
        order.shamsi_created_at = "نامشخص"

    if order.delivery_date:
        order.shamsi_delivery_date = jdatetime.date.fromgregorian(
            date=order.delivery_date
        ).strftime('%Y/%m/%d')
    else:
        order.shamsi_delivery_date = "نامشخص"

    # ۵. محاسبه مانده حساب
    remaining_balance = 0
    if order.price and order.deposit:
        remaining_balance = order.price - order.deposit
    elif order.price:
        remaining_balance = order.price

    context = {
        "order": order,
        "images": order_images,
        "remaining_balance": remaining_balance,
    }

    return render(request, "seller_order_detail.html", context)
