"""
URL configuration for senator project.

The `urlpatterns` list routes URLs to views. For more information please see:
    https://docs.djangoproject.com/en/6.0/topics/http/urls/
Examples:
Function views
    1. Add an import:  from my_app import views
    2. Add a URL to urlpatterns:  path('', views.home, name='home')
Class-based views
    1. Add an import:  from other_app.views import Home
    2. Add a URL to urlpatterns:  path('', Home.as_view(), name='home')
Including another URLconf
    1. Import the include() function: from django.urls import include, path
    2. Add a URL to urlpatterns:  path('blog/', include('blog.urls'))
"""
from django.contrib import admin
from django.urls import path, include
from django.conf import settings
from django.conf.urls.static import static
from home import pwa
from home.media import private_media

urlpatterns = [
    path('media/<path:path>', private_media, name='private_media'),
    path('manifest.webmanifest', pwa.manifest, name='pwa_manifest'),
    path('sw.js', pwa.service_worker, name='pwa_service_worker'),
    path('pwa/install.js', pwa.install_script, name='pwa_install_script'),
    path('pwa/icon-<int:size>.png', pwa.icon, name='pwa_icon'),
    path('offline/', pwa.offline, name='pwa_offline'),
    path('notifications/', include('notifications.urls')),
    path('admin/', admin.site.urls),
    path('', include('home.urls')),
    path('management_dashboard/', include('management_dashboard.urls')),
    path('seller_dashboard/', include('seller_dashboard.urls')),
    path('customers/', include('customers.urls', namespace='customers')),
    path('orders/', include('order.urls', namespace='orders')),  # ← namespace اینجا هم باید باشه

]

