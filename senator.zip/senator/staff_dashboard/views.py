from django.shortcuts import render

# Create your views here.
import jdatetime
from django.shortcuts import render
from django.contrib.auth.decorators import login_required
from .models import Order

@login_required
def master_dashboard(request):
    # تاریخ پیش‌فرض: امروز شمسی
    today_shamsi = jdatetime.date.today()
    selected_date_str = request.GET.get('date')

    if selected_date_str:
        try:
            # دریافت تاریخ انتخاب شده از فرم
            y, m, d = map(int, selected_date_str.split('-'))
            selected_date = jdatetime.date(y, m, d)
        except ValueError:
            selected_date = today_shamsi
    else:
        selected_date = today_shamsi
        selected_date_str = selected_date.strftime('%Y-%m-%d')

    # تبدیل تاریخ شمسی به میلادی برای فیلتر در دیتابیس
    gregorian_date = selected_date.togregorian()

    # فیلتر سفارشات مربوط به همین استادکار در تاریخ مشخص شده
    orders = Order.objects.filter(
        master=request.user,
        delivery_date__date=gregorian_date
    ).order_by('delivery_date')

    order_count = orders.count()

    context = {
        'orders': orders,
        'order_count': order_count,
        'selected_date_str': selected_date_str,
        'is_today': selected_date == today_shamsi
    }
    return render(request, 'master_dashboard.html', context)
