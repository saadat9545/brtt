(() => {
    let installPrompt = null;
    let installButton = null;
    const standalone = window.matchMedia('(display-mode: standalone)');

    function hideInstall() {
        installPrompt = null;
        if (installButton) installButton.hidden = true;
    }

    window.addEventListener('beforeinstallprompt', (event) => {
        event.preventDefault();
        if (standalone.matches) return;
        installPrompt = event;
        if (!installButton) {
            installButton = document.createElement('button');
            installButton.type = 'button';
            installButton.textContent = 'نصب سناتور روی دستگاه';
            installButton.setAttribute('aria-label', 'نصب برنامه سناتور روی دستگاه');
            installButton.style.cssText = 'position:fixed;bottom:20px;left:20px;z-index:10000;' +
                'max-width:calc(100vw - 40px);padding:12px 20px;border:1px solid #f5b041;' +
                'border-radius:14px;background:#2c1a4d;color:#fff;font:14px Tahoma,sans-serif;' +
                'cursor:pointer;box-shadow:0 4px 20px #0005;direction:rtl';
            installButton.addEventListener('click', async () => {
                if (!installPrompt) return;
                installButton.disabled = true;
                try {
                    await installPrompt.prompt();
                    await installPrompt.userChoice;
                } catch (error) {
                    console.warn('Senator installation prompt failed:', error);
                } finally {
                    hideInstall();
                    installButton.disabled = false;
                }
            });
            document.body.appendChild(installButton);
        }
        installButton.hidden = false;
    });

    window.addEventListener('appinstalled', hideInstall);
    standalone.addEventListener('change', () => {
        if (standalone.matches) hideInstall();
    });

    if ('serviceWorker' in navigator && window.isSecureContext) {
        navigator.serviceWorker.register('/sw.js', {scope: '/'}).catch((error) => {
            console.warn('Senator service worker registration failed:', error);
        });
    }
})();
