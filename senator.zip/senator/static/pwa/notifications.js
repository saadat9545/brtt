(() => {
    'use strict';
    const panel = document.getElementById('order-notifications');
    if (!panel) return;
    const status = document.getElementById('notification-status');
    const enable = document.getElementById('enable-order-push');
    const disable = document.getElementById('disable-order-push');
    const soundButton = document.getElementById('enable-order-sound');
    const list = document.getElementById('notification-list');
    const toast = document.getElementById('notification-toast');
    const csrf = panel.querySelector('[name=csrfmiddlewaretoken]').value;
    const supported = window.isSecureContext && 'serviceWorker' in navigator &&
        'PushManager' in window && 'Notification' in window;
    const seen = new Set();
    let publicKey = '';
    let initialized = false;
    let stopped = false;
    let polling = false;
    let registration = null;
    let audio = null;
    let soundEnabled = false;

    async function api(url, body) {
        const response = await fetch(url, {
            credentials: 'same-origin', cache: 'no-store',
            ...(body === undefined ? {} : {
                method: 'POST', headers: {'Content-Type': 'application/json', 'X-CSRFToken': csrf},
                body: JSON.stringify(body),
            }),
        });
        if (response.status === 401 || response.status === 403 || response.redirected) {
            stopped = true;
            list.replaceChildren();
            document.getElementById('notification-count').textContent = '';
            throw new Error('برای دریافت اعلان، دوباره وارد حساب استادکار شوید.');
        }
        const data = await response.json();
        if (!response.ok) throw new Error(data.error || 'ارتباط با سرور برقرار نشد.');
        return data;
    }

    function decodeKey(value) {
        const decoded = atob(value.replace(/-/g, '+').replace(/_/g, '/') + '='.repeat((4 - value.length % 4) % 4));
        return Uint8Array.from(decoded, char => char.charCodeAt(0));
    }

    async function worker() {
        if (!registration) {
            await navigator.serviceWorker.register('/sw.js', {scope: '/'});
            registration = await navigator.serviceWorker.ready;
        }
        return registration;
    }

    function beep() {
        if (!soundEnabled || !audio || audio.state !== 'running') return;
        const now = audio.currentTime;
        for (const [delay, frequency] of [[0, 660], [0.22, 880]]) {
            const oscillator = audio.createOscillator();
            const gain = audio.createGain();
            oscillator.frequency.value = frequency;
            gain.gain.setValueAtTime(0, now + delay);
            gain.gain.linearRampToValueAtTime(0.15, now + delay + 0.02);
            gain.gain.exponentialRampToValueAtTime(0.001, now + delay + 0.2);
            oscillator.connect(gain);
            gain.connect(audio.destination);
            oscillator.start(now + delay);
            oscillator.stop(now + delay + 0.22);
            oscillator.onended = () => { oscillator.disconnect(); gain.disconnect(); };
        }
    }

    async function activateSound() {
        const Audio = window.AudioContext || window.webkitAudioContext;
        if (!Audio) return;
        audio = audio || new Audio();
        await audio.resume();
        soundEnabled = audio.state === 'running';
        soundButton.textContent = soundEnabled ? 'قطع صدای پنل' : 'فعال‌کردن صدای پنل';
        beep();
    }

    soundButton.addEventListener('click', async () => {
        if (soundEnabled) {
            soundEnabled = false;
            soundButton.textContent = 'فعال‌کردن صدای پنل';
        } else {
            try { await activateSound(); } catch (_) { status.textContent = 'مرورگر اجازه پخش صدا نداد.'; }
        }
    });

    async function syncDevice() {
        if (!supported || Notification.permission !== 'granted' || !publicKey) return;
        const reg = await worker();
        const subscription = await reg.pushManager.getSubscription();
        if (subscription) {
            await api(panel.dataset.subscribe, subscription.toJSON());
            enable.textContent = 'اعلان دستگاه فعال است';
            disable.hidden = false;
            status.textContent = 'اعلان این دستگاه فعال است؛ برای صدای داخل پنل، دکمه صدا را بزنید.';
        }
    }

    enable.addEventListener('click', async () => {
        enable.disabled = true;
        try {
            // Permission and audio must start directly from a user gesture (especially on iOS).
            const permissionPromise = Notification.requestPermission();
            const soundPromise = activateSound().catch(() => {});
            const permission = await permissionPromise;
            await soundPromise;
            if (permission !== 'granted') throw new Error('اجازه اعلان داده نشد؛ آن را از تنظیمات مرورگر فعال کنید.');
            const reg = await worker();
            let subscription = await reg.pushManager.getSubscription();
            if (subscription && subscription.options.applicationServerKey) {
                const existing = new Uint8Array(subscription.options.applicationServerKey);
                const desired = decodeKey(publicKey);
                if (existing.length !== desired.length || existing.some((byte, i) => byte !== desired[i])) {
                    await api(panel.dataset.unsubscribe, {endpoint: subscription.endpoint});
                    await subscription.unsubscribe();
                    subscription = null;
                }
            }
            subscription = subscription || await reg.pushManager.subscribe({
                userVisibleOnly: true, applicationServerKey: decodeKey(publicKey),
            });
            await api(panel.dataset.subscribe, subscription.toJSON());
            disable.hidden = false;
            enable.textContent = 'اعلان دستگاه فعال است';
            status.textContent = 'اعلان سفارش‌های جدید برای این دستگاه فعال شد.';
        } catch (error) {
            status.textContent = error.message || 'فعال‌سازی اعلان ناموفق بود.';
        } finally {
            enable.disabled = stopped || !publicKey;
        }
    });

    disable.addEventListener('click', async () => {
        disable.disabled = true;
        try {
            const subscription = await (await worker()).pushManager.getSubscription();
            if (subscription) {
                await api(panel.dataset.unsubscribe, {endpoint: subscription.endpoint});
                await subscription.unsubscribe();
            }
            disable.hidden = true;
            enable.textContent = 'فعال‌کردن اعلان دستگاه';
            status.textContent = 'اعلان گوشی در این دستگاه قطع شد؛ اعلان‌های داخل پنل باقی می‌مانند.';
        } catch (error) { status.textContent = error.message; }
        finally { disable.disabled = false; }
    });

    async function showSystemNotification(item) {
        if (!supported || Notification.permission !== 'granted') return;
        try {
            const reg = await worker();
            if (!await reg.pushManager.getSubscription()) return;
            const existing = await reg.getNotifications({tag: item.tag});
            if (existing.length) return;
            await reg.showNotification(item.title, {
                body: item.body, tag: item.tag,
                icon: '/pwa/icon-192.png', badge: '/pwa/icon-192.png',
                data: {url: item.url}, dir: 'rtl', lang: 'fa',
                silent: false,
            });
        } catch (_) { /* The in-app alert remains available if the OS rejects it. */ }
    }

    function announce(item, playSound = true, fromPush = false) {
        if (seen.has(item.id)) return;
        seen.add(item.id);
        if (!fromPush) showSystemNotification(item);
        // Only a visible panel plays the extra in-app chime; the OS handles background alerts.
        if (!document.hidden) {
            toast.textContent = item.body;
            toast.hidden = false;
            if (playSound) beep();
        }
    }

    async function read(id) {
        await api(panel.dataset.read.replace('/0/read/', `/${id}/read/`), {});
    }

    function render(data) {
        document.getElementById('notification-count').textContent = data.unread_count ? `(${data.unread_count} خوانده‌نشده)` : '';
        list.replaceChildren();
        if (!data.notifications.length) {
            const empty = document.createElement('li');
            empty.textContent = 'هنوز اعلان سفارشی ندارید.';
            list.appendChild(empty);
        }
        for (const item of data.notifications) {
            const row = document.createElement('li');
            const link = document.createElement('a');
            link.href = item.url;
            link.className = 'block rounded-xl p-3 border border-primary/20';
            link.textContent = `${item.read ? '' : '● '}${item.body}`;
            link.addEventListener('click', async event => {
                if (event.ctrlKey || event.metaKey || event.shiftKey || event.altKey) return;
                event.preventDefault();
                try { await read(item.id); } catch (_) { /* Opening the order remains available offline. */ }
                window.location.assign(item.url);
            });
            row.appendChild(link);
            list.appendChild(row);
        }
    }

    async function poll() {
        if (polling || stopped) return;
        polling = true;
        try {
            const data = await api(panel.dataset.inbox);
            publicKey = data.public_key;
            render(data);
            for (const item of data.notifications) {
                if (initialized && !item.read) announce(item);
                else seen.add(item.id);
            }
            if (!initialized) {
                initialized = true;
                enable.disabled = !supported || !data.configured;
                status.textContent = !supported ?
                    'اعلان گوشی به HTTPS و مرورگر سازگار نیاز دارد. در آیفون، برنامه را از صفحه اصلی باز کنید.' :
                    !data.configured ? 'اعلان داخل پنل فعال است؛ ارسال اعلان گوشی هنوز روی سرور تنظیم نشده است.' :
                    Notification.permission === 'denied' ? 'اجازه اعلان بسته است؛ آن را از تنظیمات مرورگر فعال کنید.' :
                    'برای دریافت اعلان هنگام بسته‌بودن برنامه، اعلان گوشی را فعال کنید.';
                try { await syncDevice(); } catch (error) { status.textContent = error.message; }
                const params = new URLSearchParams(window.location.search);
                const notificationId = Number(params.get('notification'));
                const item = data.notifications.find(n => n.id === notificationId);
                if (item) {
                    await read(item.id);
                    render(await api(panel.dataset.inbox));
                    const orderId = params.get('order');
                    if (/^\d+$/.test(orderId || '') && typeof window.openOrderModal === 'function') {
                        const modalId = `modal-${orderId}`;
                        if (document.getElementById(modalId)) window.openOrderModal(modalId);
                    }
                }
            }
        } catch (error) { status.textContent = error.message || 'ارتباط قطع است؛ تلاش مجدد انجام می‌شود.'; }
        finally { polling = false; }
    }

    if ('serviceWorker' in navigator) {
        navigator.serviceWorker.addEventListener('message', event => {
            const message = event.data;
            if (!message || message.type !== 'ORDER_PUSH' || stopped ||
                String(message.payload.recipient_id) !== panel.dataset.userId) return;
            announce(message.payload, true, true);
            poll();
        });
    }
    document.addEventListener('visibilitychange', () => { if (!document.hidden) poll(); });
    window.addEventListener('online', poll);
    poll();
    // A fallback for denied Push permission or a temporary provider outage.
    setInterval(() => { if (!document.hidden) poll(); }, 15000);
})();
