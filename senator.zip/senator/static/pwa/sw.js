// Only the public offline screen is cached. Customer data and POSTs stay on the network.
const OFFLINE_CACHE = 'senator-offline-v1';
const OFFLINE_URL = '/offline/';

self.addEventListener('install', (event) => {
    event.waitUntil(caches.open(OFFLINE_CACHE).then((cache) => cache.add(OFFLINE_URL)).then(() => self.skipWaiting()));
});

self.addEventListener('push', (event) => {
    event.waitUntil((async () => {
        let payload;
        try { payload = event.data.json(); } catch (_) { return; }
        if (!payload || !payload.id || !payload.recipient_id) return;
        const windows = await self.clients.matchAll({type: 'window', includeUncontrolled: true});
        // Always show a visible notification, as required by userVisibleOnly subscriptions.
        await self.registration.showNotification(payload.title || 'سفارش جدید سناتور', {
            body: payload.body,
            icon: '/pwa/icon-192.png',
            badge: '/pwa/icon-192.png',
            tag: payload.tag,
            data: {url: payload.url},
            dir: 'rtl', lang: 'fa',
            silent: false,
            vibrate: [200, 100, 200],
        });
        for (const client of windows) client.postMessage({type: 'ORDER_PUSH', payload});
    })());
});

self.addEventListener('notificationclick', (event) => {
    event.notification.close();
    event.waitUntil((async () => {
        const target = new URL(event.notification.data?.url || '/dashboard/master/', self.location.origin);
        if (target.origin !== self.location.origin || target.pathname !== '/dashboard/master/') return;
        const windows = await self.clients.matchAll({type: 'window', includeUncontrolled: true});
        const client = windows.find(item => new URL(item.url).pathname === target.pathname);
        if (client) {
            await client.navigate(target.href);
            await client.focus();
        } else {
            await self.clients.openWindow(target.href);
        }
    })());
});

self.addEventListener('activate', (event) => {
    event.waitUntil((async () => {
        for (const name of await caches.keys()) {
            if (name.startsWith('senator-offline-') && name !== OFFLINE_CACHE) {
                await caches.delete(name);
            }
        }
        await self.clients.claim();
    })());
});

self.addEventListener('fetch', (event) => {
    if (event.request.method !== 'GET' || event.request.mode !== 'navigate' ||
        new URL(event.request.url).origin !== self.location.origin) return;

    event.respondWith(fetch(event.request).catch(async () => {
        const offline = await caches.match(OFFLINE_URL, {cacheName: OFFLINE_CACHE});
        return offline || Response.error();
    }));
});
