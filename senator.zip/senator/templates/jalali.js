#%%
const Jalali = (() => {

  function toJalali(gy, gm, gd) {
    const g_d_m = [0,31,59,90,120,151,181,212,243,273,304,334];
    let jy;
    if (gy > 1600) {
      jy = 979;
      gy -= 1600;
    } else {
      jy = 0;
      gy -= 621;
    }

    let gy2 = gm > 2 ? gy + 1 : gy;
    let days = 365*gy + Math.floor((gy2+3)/4) - Math.floor((gy2+99)/100) + Math.floor((gy2+399)/400) - 80 + gd + g_d_m[gm-1];

    jy += 33*Math.floor(days/12053);
    days %= 12053;

    jy += 4*Math.floor(days/1461);
    days %= 1461;

    if (days > 365) {
      jy += Math.floor((days-1)/365);
      days = (days-1)%365;
    }

    let jm, jd;

    if (days < 186) {
      jm = 1 + Math.floor(days/31);
      jd = 1 + (days%31);
    } else {
      jm = 7 + Math.floor((days-186)/30);
      jd = 1 + ((days-186)%30);
    }

    return { jy, jm, jd };
  }

  function getMonthDays(year, month){
    if(month <= 6) return 31
    if(month <= 11) return 30
    return isLeap(year) ? 30 : 29
  }

  function isLeap(jy){
    const breaks = [-61,9,38,199,426,686,756,818,1111,1181,1210
      ,1635,2060,2097,2192,2262,2324,2394,2456,3178]

    let bl = breaks.length
    let jp = breaks[0]
    let jm
    let jump
    let leap
    let n

    if(jy < jp || jy >= breaks[bl-1]) return false

    for(let i=1;i<bl;i++){
      jm = breaks[i]
      jump = jm - jp
      if(jy < jm) break
      jp = jm
    }

    n = jy - jp

    if(jump - n < 6)
      n = n - jump + Math.floor((jump+4)/33)*33

    leap = ((n+1)%33 -1)%4
    if(leap === -1) leap = 4

    return leap === 0
  }

  return {
    toJalali,
    getMonthDays,
    isLeap
  }

})();


function buildCalendar(year, month){

  const days = Jalali.getMonthDays(year, month)

  const today = new Date()
  const j = Jalali.toJalali(
    today.getFullYear(),
    today.getMonth()+1,
    today.getDate()
  )

  let html = `<div class="calendar">`

  for(let i=1;i<=days;i++){

    let active = (i === j.jd && month === j.jm && year === j.jy)
      ? "today"
      : ""

    html += `<div class="day ${active}" data-day="${i}">
        ${i}
    </div>`
  }

  html += `</div>`

  return html
}
