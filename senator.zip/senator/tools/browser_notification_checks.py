"""Optional: pip install playwright; python manage.py test tools.browser_notification_checks.

Uses the locally installed Chrome and an isolated Django test database. Push provider
registration is mocked; no device is contacted and no production account is changed.
"""
import base64
import json
from concurrent.futures import ThreadPoolExecutor
from pathlib import Path
from unittest.mock import Mock, patch

from cryptography.hazmat.primitives import serialization
from cryptography.hazmat.primitives.asymmetric import ec
from django.conf import settings
from django.db import close_old_connections
from django.test import LiveServerTestCase, override_settings
from django.urls import reverse
from django.utils import timezone
from playwright.sync_api import sync_playwright

from accounts.models import CustomUser
from notifications.models import OrderNotification, PushSubscription
from order.models import Order


@override_settings(ALLOWED_HOSTS=['localhost', 'testserver'])
class NotificationBrowserChecks(LiveServerTestCase):
    def database(self, callback):
        # Playwright's sync driver runs an event loop; keep Django ORM calls on a separate thread.
        def run():
            try:
                return callback()
            finally:
                close_old_connections()
        with ThreadPoolExecutor(max_workers=1) as executor:
            return executor.submit(run).result()

    def test_controls_inbox_sound_and_order_link_in_mobile_viewport(self):
        master = CustomUser.objects.create_user(username='browser-master', role='master')
        self.client.force_login(master)
        point = ec.generate_private_key(ec.SECP256R1()).public_key().public_bytes(
            serialization.Encoding.X962, serialization.PublicFormat.UncompressedPoint)
        subscription = {
            'endpoint': 'https://fcm.googleapis.com/fcm/send/browser-test',
            'keys': {
                'p256dh': base64.urlsafe_b64encode(point).rstrip(b'=').decode(),
                'auth': base64.urlsafe_b64encode(b'0123456789abcdef').rstrip(b'=').decode(),
            },
        }
        with sync_playwright() as playwright:
            browser = playwright.chromium.launch(channel='chrome', headless=True)
            context = browser.new_context(viewport={'width': 390, 'height': 844})
            context.grant_permissions(['notifications'], origin=self.live_server_url)
            context.add_cookies([{
                'name': settings.SESSION_COOKIE_NAME, 'value': self.client.session.session_key,
                'url': self.live_server_url,
            }])
            context.add_init_script("""
                window.__subscription = null;
                PushManager.prototype.getSubscription = async function () { return window.__subscription; };
                PushManager.prototype.subscribe = async function () {
                    const data = SUBSCRIPTION;
                    window.__subscription = {
                        endpoint: data.endpoint, options: {}, toJSON: () => data,
                        unsubscribe: async () => { window.__subscription = null; return true; }
                    };
                    return window.__subscription;
                };
            """.replace('SUBSCRIPTION', json.dumps(subscription)))
            page = context.new_page()
            errors = []
            page.on('pageerror', lambda error: errors.append(str(error)))
            # Existing layout uses remote fonts/scripts; only local notification behavior is under test.
            page.route('**/*', lambda route: route.continue_() if route.request.url.startswith(self.live_server_url)
                       else route.abort())
            page.goto(self.live_server_url + reverse('master_dashboard'))
            page.locator('#enable-order-push:not([disabled])').wait_for()
            page.locator('#enable-order-push').click()
            page.wait_for_function("document.querySelector('#notification-status').textContent.includes('فعال شد')")
            self.assertEqual(self.database(lambda: PushSubscription.objects.get().user_id), master.pk)
            self.assertEqual(page.locator('#enable-order-sound').inner_text(), 'قطع صدای پنل')
            page.locator('#enable-order-sound').click()
            self.assertEqual(page.locator('#enable-order-sound').inner_text(), 'فعال‌کردن صدای پنل')
            page.locator('#enable-order-sound').click()

            with patch('notifications.services.webpush', return_value=Mock(status_code=201)):
                def create_order():
                    order = Order.objects.create(master=master, customer_name='Browser Test', customer_phone='09123456789',
                                                 order_type='cake', delivery_date=timezone.localdate())
                    return order.pk, OrderNotification.objects.get(order=order).payload()
                order_id, payload = self.database(create_order)
            page.evaluate("payload => navigator.serviceWorker.dispatchEvent(new MessageEvent('message', "
                          "{data: {type: 'ORDER_PUSH', payload}}))", payload)
            page.wait_for_function("document.querySelector('#notification-count').textContent.includes('1')")
            self.assertIn(str(order_id), page.locator('#notification-toast').inner_text())
            # Another account's Push must not replace this master's in-app alert.
            page.evaluate("payload => navigator.serviceWorker.dispatchEvent(new MessageEvent('message', "
                          "{data: {type: 'ORDER_PUSH', payload}}))",
                          {**payload, 'id': 99999, 'recipient_id': master.pk + 99, 'body': 'WRONG RECIPIENT'})
            self.assertNotIn('WRONG RECIPIENT', page.locator('#notification-toast').inner_text())
            page.locator('#order-notifications summary').click()
            page.locator('#notification-list a').first.click()
            page.wait_for_url(f'**/*order={order_id}*')
            page.wait_for_function("id => { const modal = document.getElementById(`modal-${id}`); "
                                   "return modal && !modal.classList.contains('hidden'); }", arg=order_id)
            self.assertIsNotNone(self.database(lambda: OrderNotification.objects.get(pk=payload['id']).read_at))
            self.assertIn(f'order={order_id}', page.url)
            # Offline CDN failures in the existing calendar are unrelated to notification controls.
            expected_cdn_errors = ('jalaali is not defined', 'tailwind is not defined')
            self.assertEqual([error for error in errors if not any(known in error for known in expected_cdn_errors)], [])
            context.close()
            browser.close()

    def test_service_worker_handles_closed_app_and_safe_click(self):
        # Run the real worker source with browser API boundaries stubbed, including zero open windows.
        source = (Path(settings.BASE_DIR) / 'static/pwa/sw.js').read_text(encoding='utf-8')
        with sync_playwright() as playwright:
            browser = playwright.chromium.launch(channel='chrome', headless=True)
            page = browser.new_page()
            result = page.evaluate("""async source => {
                const handlers = {};
                const shown = [];
                const opened = [];
                const worker = {
                    location: {origin: 'https://senator.example'},
                    addEventListener: (name, handler) => { handlers[name] = handler; },
                    registration: {showNotification: async (title, options) => shown.push({title, options})},
                    clients: {matchAll: async () => [], openWindow: async url => opened.push(url)},
                };
                new Function('self', source)(worker);
                const payload = {id: 12, recipient_id: 1, title: 'New order', body: 'Order 34',
                    tag: 'senator-order-12', url: '/dashboard/master/?order=34'};
                let task;
                handlers.push({data: {json: () => payload}, waitUntil: promise => { task = promise; }});
                await task;
                handlers.notificationclick({notification: {close() {}, data: {url: payload.url}},
                    waitUntil: promise => { task = promise; }});
                await task;
                handlers.notificationclick({notification: {close() {}, data: {url: 'https://evil.example/'}},
                    waitUntil: promise => { task = promise; }});
                await task;
                return {shown, opened};
            }""", source)
            self.assertEqual(len(result['shown']), 1)
            self.assertFalse(result['shown'][0]['options']['silent'])
            self.assertEqual(result['shown'][0]['options']['vibrate'], [200, 100, 200])
            self.assertEqual(result['opened'], ['https://senator.example/dashboard/master/?order=34'])
            browser.close()
