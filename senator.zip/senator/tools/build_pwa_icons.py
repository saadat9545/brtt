"""Build the simple geometric cake app icon; run with the project's Pillow dependency."""
from pathlib import Path

from PIL import Image, ImageDraw


destination = Path(__file__).resolve().parent.parent / "static" / "pwa"
destination.mkdir(parents=True, exist_ok=True)
for size in (192, 512):
    scale = size / 512
    image = Image.new("RGB", (size, size), "#2c1a4d")
    draw = ImageDraw.Draw(image)

    def box(coords, fill, radius=0):
        draw.rounded_rectangle(
            tuple(round(value * scale) for value in coords),
            radius=round(radius * scale), fill=fill,
        )

    # Gold cake with three candles, readable even at taskbar size.
    box((110, 240, 402, 366), "#f5b041", 22)
    box((110, 240, 402, 272), "#fff1d6", 12)
    box((86, 382, 426, 398), "#fff1d6", 8)
    for center in (176, 256, 336):
        box((center - 8, 185, center + 8, 234), "#fff1d6", 4)
        draw.ellipse(tuple(round(value * scale) for value in
                           (center - 10, 145, center + 10, 174)), fill="#f5b041")
    image.save(destination / f"icon-{size}.png")
